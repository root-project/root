{
   TGeoManager::Import("d0.root");
   new TBrowser;
   gGeoManager->SetMaxVisNodes(40000);
   //gGeoManager->DefaultColors();
   //gGeoManager->GetVolume("IT56")->InvisibleAll();
   //gGeoManager->GetVolume("I215")->SetTransparency(50);
   gGeoManager->GetVolume("D0")->Draw("ogl");
}
