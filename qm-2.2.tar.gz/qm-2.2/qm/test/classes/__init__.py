########################################################################
#
# File:   __init__.py
# Author: Mark Mitchell
# Date:   2003-11-23
#
# Contents:
#   Module initialization.
#
# Copyright (c) 2001 by CodeSourcery, LLC.  All rights reserved. 
#
# For license terms see the file COPYING.
#
########################################################################

########################################################################
# Local Variables:
# mode: python
# indent-tabs-mode: nil
# fill-column: 72
# End:
