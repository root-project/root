########################################################################
#
# File:   __init__.py
# Author: Alex Samuel
# Date:   2001-04-09
#
# Contents:
#   Initialization for module qm.test.web.
#
# Copyright (c) 2001 by CodeSourcery, LLC.  All rights reserved. 
#
# For license terms see the file COPYING.
#
########################################################################

########################################################################
# Local Variables:
# mode: python
# indent-tabs-mode: nil
# fill-column: 72
# End:
