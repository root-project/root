from distutils.core import setup

setup(name="DocumentTemplate",
      version="1.0",
      packages = ['zope-dtml.DocumentTemplate'],
      package_dir = { 'zope-dtml.DocumentTemplate' : '.' })
