{
   TGeoManager::Import("atlas.root");
   new TBrowser;  
   gGeoManager->DefaultColors();
   gGeoManager->SetMaxVisNodes(25000);
   //gGeoManager->SetVisLevel(4);
   gGeoManager->GetVolume("SISO")->InvisibleAll();
   gGeoManager->GetVolume("SIS3")->InvisibleAll();
   gGeoManager->GetVolume("SIS4")->InvisibleAll();
   gGeoManager->GetVolume("SCFL")->InvisibleAll();
   gGeoManager->GetVolume("SCTS")->InvisibleAll();
   //gGeoManager->GetVolume("SISO")->InvisibleAll();
   gGeoManager->GetVolume("SCTT")->Draw("ogl");
}
