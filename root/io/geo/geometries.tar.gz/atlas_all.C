{
   TGeoManager::Import("atlas.root");
   new TBrowser;  
   gGeoManager->DefaultColors();
   gGeoManager->SetMaxVisNodes(5000);
   //gGeoManager->SetVisLevel(4);
   gGeoManager->GetVolume("ATLS")->Draw("ogl");
}
