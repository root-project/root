{
   gROOT->ProcessLine(".x ams.C");
   new TBrowser;
   gGeoManager->DefaultColors();
   gGeoManager->SetVisLevel(3);
   gGeoManager->GetVolume("AMSG")->Draw("ogl");
   
}
