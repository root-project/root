{
   TGeoManager::Import("ams.root");
   new TBrowser;
   gGeoManager->DefaultColors();
   gGeoManager->SetVisLevel(3);
   gGeoManager->GetVolume("AMSG")->Draw("ogl");
   
}
