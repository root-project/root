{
   TGeoManager::Import("gem.root");
   new TBrowser;
   //gROOT->ProcessLine(".x setcolor2.c");
   gGeoManager->DefaultColors();
   //gGeoManager->GetVolume("HUFL")->InvisibleAll();
   gGeoManager->GetVolume("GASO")->SetTransparency(100);
   gGeoManager->GetVolume("PBUS")->SetTransparency(100);
   //gGeoManager->GetVolume("L3YO")->SetLineColor(50);
   gGeoManager->SetMaxVisNodes(30000);
   //gGeoManager->GetVolume("GEMD")->Draw();
   gGeoManager->GetVolume("SVTX")->Draw("ogl");
   //gGeoManager->GetVolume("MUPH")->Draw();
}
