{
   TGeoManager::Import("brahms.root");
   new TBrowser;
   //gGeoManager->DefaultColors();
   //gGeoManager->GetVolume("IT56")->InvisibleAll();
   //gGeoManager->GetVolume("I215")->SetTransparency(50);
   gGeoManager->GetVolume("CAVE")->Draw("ogl");
}
