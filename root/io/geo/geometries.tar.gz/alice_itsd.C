{
   TGeoManager::Import("alice.root");
   gGeoManager->DefaultColors();
   gGeoManager->GetVolume("IT56")->InvisibleAll();
   gGeoManager->GetVolume("IT34")->InvisibleAll();
   gGeoManager->GetVolume("IT12")->InvisibleAll();
   gGeoManager->GetVolume("ICY2")->SetTransparency(50);
   gGeoManager->GetVolume("I215")->SetTransparency(50);
   gGeoManager->GetVolume("I212")->SetTransparency(50);
   gGeoManager->GetVolume("ITSD")->Draw("ogl");
   new TBrowser;
}
