{
   TGeoManager::Import("btev.root");
   new TBrowser;
   gGeoManager->DefaultColors();
   gGeoManager->SetVisLevel(3);
   gGeoManager->GetVolume("C0WA")->Draw("ogl");
   
}
