{
   gROOT->ProcessLine(".x btev.C");
   new TBrowser;
   gGeoManager->DefaultColors();
   gGeoManager->SetVisLevel(3);
   gGeoManager->GetVolume("C0WA")->Draw("ogl");
   
}
