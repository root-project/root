{
   gROOT->ProcessLine(".x phobos.C");
   //TGeoManager::Import("hades.root");
   new TBrowser;
   //gGeoManager->DefaultColors();
   //gGeoManager->GetVolume("IT56")->InvisibleAll();
   //gGeoManager->GetVolume("I215")->SetTransparency(50);
   gGeoManager->GetVolume("OUTS")->Draw("ogl");
}
