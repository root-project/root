{
   TGeoManager::Import("lhcb_mag.root");
   new TBrowser;
   gGeoManager->DefaultColors();
   gGeoManager->GetVolume("World")->Draw("ogl");
}
