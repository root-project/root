{
   //gROOT->ProcessLine(".x aleph.C");
   TGeoManager::Import("aleph.root");
   new TBrowser;
   //gGeoManager->SetMaxVisNodes(40000);
   gGeoManager->DefaultColors();
   //gGeoManager->GetVolume("IT56")->InvisibleAll();
   gGeoManager->GetVolume("MUB1")->SetTransparency(80);
   gGeoManager->GetVolume("MUB2")->SetTransparency(80);
   gGeoManager->GetVolume("HCLA")->SetTransparency(20);
   gGeoManager->GetVolume("HCME")->SetTransparency(20);
   gGeoManager->GetVolume("MUC1")->SetTransparency(80);
   gGeoManager->GetVolume("MUC2")->SetTransparency(80);
   gGeoManager->GetVolume("ALEF")->Draw("ogl");
}
