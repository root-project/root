{
   TGeoManager::Import("babar.root");
   new TBrowser;
   //gGeoManager->DefaultColors();
   gGeoManager->GetVolume("ZZZZ")->InvisibleAll();
   gGeoManager->GetVolume("MPRN")->InvisibleAll();
   gGeoManager->GetVolume("MBGN")->InvisibleAll();
   gGeoManager->GetVolume("DIS1")->InvisibleAll();
   gGeoManager->GetVolume("DIS2")->InvisibleAll();
   gGeoManager->GetVolume("EMBC")->SetLineColor(2);
   gGeoManager->GetVolume("SSVD")->Draw("ogl");
}
