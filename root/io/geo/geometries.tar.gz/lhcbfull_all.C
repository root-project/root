{
   TGeoManager::Import("lhcbfull.root");
   new TBrowser;
   gGeoManager->DefaultColors();
   gGeoManager->SetMaxVisNodes(10000);
   //gGeoManager->SetVisLevel(4);
   gGeoManager->GetVolume("World")->Draw("ogl");
}
