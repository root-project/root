{
   TGeoManager::Import("atlas.root");
   gGeoManager->DefaultColors();
   gGeoManager->SetVisLevel(4);
   gGeoManager->GetVolume("CEE9")->InvisibleAll();
   gGeoManager->GetVolume("CEEh")->InvisibleAll();
   gGeoManager->GetVolume("CEE0")->SetTransparency(70);
   gGeoManager->GetVolume("CBE0")->SetTransparency(80);
   gGeoManager->GetVolume("CEEA")->SetTransparency(60);
   gGeoManager->GetVolume("CEEu")->SetTransparency(60);
   gGeoManager->GetVolume("CEEt")->SetTransparency(60);
   gGeoManager->GetVolume("CRE4")->SetTransparency(60);
   gGeoManager->GetVolume("CRE5")->SetTransparency(60);
   gGeoManager->GetVolume("CRE7")->SetTransparency(60);
   gGeoManager->GetVolume("CRYO")->Draw("ogl");
   new TBrowser;  
}
