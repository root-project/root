{
   TGeoManager::Import("phenix.root");
   new TBrowser;
   gGeoManager->DefaultColors();
   gGeoManager->GetVolume("HALL")->Draw("ogl");

}
