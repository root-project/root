{
   gROOT->ProcessLine(".x phenix.C");
   new TBrowser;
   gGeoManager->DefaultColors();
   gGeoManager->GetVolume("HALL")->Draw("ogl");

}
