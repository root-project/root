{
   //gROOT->ProcessLine(".x cdf.C");
   TGeoManager::Import("cdf.root");
   new TBrowser;
   gGeoManager->SetMaxVisNodes(40000);
   gGeoManager->DefaultColors();
   gGeoManager->GetVolume("ISOS")->InvisibleAll();
   //gGeoManager->GetVolume("")->InvisibleAll();
   //gGeoManager->GetVolume("")->InvisibleAll();
   gGeoManager->GetVolume("JCS4")->SetTransparency(60);
   gGeoManager->GetVolume("IPCA")->SetTransparency(60);
   gGeoManager->GetVolume("SCA3")->SetTransparency(80);
   gGeoManager->GetVolume("SSTI")->SetTransparency(80);
   gGeoManager->GetVolume("SPFM")->SetTransparency(90);
   gGeoManager->GetVolume("SPBM")->SetTransparency(90);
   gGeoManager->GetVolume("SPFE")->SetTransparency(90);
   gGeoManager->GetVolume("SPCC")->SetTransparency(90);
   gGeoManager->GetVolume("SXOI")->SetTransparency(20);
   gGeoManager->GetVolume("SSOF")->SetTransparency(90);
   gGeoManager->GetVolume("SSTF")->SetTransparency(90);
   gGeoManager->GetVolume("SSTO")->SetTransparency(60);
   gGeoManager->GetVolume("SS60")->SetTransparency(60);
   gGeoManager->GetVolume("SS70")->SetTransparency(60);
   gGeoManager->GetVolume("SVXC")->Draw("ogl");
}
