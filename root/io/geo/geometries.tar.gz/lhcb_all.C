{
   gROOT->ProcessLine(".x lhcb.C");
   new TBrowser;
   gGeoManager->DefaultColors();
   gGeoManager->SetVisLevel(2);
   gGeoManager->GetVolume("VSVV")->InvisibleAll();
   gGeoManager->GetVolume("CAVE")->Draw("ogl");
   
}
