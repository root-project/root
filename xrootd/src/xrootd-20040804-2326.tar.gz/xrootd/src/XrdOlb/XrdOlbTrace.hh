#ifndef _XRDOLB_TRACE_H
#define _XRDOLB_TRACE_H
/******************************************************************************/
/*                                                                            */
/*                        X r d O l b T r a c e . h h                         */
/*                                                                            */
/* (C) 2003 by the Board of Trustees of the Leland Stanford, Jr., University  */
/*                            All Rights Reserved                             */
/*   Produced by Andrew Hanushevsky for Stanford University under contract    */
/*                DE-AC03-76-SFO0515 with the Deprtment of Energy             */
/******************************************************************************/

//         $Id: XrdOlbTrace.hh,v 1.2 2004/07/07 02:49:45 abh Exp $

#include "XrdOuc/XrdOucTrace.hh"

#ifndef NODEBUG

#include <iostream.h>
#include "XrdOuc/XrdOucTrace.hh"

#define TRACE_ALL   0x0007
#define TRACE_Debug 0x0001
#define TRACE_Stage 0x0002
#define TRACE_Defer 0x0004

#define DEBUG(y) if (XrdOlbTrace.What & TRACE_Debug) TRACEX(y)

#define TRACE(x,y) if (XrdOlbTrace.What & TRACE_ ## x) TRACEX(y)

#define TRACEX(y) {XrdOlbTrace.Beg(0,epname); cerr <<y; XrdOlbTrace.End();}

#else

#define DEBUG(y)
#define TRACE(x, y)

#endif
#endif
