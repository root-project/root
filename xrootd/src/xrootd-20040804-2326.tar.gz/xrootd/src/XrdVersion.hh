// $Id: XrdVersion.hh,v 1.47 2004/08/05 06:27:05 elmer Exp $
#ifndef __XRD_VERSION_H__
#define __XRD_VERSION_H__
#define XrdVERSION     "20040804-2326"
#if XrdDEBUG
#define XrdVSTRING XrdVERSION "_dbg"
#else
#define XrdVSTRING XrdVERSION
#endif

#define XrdDEFAULTPORT 1094;
#endif
