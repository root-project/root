/******************************************************************************/
/*                                                                            */
/*                     X r d O u c P l a t f o r m . c c                      */
/*                                                                            */
/* (c) 2004 by the Board of Trustees of the Leland Stanford, Jr., University  */
/*       All Rights Reserved. See XrdInfo.cc for complete License Terms       */
/*   Produced by Andrew Hanushevsky for Stanford University under contract    */
/*              DE-AC03-76-SFO0515 with the Department of Energy              */
/******************************************************************************/
  
//        $Id: XrdOucPlatform.cc,v 1.3 2004/07/07 02:50:48 abh Exp $

const char *XrdOucPlatformCVSID = "$Id: XrdOucPlatform.cc,v 1.3 2004/07/07 02:50:48 abh Exp $";

#include <string.h>
#include <unistd.h>
#include <netinet/in.h>
#include <sys/types.h>

#ifdef __linux__

extern "C"
{
int strlcpy(char *dst, const char *src, size_t sz)
{
    int slen = strlen(src);
    int tlen =sz-1;

    if (slen <= tlen) strcpy(dst, src);
       else if (tlen > 0) {strncpy(dst, src, tlen); dst[tlen] = '\0';}
               else if (tlen == 0) dst[0] = '\0';

    return slen;
}
}

#ifdef __ICC__
extern "C"
{
unsigned long long Swap_n2hll(unsigned long long x)
{
 unsigned long long ret_val;

    *( (unsigned long *)(&ret_val) + 1) = ntohl(*( (unsigned long *)(&x)));
    *(((unsigned long *)(&ret_val)))    = ntohl(*(((unsigned long *)(&x))+1));
    return ret_val;
}
}
#endif

#endif
