var _points = [ new Vector3(), new Vector3(), new Vector3(), new Vector3(), new Vector3(), new Vector3(), new Vector3(), new Vector3() ], _vector$5 = new Vector3(), _v0$1 = new Vector3(), _v1$2 = new Vector3(), _v2$1 = new Vector3(), _f0 = new Vector3(), _f1 = new Vector3(), _f2 = new Vector3(), _center = new Vector3(), _extents = new Vector3(), _triangleNormal = new Vector3(), _testAxis = new Vector3();

function Box3(e, t) {
 this.min = void 0 !== e ? e : new Vector3(1 / 0, 1 / 0, 1 / 0), this.max = void 0 !== t ? t : new Vector3(-1 / 0, -1 / 0, -1 / 0);
}

function satForAxes(e, t, i, r, s) {
 for (var a = 0, n = e.length - 3; a <= n; a += 3) {
  _testAxis.fromArray(e, a);
  var o = s.x * Math.abs(_testAxis.x) + s.y * Math.abs(_testAxis.y) + s.z * Math.abs(_testAxis.z), h = t.dot(_testAxis), u = i.dot(_testAxis), l = r.dot(_testAxis);
  if (Math.max(-Math.max(h, u, l), Math.min(h, u, l)) > o) return !1;
 }
 return !0;
}

Object.assign(Box3.prototype, {
 isBox3: !0,
 set: function(e, t) {
  return this.min.copy(e), this.max.copy(t), this;
 },
 setFromArray: function(e) {
  for (var t = 1 / 0, i = 1 / 0, r = 1 / 0, s = -1 / 0, a = -1 / 0, n = -1 / 0, o = 0, h = e.length; o < h; o += 3) {
   var u = e[o], l = e[o + 1], _ = e[o + 2];
   u < t && (t = u), l < i && (i = l), _ < r && (r = _), s < u && (s = u), a < l && (a = l), 
   n < _ && (n = _);
  }
  return this.min.set(t, i, r), this.max.set(s, a, n), this;
 },
 setFromBufferAttribute: function(e) {
  for (var t = 1 / 0, i = 1 / 0, r = 1 / 0, s = -1 / 0, a = -1 / 0, n = -1 / 0, o = 0, h = e.count; o < h; o++) {
   var u = e.getX(o), l = e.getY(o), _ = e.getZ(o);
   u < t && (t = u), l < i && (i = l), _ < r && (r = _), s < u && (s = u), a < l && (a = l), 
   n < _ && (n = _);
  }
  return this.min.set(t, i, r), this.max.set(s, a, n), this;
 },
 setFromPoints: function(e) {
  this.makeEmpty();
  for (var t = 0, i = e.length; t < i; t++) this.expandByPoint(e[t]);
  return this;
 },
 setFromCenterAndSize: function(e, t) {
  t = _vector$5.copy(t).multiplyScalar(.5);
  return this.min.copy(e).sub(t), this.max.copy(e).add(t), this;
 },
 setFromObject: function(e) {
  return this.makeEmpty(), this.expandByObject(e);
 },
 clone: function() {
  return new this.constructor().copy(this);
 },
 copy: function(e) {
  return this.min.copy(e.min), this.max.copy(e.max), this;
 },
 makeEmpty: function() {
  return this.min.x = this.min.y = this.min.z = 1 / 0, this.max.x = this.max.y = this.max.z = -1 / 0, 
  this;
 },
 isEmpty: function() {
  return this.max.x < this.min.x || this.max.y < this.min.y || this.max.z < this.min.z;
 },
 getCenter: function(e) {
  return void 0 === e && (console.warn("Box3: .getCenter() target is now required"), 
  e = new Vector3()), this.isEmpty() ? e.set(0, 0, 0) : e.addVectors(this.min, this.max).multiplyScalar(.5);
 },
 getSize: function(e) {
  return void 0 === e && (console.warn("Box3: .getSize() target is now required"), 
  e = new Vector3()), this.isEmpty() ? e.set(0, 0, 0) : e.subVectors(this.max, this.min);
 },
 expandByPoint: function(e) {
  return this.min.min(e), this.max.max(e), this;
 },
 expandByVector: function(e) {
  return this.min.sub(e), this.max.add(e), this;
 },
 expandByScalar: function(e) {
  return this.min.addScalar(-e), this.max.addScalar(e), this;
 },
 expandByObject: function(t) {
  t.updateWorldMatrix(!1, !1);
  var e = t.geometry;
  if (void 0 !== e) {
   var i = e.vertices;
   for (let e = 0; e < i.array.length; e += i.itemSize) _vector$5.set(i.array[e], i.array[e + 1], i.array[e + 2]), 
   _vector$5.applyMatrix4(t.matrixWorld), this.expandByPoint(_vector$5);
  }
  for (var r = t.children, s = 0, a = r.length; s < a; s++) this.expandByObject(r[s]);
  return this;
 },
 containsPoint: function(e) {
  return !(e.x < this.min.x || e.x > this.max.x || e.y < this.min.y || e.y > this.max.y || e.z < this.min.z || e.z > this.max.z);
 },
 containsBox: function(e) {
  return this.min.x <= e.min.x && e.max.x <= this.max.x && this.min.y <= e.min.y && e.max.y <= this.max.y && this.min.z <= e.min.z && e.max.z <= this.max.z;
 },
 getParameter: function(e, t) {
  return void 0 === t && (console.warn("Box3: .getParameter() target is now required"), 
  t = new Vector3()), t.set((e.x - this.min.x) / (this.max.x - this.min.x), (e.y - this.min.y) / (this.max.y - this.min.y), (e.z - this.min.z) / (this.max.z - this.min.z));
 },
 intersectsBox: function(e) {
  return !(e.max.x < this.min.x || e.min.x > this.max.x || e.max.y < this.min.y || e.min.y > this.max.y || e.max.z < this.min.z || e.min.z > this.max.z);
 },
 intersectsSphere: function(e) {
  return this.clampPoint(e.center, _vector$5), _vector$5.distanceToSquared(e.center) <= e.radius * e.radius;
 },
 intersectsPlane: function(e) {
  var t, i = 0 < e.normal.x ? (t = e.normal.x * this.min.x, e.normal.x * this.max.x) : (t = e.normal.x * this.max.x, 
  e.normal.x * this.min.x);
  return 0 < e.normal.y ? (t += e.normal.y * this.min.y, i += e.normal.y * this.max.y) : (t += e.normal.y * this.max.y, 
  i += e.normal.y * this.min.y), 0 < e.normal.z ? (t += e.normal.z * this.min.z, 
  i += e.normal.z * this.max.z) : (t += e.normal.z * this.max.z, i += e.normal.z * this.min.z), 
  t <= -e.constant && i >= -e.constant;
 },
 intersectsTriangle: function(e) {
  return !this.isEmpty() && (this.getCenter(_center), _extents.subVectors(this.max, _center), 
  _v0$1.subVectors(e.a, _center), _v1$2.subVectors(e.b, _center), _v2$1.subVectors(e.c, _center), 
  _f0.subVectors(_v1$2, _v0$1), _f1.subVectors(_v2$1, _v1$2), _f2.subVectors(_v0$1, _v2$1), 
  !!satForAxes([ 0, -_f0.z, _f0.y, 0, -_f1.z, _f1.y, 0, -_f2.z, _f2.y, _f0.z, 0, -_f0.x, _f1.z, 0, -_f1.x, _f2.z, 0, -_f2.x, -_f0.y, _f0.x, 0, -_f1.y, _f1.x, 0, -_f2.y, _f2.x, 0 ], _v0$1, _v1$2, _v2$1, _extents)) && !!satForAxes([ 1, 0, 0, 0, 1, 0, 0, 0, 1 ], _v0$1, _v1$2, _v2$1, _extents) && (_triangleNormal.crossVectors(_f0, _f1), 
  satForAxes([ _triangleNormal.x, _triangleNormal.y, _triangleNormal.z ], _v0$1, _v1$2, _v2$1, _extents));
 },
 clampPoint: function(e, t) {
  return void 0 === t && (console.warn("Box3: .clampPoint() target is now required"), 
  t = new Vector3()), t.copy(e).clamp(this.min, this.max);
 },
 distanceToPoint: function(e) {
  return _vector$5.copy(e).clamp(this.min, this.max).sub(e).length();
 },
 getBoundingSphere: function(e) {
  return void 0 === e && console.error("Box3: .getBoundingSphere() target is now required"), 
  this.getCenter(e.center), e.radius = .5 * this.getSize(_vector$5).length(), e;
 },
 intersect: function(e) {
  return this.min.max(e.min), this.max.min(e.max), this.isEmpty() && this.makeEmpty(), 
  this;
 },
 union: function(e) {
  return this.min.min(e.min), this.max.max(e.max), this;
 },
 applyMatrix4: function(e) {
  return this.isEmpty() || (_points[0].set(this.min.x, this.min.y, this.min.z).applyMatrix4(e), 
  _points[1].set(this.min.x, this.min.y, this.max.z).applyMatrix4(e), _points[2].set(this.min.x, this.max.y, this.min.z).applyMatrix4(e), 
  _points[3].set(this.min.x, this.max.y, this.max.z).applyMatrix4(e), _points[4].set(this.max.x, this.min.y, this.min.z).applyMatrix4(e), 
  _points[5].set(this.max.x, this.min.y, this.max.z).applyMatrix4(e), _points[6].set(this.max.x, this.max.y, this.min.z).applyMatrix4(e), 
  _points[7].set(this.max.x, this.max.y, this.max.z).applyMatrix4(e), this.setFromPoints(_points)), 
  this;
 },
 translate: function(e) {
  return this.min.add(e), this.max.add(e), this;
 },
 equals: function(e) {
  return e.min.equals(this.min) && e.max.equals(this.max);
 },
 center: function(e) {
  return (e || new Vector3()).addVectors(this.min, this.max).multiplyScalar(.5);
 }
});

var _box = new Box3();

function Sphere(e, t) {
 this.center = void 0 !== e ? e : new Vector3(), this.radius = void 0 !== t ? t : 0;
}

Object.assign(Sphere.prototype, {
 set: function(e, t) {
  return this.center.copy(e), this.radius = t, this;
 },
 setFromPoints: function(e, t) {
  for (var i = this.center, r = (void 0 !== t ? i.copy(t) : _box.setFromPoints(e).getCenter(i), 
  0), s = 0, a = e.length; s < a; s++) r = Math.max(r, i.distanceToSquared(e[s]));
  return this.radius = Math.sqrt(r), this;
 },
 clone: function() {
  return new this.constructor().copy(this);
 },
 copy: function(e) {
  return this.center.copy(e.center), this.radius = e.radius, this;
 },
 empty: function() {
  return this.radius <= 0;
 },
 containsPoint: function(e) {
  return e.distanceToSquared(this.center) <= this.radius * this.radius;
 },
 distanceToPoint: function(e) {
  return e.distanceTo(this.center) - this.radius;
 },
 intersectsSphere: function(e) {
  var t = this.radius + e.radius;
  return e.center.distanceToSquared(this.center) <= t * t;
 },
 intersectsBox: function(e) {
  return e.intersectsSphere(this);
 },
 intersectsPlane: function(e) {
  return Math.abs(e.distanceToPoint(this.center)) <= this.radius;
 },
 clampPoint: function(e, t) {
  var i = this.center.distanceToSquared(e);
  return void 0 === t && (console.warn("Sphere: .clampPoint() target is now required"), 
  t = new Vector3()), t.copy(e), i > this.radius * this.radius && (t.sub(this.center).normalize(), 
  t.multiplyScalar(this.radius).add(this.center)), t;
 },
 getBoundingBox: function(e) {
  return void 0 === e && (console.warn("Sphere: .getBoundingBox() target is now required"), 
  e = new Box3()), e.set(this.center, this.center), e.expandByScalar(this.radius), 
  e;
 },
 applyMatrix4: function(e) {
  return this.center.applyMatrix4(e), this.radius = this.radius * e.getMaxScaleOnAxis(), 
  this;
 },
 translate: function(e) {
  return this.center.add(e), this;
 },
 equals: function(e) {
  return e.center.equals(this.center) && e.radius === this.radius;
 }
});

for (var _lut = [], i$1 = 0; i$1 < 256; i$1++) _lut[i$1] = (i$1 < 16 ? "0" : "") + i$1.toString(16);

var _Math = {
 DEG2RAD: Math.PI / 180,
 RAD2DEG: 180 / Math.PI,
 generateUUID: function() {
  var e = 4294967295 * Math.random() | 0, t = 4294967295 * Math.random() | 0, i = 4294967295 * Math.random() | 0, r = 4294967295 * Math.random() | 0;
  return (_lut[255 & e] + _lut[e >> 8 & 255] + _lut[e >> 16 & 255] + _lut[e >> 24 & 255] + "-" + _lut[255 & t] + _lut[t >> 8 & 255] + "-" + _lut[t >> 16 & 15 | 64] + _lut[t >> 24 & 255] + "-" + _lut[63 & i | 128] + _lut[i >> 8 & 255] + "-" + _lut[i >> 16 & 255] + _lut[i >> 24 & 255] + _lut[255 & r] + _lut[r >> 8 & 255] + _lut[r >> 16 & 255] + _lut[r >> 24 & 255]).toUpperCase();
 },
 clamp: function(e, t, i) {
  return Math.max(t, Math.min(i, e));
 },
 euclideanModulo: function(e, t) {
  return (e % t + t) % t;
 },
 mapLinear: function(e, t, i, r, s) {
  return r + (e - t) * (s - r) / (i - t);
 },
 lerp: function(e, t, i) {
  return (1 - i) * e + i * t;
 },
 smoothstep: function(e, t, i) {
  return e <= t ? 0 : i <= e ? 1 : (e = (e - t) / (i - t)) * e * (3 - 2 * e);
 },
 smootherstep: function(e, t, i) {
  return e <= t ? 0 : i <= e ? 1 : (e = (e - t) / (i - t)) * e * e * (e * (6 * e - 15) + 10);
 },
 randInt: function(e, t) {
  return e + Math.floor(Math.random() * (t - e + 1));
 },
 randFloat: function(e, t) {
  return e + Math.random() * (t - e);
 },
 randFloatSpread: function(e) {
  return e * (.5 - Math.random());
 },
 degToRad: function(e) {
  return e * _Math.DEG2RAD;
 },
 radToDeg: function(e) {
  return e * _Math.RAD2DEG;
 },
 isPowerOfTwo: function(e) {
  return 0 == (e & e - 1) && 0 !== e;
 },
 ceilPowerOfTwo: function(e) {
  return Math.pow(2, Math.ceil(Math.log(e) / Math.LN2));
 },
 floorPowerOfTwo: function(e) {
  return Math.pow(2, Math.floor(Math.log(e) / Math.LN2));
 },
 computeSpheresBoundingSphere: function(t) {
  var i = [];
  for (let e = 0; e < t.length; e++) {
   var r = t[e].getBoundingBox(), s = r.min, a = r.max, n = t[e].center;
   for (let e = 0; e < 3; e++) i.push(...n.toArray()), i[i.length - (3 - e)] = s.getComponent(e), 
   i.push(...n.toArray()), i[i.length - (3 - e)] = a.getComponent(e);
  }
  var e = new Box3(), o = new Sphere(), h = new Vector3();
  e.setFromArray(i), e.center(o.center);
  let u = 0;
  for (let e = 0; e < i.length; e += 3) h.fromArray(i, e), u = Math.max(u, o.center.distanceToSquared(h));
  return o.radius = Math.sqrt(u), isNaN(o.radius) && console.error("Geometry error: Bounding sphere radius is NaN."), 
  o;
 }
};

function Quaternion(e, t, i, r) {
 this._x = e || 0, this._y = t || 0, this._z = i || 0, this._w = void 0 !== r ? r : 1;
}

Object.assign(Quaternion, {
 slerp: function(e, t, i, r) {
  return i.copy(e).slerp(t, r);
 },
 slerpFlat: function(e, t, i, r, s, a, n) {
  var o, h, u, l = i[r + 0], _ = i[r + 1], c = i[r + 2], i = i[r + 3], r = s[a + 0], d = s[a + 1], m = s[a + 2], s = s[a + 3];
  i === s && l === r && _ === d && c === m || (a = 1 - n, o = 0 <= (h = l * r + _ * d + c * m + i * s) ? 1 : -1, 
  (u = 1 - h * h) > Number.EPSILON && (u = Math.sqrt(u), h = Math.atan2(u, h * o), 
  a = Math.sin(a * h) / u, n = Math.sin(n * h) / u), l = l * a + r * (h = n * o), 
  _ = _ * a + d * h, c = c * a + m * h, i = i * a + s * h, a === 1 - n && (l *= u = 1 / Math.sqrt(l * l + _ * _ + c * c + i * i), 
  _ *= u, c *= u, i *= u)), e[t] = l, e[t + 1] = _, e[t + 2] = c, e[t + 3] = i;
 }
}), Object.defineProperties(Quaternion.prototype, {
 x: {
  get: function() {
   return this._x;
  },
  set: function(e) {
   this._x = e, this._onChangeCallback();
  }
 },
 y: {
  get: function() {
   return this._y;
  },
  set: function(e) {
   this._y = e, this._onChangeCallback();
  }
 },
 z: {
  get: function() {
   return this._z;
  },
  set: function(e) {
   this._z = e, this._onChangeCallback();
  }
 },
 w: {
  get: function() {
   return this._w;
  },
  set: function(e) {
   this._w = e, this._onChangeCallback();
  }
 }
}), Object.assign(Quaternion.prototype, {
 isQuaternion: !0,
 set: function(e, t, i, r) {
  return this._x = e, this._y = t, this._z = i, this._w = r, this._onChangeCallback(), 
  this;
 },
 clone: function() {
  return new this.constructor(this._x, this._y, this._z, this._w);
 },
 copy: function(e) {
  return this._x = e.x, this._y = e.y, this._z = e.z, this._w = e.w, this._onChangeCallback(), 
  this;
 },
 setFromEuler: function(e, t) {
  var i, r, s, a, n, o, h;
  if (e && e.isEuler) return n = e._x, o = e._y, i = e._z, e = e.order, a = Math.cos, 
  h = Math.sin, r = a(n / 2), s = a(o / 2), a = a(i / 2), n = h(n / 2), o = h(o / 2), 
  h = h(i / 2), "XYZ" === e ? (this._x = n * s * a + r * o * h, this._y = r * o * a - n * s * h, 
  this._z = r * s * h + n * o * a, this._w = r * s * a - n * o * h) : "YXZ" === e ? (this._x = n * s * a + r * o * h, 
  this._y = r * o * a - n * s * h, this._z = r * s * h - n * o * a, this._w = r * s * a + n * o * h) : "ZXY" === e ? (this._x = n * s * a - r * o * h, 
  this._y = r * o * a + n * s * h, this._z = r * s * h + n * o * a, this._w = r * s * a - n * o * h) : "ZYX" === e ? (this._x = n * s * a - r * o * h, 
  this._y = r * o * a + n * s * h, this._z = r * s * h - n * o * a, this._w = r * s * a + n * o * h) : "YZX" === e ? (this._x = n * s * a + r * o * h, 
  this._y = r * o * a + n * s * h, this._z = r * s * h - n * o * a, this._w = r * s * a - n * o * h) : "XZY" === e && (this._x = n * s * a - r * o * h, 
  this._y = r * o * a - n * s * h, this._z = r * s * h + n * o * a, this._w = r * s * a + n * o * h), 
  !1 !== t && this._onChangeCallback(), this;
  throw new Error("Quaternion: .setFromEuler() now expects an Euler rotation rather than a Vector3 and order.");
 },
 setFromAxisAngle: function(e, t) {
  var t = t / 2, i = Math.sin(t);
  return this._x = e.x * i, this._y = e.y * i, this._z = e.z * i, this._w = Math.cos(t), 
  this._onChangeCallback(), this;
 },
 setFromRotationMatrix: function(e) {
  var t, e = e.elements, i = e[0], r = e[4], s = e[8], a = e[1], n = e[5], o = e[9], h = e[2], u = e[6], e = e[10], l = i + n + e;
  return 0 < l ? (t = .5 / Math.sqrt(l + 1), this._w = .25 / t, this._x = (u - o) * t, 
  this._y = (s - h) * t, this._z = (a - r) * t) : n < i && e < i ? (t = 2 * Math.sqrt(1 + i - n - e), 
  this._w = (u - o) / t, this._x = .25 * t, this._y = (r + a) / t, this._z = (s + h) / t) : e < n ? (t = 2 * Math.sqrt(1 + n - i - e), 
  this._w = (s - h) / t, this._x = (r + a) / t, this._y = .25 * t, this._z = (o + u) / t) : (t = 2 * Math.sqrt(1 + e - i - n), 
  this._w = (a - r) / t, this._x = (s + h) / t, this._y = (o + u) / t, this._z = .25 * t), 
  this._onChangeCallback(), this;
 },
 setFromUnitVectors: function(e, t) {
  var i = e.dot(t) + 1;
  return i < 1e-6 ? (i = 0, Math.abs(e.x) > Math.abs(e.z) ? (this._x = -e.y, this._y = e.x, 
  this._z = 0) : (this._x = 0, this._y = -e.z, this._z = e.y)) : (this._x = e.y * t.z - e.z * t.y, 
  this._y = e.z * t.x - e.x * t.z, this._z = e.x * t.y - e.y * t.x), this._w = i, 
  this.normalize();
 },
 angleTo: function(e) {
  return 2 * Math.acos(Math.abs(_Math.clamp(this.dot(e), -1, 1)));
 },
 rotateTowards: function(e, t) {
  var i = this.angleTo(e);
  return 0 !== i && (t = Math.min(1, t / i), this.slerp(e, t)), this;
 },
 inverse: function() {
  return this.conjugate();
 },
 conjugate: function() {
  return this._x *= -1, this._y *= -1, this._z *= -1, this._onChangeCallback(), 
  this;
 },
 dot: function(e) {
  return this._x * e._x + this._y * e._y + this._z * e._z + this._w * e._w;
 },
 lengthSq: function() {
  return this._x * this._x + this._y * this._y + this._z * this._z + this._w * this._w;
 },
 length: function() {
  return Math.sqrt(this._x * this._x + this._y * this._y + this._z * this._z + this._w * this._w);
 },
 normalize: function() {
  var e = this.length();
  return 0 === e ? (this._x = 0, this._y = 0, this._z = 0, this._w = 1) : (this._x = this._x * (e = 1 / e), 
  this._y = this._y * e, this._z = this._z * e, this._w = this._w * e), this._onChangeCallback(), 
  this;
 },
 multiply: function(e, t) {
  return void 0 !== t ? (console.warn("Quaternion: .multiply() now only accepts one argument. Use .multiplyQuaternions( a, b ) instead."), 
  this.multiplyQuaternions(e, t)) : this.multiplyQuaternions(this, e);
 },
 premultiply: function(e) {
  return this.multiplyQuaternions(e, this);
 },
 multiplyQuaternions: function(e, t) {
  var i = e._x, r = e._y, s = e._z, e = e._w, a = t._x, n = t._y, o = t._z, t = t._w;
  return this._x = i * t + e * a + r * o - s * n, this._y = r * t + e * n + s * a - i * o, 
  this._z = s * t + e * o + i * n - r * a, this._w = e * t - i * a - r * n - s * o, 
  this._onChangeCallback(), this;
 },
 slerp: function(e, t) {
  if (0 !== t) {
   if (1 === t) return this.copy(e);
   var i, r = this._x, s = this._y, a = this._z, n = this._w, o = n * e._w + r * e._x + s * e._y + a * e._z;
   o < 0 ? (this._w = -e._w, this._x = -e._x, this._y = -e._y, this._z = -e._z, 
   o = -o) : this.copy(e), 1 <= o ? (this._w = n, this._x = r, this._y = s, this._z = a) : ((e = 1 - o * o) <= Number.EPSILON ? (this._w = (i = 1 - t) * n + t * this._w, 
   this._x = i * r + t * this._x, this._y = i * s + t * this._y, this._z = i * a + t * this._z, 
   this.normalize()) : (i = Math.sqrt(e), e = Math.atan2(i, o), o = Math.sin((1 - t) * e) / i, 
   t = Math.sin(t * e) / i, this._w = n * o + this._w * t, this._x = r * o + this._x * t, 
   this._y = s * o + this._y * t, this._z = a * o + this._z * t), this._onChangeCallback());
  }
  return this;
 },
 equals: function(e) {
  return e._x === this._x && e._y === this._y && e._z === this._z && e._w === this._w;
 },
 fromArray: function(e, t) {
  return this._x = e[t = void 0 === t ? 0 : t], this._y = e[t + 1], this._z = e[t + 2], 
  this._w = e[t + 3], this._onChangeCallback(), this;
 },
 toArray: function(e, t) {
  return (e = void 0 === e ? [] : e)[t = void 0 === t ? 0 : t] = this._x, e[t + 1] = this._y, 
  e[t + 2] = this._z, e[t + 3] = this._w, e;
 },
 _onChange: function(e) {
  return this._onChangeCallback = e, this;
 },
 _onChangeCallback: function() {}
});

var _vector$4 = new Vector3(), _quaternion$1 = new Quaternion();

function Vector3(e, t, i) {
 this.x = e || 0, this.y = t || 0, this.z = i || 0;
}

Object.assign(Vector3.prototype, {
 isVector3: !0,
 set: function(e, t, i) {
  return this.x = e, this.y = t, this.z = i, this;
 },
 setScalar: function(e) {
  return this.x = e, this.y = e, this.z = e, this;
 },
 setX: function(e) {
  return this.x = e, this;
 },
 setY: function(e) {
  return this.y = e, this;
 },
 setZ: function(e) {
  return this.z = e, this;
 },
 setComponent: function(e, t) {
  switch (e) {
  case 0:
   this.x = t;
   break;

  case 1:
   this.y = t;
   break;

  case 2:
   this.z = t;
   break;

  default:
   throw new Error("index is out of range: " + e);
  }
  return this;
 },
 getComponent: function(e) {
  switch (e) {
  case 0:
   return this.x;

  case 1:
   return this.y;

  case 2:
   return this.z;

  default:
   throw new Error("index is out of range: " + e);
  }
 },
 clone: function() {
  return new this.constructor(this.x, this.y, this.z);
 },
 copy: function(e) {
  return this.x = e.x, this.y = e.y, this.z = e.z, this;
 },
 add: function(e, t) {
  return void 0 !== t ? (console.warn("Vector3: .add() now only accepts one argument. Use .addVectors( a, b ) instead."), 
  this.addVectors(e, t)) : (this.x += e.x, this.y += e.y, this.z += e.z, this);
 },
 addScalar: function(e) {
  return this.x += e, this.y += e, this.z += e, this;
 },
 addVectors: function(e, t) {
  return this.x = e.x + t.x, this.y = e.y + t.y, this.z = e.z + t.z, this;
 },
 addScaledVector: function(e, t) {
  return this.x += e.x * t, this.y += e.y * t, this.z += e.z * t, this;
 },
 sub: function(e, t) {
  return void 0 !== t ? (console.warn("Vector3: .sub() now only accepts one argument. Use .subVectors( a, b ) instead."), 
  this.subVectors(e, t)) : (this.x -= e.x, this.y -= e.y, this.z -= e.z, this);
 },
 subScalar: function(e) {
  return this.x -= e, this.y -= e, this.z -= e, this;
 },
 subVectors: function(e, t) {
  return this.x = e.x - t.x, this.y = e.y - t.y, this.z = e.z - t.z, this;
 },
 multiply: function(e, t) {
  return void 0 !== t ? (console.warn("Vector3: .multiply() now only accepts one argument. Use .multiplyVectors( a, b ) instead."), 
  this.multiplyVectors(e, t)) : (this.x *= e.x, this.y *= e.y, this.z *= e.z, this);
 },
 multiplyScalar: function(e) {
  return this.x *= e, this.y *= e, this.z *= e, this;
 },
 multiplyVectors: function(e, t) {
  return this.x = e.x * t.x, this.y = e.y * t.y, this.z = e.z * t.z, this;
 },
 applyEuler: function(e) {
  return e && e.isEuler || console.error("Vector3: .applyEuler() now expects an Euler rotation rather than a Vector3 and order."), 
  this.applyQuaternion(_quaternion$1.setFromEuler(e));
 },
 applyAxisAngle: function(e, t) {
  return this.applyQuaternion(_quaternion$1.setFromAxisAngle(e, t));
 },
 applyMatrix3: function(e) {
  var t = this.x, i = this.y, r = this.z, e = e.elements;
  return this.x = e[0] * t + e[3] * i + e[6] * r, this.y = e[1] * t + e[4] * i + e[7] * r, 
  this.z = e[2] * t + e[5] * i + e[8] * r, this;
 },
 applyMatrix4: function(e) {
  var t = this.x, i = this.y, r = this.z, e = e.elements, s = 1 / (e[3] * t + e[7] * i + e[11] * r + e[15]);
  return this.x = (e[0] * t + e[4] * i + e[8] * r + e[12]) * s, this.y = (e[1] * t + e[5] * i + e[9] * r + e[13]) * s, 
  this.z = (e[2] * t + e[6] * i + e[10] * r + e[14]) * s, this;
 },
 applyQuaternion: function(e) {
  var t = this.x, i = this.y, r = this.z, s = e.x, a = e.y, n = e.z, e = e.w, o = e * t + a * r - n * i, h = e * i + n * t - s * r, u = e * r + s * i - a * t, t = -s * t - a * i - n * r;
  return this.x = o * e + t * -s + h * -n - u * -a, this.y = h * e + t * -a + u * -s - o * -n, 
  this.z = u * e + t * -n + o * -a - h * -s, this;
 },
 project: function(e) {
  return this.applyMatrix4(e.matrixWorldInverse).applyMatrix4(e.projectionMatrix);
 },
 unproject: function(e) {
  return this.applyMatrix4(e.projectionMatrixInverse).applyMatrix4(e.matrixWorld);
 },
 transformDirection: function(e) {
  var t = this.x, i = this.y, r = this.z, e = e.elements;
  return this.x = e[0] * t + e[4] * i + e[8] * r, this.y = e[1] * t + e[5] * i + e[9] * r, 
  this.z = e[2] * t + e[6] * i + e[10] * r, this.normalize();
 },
 divide: function(e) {
  return this.x /= e.x, this.y /= e.y, this.z /= e.z, this;
 },
 divideScalar: function(e) {
  return this.multiplyScalar(1 / e);
 },
 min: function(e) {
  return this.x = Math.min(this.x, e.x), this.y = Math.min(this.y, e.y), this.z = Math.min(this.z, e.z), 
  this;
 },
 max: function(e) {
  return this.x = Math.max(this.x, e.x), this.y = Math.max(this.y, e.y), this.z = Math.max(this.z, e.z), 
  this;
 },
 clamp: function(e, t) {
  return this.x = Math.max(e.x, Math.min(t.x, this.x)), this.y = Math.max(e.y, Math.min(t.y, this.y)), 
  this.z = Math.max(e.z, Math.min(t.z, this.z)), this;
 },
 clampScalar: function(e, t) {
  return this.x = Math.max(e, Math.min(t, this.x)), this.y = Math.max(e, Math.min(t, this.y)), 
  this.z = Math.max(e, Math.min(t, this.z)), this;
 },
 clampLength: function(e, t) {
  var i = this.length();
  return this.divideScalar(i || 1).multiplyScalar(Math.max(e, Math.min(t, i)));
 },
 floor: function() {
  return this.x = Math.floor(this.x), this.y = Math.floor(this.y), this.z = Math.floor(this.z), 
  this;
 },
 ceil: function() {
  return this.x = Math.ceil(this.x), this.y = Math.ceil(this.y), this.z = Math.ceil(this.z), 
  this;
 },
 round: function() {
  return this.x = Math.round(this.x), this.y = Math.round(this.y), this.z = Math.round(this.z), 
  this;
 },
 roundToZero: function() {
  return this.x = this.x < 0 ? Math.ceil(this.x) : Math.floor(this.x), this.y = this.y < 0 ? Math.ceil(this.y) : Math.floor(this.y), 
  this.z = this.z < 0 ? Math.ceil(this.z) : Math.floor(this.z), this;
 },
 negate: function() {
  return this.x = -this.x, this.y = -this.y, this.z = -this.z, this;
 },
 dot: function(e) {
  return this.x * e.x + this.y * e.y + this.z * e.z;
 },
 lengthSq: function() {
  return this.x * this.x + this.y * this.y + this.z * this.z;
 },
 length: function() {
  return Math.sqrt(this.x * this.x + this.y * this.y + this.z * this.z);
 },
 manhattanLength: function() {
  return Math.abs(this.x) + Math.abs(this.y) + Math.abs(this.z);
 },
 normalize: function() {
  return this.divideScalar(this.length() || 1);
 },
 setLength: function(e) {
  return this.normalize().multiplyScalar(e);
 },
 lerp: function(e, t) {
  return this.x += (e.x - this.x) * t, this.y += (e.y - this.y) * t, this.z += (e.z - this.z) * t, 
  this;
 },
 lerpVectors: function(e, t, i) {
  return this.subVectors(t, e).multiplyScalar(i).add(e);
 },
 cross: function(e, t) {
  return void 0 !== t ? (console.warn("Vector3: .cross() now only accepts one argument. Use .crossVectors( a, b ) instead."), 
  this.crossVectors(e, t)) : this.crossVectors(this, e);
 },
 crossVectors: function(e, t) {
  var i = e.x, r = e.y, e = e.z, s = t.x, a = t.y, t = t.z;
  return this.x = r * t - e * a, this.y = e * s - i * t, this.z = i * a - r * s, 
  this;
 },
 projectOnVector: function(e) {
  var t = e.dot(this) / e.lengthSq();
  return this.copy(e).multiplyScalar(t);
 },
 projectOnPlane: function(e) {
  return _vector$4.copy(this).projectOnVector(e), this.sub(_vector$4);
 },
 reflect: function(e) {
  return this.sub(_vector$4.copy(e).multiplyScalar(2 * this.dot(e)));
 },
 angleTo: function(e) {
  var t = Math.sqrt(this.lengthSq() * e.lengthSq()), e = (0 === t && console.error("Vector3: angleTo() can't handle zero length vectors."), 
  this.dot(e) / t);
  return Math.acos(_Math.clamp(e, -1, 1));
 },
 distanceTo: function(e) {
  return Math.sqrt(this.distanceToSquared(e));
 },
 distanceToSquared: function(e) {
  var t = this.x - e.x, i = this.y - e.y, e = this.z - e.z;
  return t * t + i * i + e * e;
 },
 manhattanDistanceTo: function(e) {
  return Math.abs(this.x - e.x) + Math.abs(this.y - e.y) + Math.abs(this.z - e.z);
 },
 setFromSpherical: function(e) {
  return this.setFromSphericalCoords(e.radius, e.phi, e.theta);
 },
 setFromSphericalCoords: function(e, t, i) {
  var r = Math.sin(t) * e;
  return this.x = r * Math.sin(i), this.y = Math.cos(t) * e, this.z = r * Math.cos(i), 
  this;
 },
 setFromCylindrical: function(e) {
  return this.setFromCylindricalCoords(e.radius, e.theta, e.y);
 },
 setFromCylindricalCoords: function(e, t, i) {
  return this.x = e * Math.sin(t), this.y = i, this.z = e * Math.cos(t), this;
 },
 setFromMatrixPosition: function(e) {
  e = e.elements;
  return this.x = e[12], this.y = e[13], this.z = e[14], this;
 },
 setFromMatrixScale: function(e) {
  var t = this.setFromMatrixColumn(e, 0).length(), i = this.setFromMatrixColumn(e, 1).length(), e = this.setFromMatrixColumn(e, 2).length();
  return this.x = t, this.y = i, this.z = e, this;
 },
 setFromMatrixColumn: function(e, t) {
  return this.fromArray(e.elements, 4 * t);
 },
 equals: function(e) {
  return e.x === this.x && e.y === this.y && e.z === this.z;
 },
 fromArray: function(e, t) {
  return this.x = e[t = void 0 === t ? 0 : t], this.y = e[t + 1], this.z = e[t + 2], 
  this;
 },
 toArray: function(e, t) {
  return (e = void 0 === e ? [] : e)[t = void 0 === t ? 0 : t] = this.x, e[t + 1] = this.y, 
  e[t + 2] = this.z, e;
 },
 fromBufferAttribute: function(e, t, i) {
  return void 0 !== i && console.warn("Vector3: offset has been removed from .fromBufferAttribute()."), 
  this.x = e.getX(t), this.y = e.getY(t), this.z = e.getZ(t), this;
 }
});

const singleton = Symbol(), singletonEnforcer = Symbol(), revision = 1, FRONT_SIDE = 0, BACK_SIDE = 1, FRONT_AND_BACK_SIDE = 2, FUNC_LESS = 3, FUNC_LEQUAL = 4, FUNC_EQUAL = 5, FUNC_NOTEQUAL = 6, FUNC_GREATER = 7, FUNC_GEQUAL = 8, FUNC_NEVER = 9, FUNC_ALWAYS = 10, WEBGL1 = "gl1", WEBGL2 = "gl2", ZeroCurvatureEnding = 2400, ZeroSlopeEnding = 2401, WrapAroundEnding = 2402, FlatShading = 1, GouraudShading = 2, PhongShading = 3, SmoothShading = 4, SPRITE_SPACE_WORLD = 0, SPRITE_SPACE_SCREEN = 1, STRIPE_SPACE_WORLD = 0, STRIPE_SPACE_SCREEN = 1, STRIPE_CAP_DEFAULT = 0, STRIPE_CAP_BUTT = 1, STRIPE_CAP_SQUARE = 2, STRIPE_CAP_ROUND = 3, STRIPE_JOIN_DEFAULT = 0, STRIPE_JOIN_MITER = 1, STRIPE_JOIN_BEVEL = 2, STRIPE_JOIN_ROUND = 3, TEXT2D_SPACE_WORLD = 0, TEXT2D_SPACE_SCREEN = 1, HIGHPASS_MODE_BRIGHTNESS = 0, HIGHPASS_MODE_DIFFERENCE = 1, POINTS = 0, LINES = 1, LINE_LOOP = 2, LINE_STRIP = 3, TRIANGLES = 4, TRIANGLE_STRIP = 5, TRIANGLE_FAN = 6, VERTEX_SHADER = "vertex", FRAGMENT_SHADER = "fragment", SUPPRESS_DEFAULT_KEYBOARD_KEYS = [ 37, 38, 39, 40 ], BLACKLIST = {
 beef: [ "046d" ]
}, gamepadIDRegex = /Vendor:\s+(.*)\s+Product:\s+(.*)\)/, MINVEC = new Vector3(-1, -1, -1), MAXVEC = new Vector3(1, 1, 1);

var _v0 = new Vector3(), _v1$1 = new Vector3(), _v2 = new Vector3(), _v3 = new Vector3(), _vab = new Vector3(), _vac = new Vector3(), _vbc = new Vector3(), _vap = new Vector3(), _vbp = new Vector3(), _vcp = new Vector3();

function Triangle(e, t, i) {
 this.a = void 0 !== e ? e : new Vector3(), this.b = void 0 !== t ? t : new Vector3(), 
 this.c = void 0 !== i ? i : new Vector3();
}

function Spherical(e, t, i) {
 return this.radius = void 0 !== e ? e : 1, this.phi = void 0 !== t ? t : 0, this.theta = void 0 !== i ? i : 0, 
 this;
}

function Cylindrical(e, t, i) {
 return this.radius = void 0 !== e ? e : 1, this.theta = void 0 !== t ? t : 0, this.y = void 0 !== i ? i : 0, 
 this;
}

Object.assign(Triangle, {
 getNormal: function(e, t, i, r) {
  void 0 === r && (console.warn("Triangle: .getNormal() target is now required"), 
  r = new Vector3()), r.subVectors(i, t), _v0.subVectors(e, t), r.cross(_v0);
  i = r.lengthSq();
  return 0 < i ? r.multiplyScalar(1 / Math.sqrt(i)) : r.set(0, 0, 0);
 },
 getBarycoord: function(e, t, i, r, s) {
  _v0.subVectors(r, t), _v1$1.subVectors(i, t), _v2.subVectors(e, t);
  var r = _v0.dot(_v0), i = _v0.dot(_v1$1), e = _v0.dot(_v2), t = _v1$1.dot(_v1$1), a = _v1$1.dot(_v2), n = r * t - i * i;
  return void 0 === s && (console.warn("Triangle: .getBarycoord() target is now required"), 
  s = new Vector3()), 0 == n ? s.set(-2, -1, -1) : s.set(1 - (t = (t * e - i * a) * (s = 1 / n)) - (n = (r * a - i * e) * s), n, t);
 },
 containsPoint: function(e, t, i, r) {
  return Triangle.getBarycoord(e, t, i, r, _v3), 0 <= _v3.x && 0 <= _v3.y && _v3.x + _v3.y <= 1;
 },
 getUV: function(e, t, i, r, s, a, n, o) {
  return this.getBarycoord(e, t, i, r, _v3), o.set(0, 0), o.addScaledVector(s, _v3.x), 
  o.addScaledVector(a, _v3.y), o.addScaledVector(n, _v3.z), o;
 },
 isFrontFacing: function(e, t, i, r) {
  return _v0.subVectors(i, t), _v1$1.subVectors(e, t), _v0.cross(_v1$1).dot(r) < 0;
 }
}), Object.assign(Triangle.prototype, {
 set: function(e, t, i) {
  return this.a.copy(e), this.b.copy(t), this.c.copy(i), this;
 },
 setFromPointsAndIndices: function(e, t, i, r) {
  return this.a.copy(e[t]), this.b.copy(e[i]), this.c.copy(e[r]), this;
 },
 clone: function() {
  return new this.constructor().copy(this);
 },
 copy: function(e) {
  return this.a.copy(e.a), this.b.copy(e.b), this.c.copy(e.c), this;
 },
 getArea: function() {
  return _v0.subVectors(this.c, this.b), _v1$1.subVectors(this.a, this.b), .5 * _v0.cross(_v1$1).length();
 },
 getMidpoint: function(e) {
  return void 0 === e && (console.warn("Triangle: .getMidpoint() target is now required"), 
  e = new Vector3()), e.addVectors(this.a, this.b).add(this.c).multiplyScalar(1 / 3);
 },
 getNormal: function(e) {
  return Triangle.getNormal(this.a, this.b, this.c, e);
 },
 getPlane: function(e) {
  return void 0 === e && (console.warn("Triangle: .getPlane() target is now required"), 
  e = new Vector3()), e.setFromCoplanarPoints(this.a, this.b, this.c);
 },
 getBarycoord: function(e, t) {
  return Triangle.getBarycoord(e, this.a, this.b, this.c, t);
 },
 getUV: function(e, t, i, r, s) {
  return Triangle.getUV(e, this.a, this.b, this.c, t, i, r, s);
 },
 containsPoint: function(e) {
  return Triangle.containsPoint(e, this.a, this.b, this.c);
 },
 isFrontFacing: function(e) {
  return Triangle.isFrontFacing(this.a, this.b, this.c, e);
 },
 intersectsBox: function(e) {
  return e.intersectsTriangle(this);
 },
 closestPointToPoint: function(e, t) {
  void 0 === t && (console.warn("Triangle: .closestPointToPoint() target is now required"), 
  t = new Vector3());
  var i = this.a, r = this.b, s = this.c, a = (_vab.subVectors(r, i), _vac.subVectors(s, i), 
  _vap.subVectors(e, i), _vab.dot(_vap)), n = _vac.dot(_vap);
  if (a <= 0 && n <= 0) return t.copy(i);
  _vbp.subVectors(e, r);
  var o = _vab.dot(_vbp), h = _vac.dot(_vbp);
  if (0 <= o && h <= o) return t.copy(r);
  var u = a * h - o * n;
  if (u <= 0 && 0 <= a && o <= 0) return l = a / (a - o), t.copy(i).addScaledVector(_vab, l);
  _vcp.subVectors(e, s);
  var l, _, e = _vab.dot(_vcp), c = _vac.dot(_vcp);
  return 0 <= c && e <= c ? t.copy(s) : (a = e * n - a * c) <= 0 && 0 <= n && c <= 0 ? (_ = n / (n - c), 
  t.copy(i).addScaledVector(_vac, _)) : (n = o * c - e * h) <= 0 && 0 <= h - o && 0 <= e - c ? (_vbc.subVectors(s, r), 
  _ = (h - o) / (h - o + (e - c)), t.copy(r).addScaledVector(_vbc, _)) : (l = a * (s = 1 / (n + a + u)), 
  _ = u * s, t.copy(i).addScaledVector(_vab, l).addScaledVector(_vac, _));
 },
 equals: function(e) {
  return e.a.equals(this.a) && e.b.equals(this.b) && e.c.equals(this.c);
 }
}), Object.assign(Spherical.prototype, {
 set: function(e, t, i) {
  return this.radius = e, this.phi = t, this.theta = i, this;
 },
 clone: function() {
  return new this.constructor().copy(this);
 },
 copy: function(e) {
  return this.radius = e.radius, this.phi = e.phi, this.theta = e.theta, this;
 },
 makeSafe: function() {
  return this.phi = Math.max(1e-6, Math.min(Math.PI - 1e-6, this.phi)), this;
 },
 setFromVector3: function(e) {
  return this.setFromCartesianCoords(e.x, e.y, e.z);
 },
 setFromCartesianCoords: function(e, t, i) {
  return this.radius = Math.sqrt(e * e + t * t + i * i), 0 === this.radius ? (this.theta = 0, 
  this.phi = 0) : (this.theta = Math.atan2(e, i), this.phi = Math.acos(_Math.clamp(t / this.radius, -1, 1))), 
  this;
 }
}), Object.assign(Cylindrical.prototype, {
 set: function(e, t, i) {
  return this.radius = e, this.theta = t, this.y = i, this;
 },
 clone: function() {
  return new this.constructor().copy(this);
 },
 copy: function(e) {
  return this.radius = e.radius, this.theta = e.theta, this.y = e.y, this;
 },
 setFromVector3: function(e) {
  return this.setFromCartesianCoords(e.x, e.y, e.z);
 },
 setFromCartesianCoords: function(e, t, i) {
  return this.radius = Math.sqrt(e * e + i * i), this.theta = Math.atan2(e, i), 
  this.y = t, this;
 }
});

var _vector$3 = new Vector3();

function Matrix3() {
 this.elements = [ 1, 0, 0, 0, 1, 0, 0, 0, 1 ], 0 < arguments.length && console.error("Matrix3: the constructor no longer reads arguments. use .set() instead.");
}

Object.assign(Matrix3.prototype, {
 isMatrix3: !0,
 set: function(e, t, i, r, s, a, n, o, h) {
  var u = this.elements;
  return u[0] = e, u[1] = r, u[2] = n, u[3] = t, u[4] = s, u[5] = o, u[6] = i, u[7] = a, 
  u[8] = h, this;
 },
 identity: function() {
  return this.set(1, 0, 0, 0, 1, 0, 0, 0, 1), this;
 },
 clone: function() {
  return new this.constructor().fromArray(this.elements);
 },
 copy: function(e) {
  var t = this.elements, e = e.elements;
  return t[0] = e[0], t[1] = e[1], t[2] = e[2], t[3] = e[3], t[4] = e[4], t[5] = e[5], 
  t[6] = e[6], t[7] = e[7], t[8] = e[8], this;
 },
 setFromMatrix4: function(e) {
  e = e.elements;
  return this.set(e[0], e[4], e[8], e[1], e[5], e[9], e[2], e[6], e[10]), this;
 },
 applyToBufferAttribute: function(e) {
  for (var t = 0, i = e.count; t < i; t++) _vector$3.x = e.getX(t), _vector$3.y = e.getY(t), 
  _vector$3.z = e.getZ(t), _vector$3.applyMatrix3(this), e.setXYZ(t, _vector$3.x, _vector$3.y, _vector$3.z);
  return e;
 },
 multiply: function(e) {
  return this.multiplyMatrices(this, e);
 },
 premultiply: function(e) {
  return this.multiplyMatrices(e, this);
 },
 multiplyMatrices: function(e, t) {
  var e = e.elements, t = t.elements, i = this.elements, r = e[0], s = e[3], a = e[6], n = e[1], o = e[4], h = e[7], u = e[2], l = e[5], e = e[8], _ = t[0], c = t[3], d = t[6], m = t[1], g = t[4], p = t[7], f = t[2], y = t[5], t = t[8];
  return i[0] = r * _ + s * m + a * f, i[3] = r * c + s * g + a * y, i[6] = r * d + s * p + a * t, 
  i[1] = n * _ + o * m + h * f, i[4] = n * c + o * g + h * y, i[7] = n * d + o * p + h * t, 
  i[2] = u * _ + l * m + e * f, i[5] = u * c + l * g + e * y, i[8] = u * d + l * p + e * t, 
  this;
 },
 multiplyScalar: function(e) {
  var t = this.elements;
  return t[0] *= e, t[3] *= e, t[6] *= e, t[1] *= e, t[4] *= e, t[7] *= e, t[2] *= e, 
  t[5] *= e, t[8] *= e, this;
 },
 determinant: function() {
  var e = this.elements, t = e[0], i = e[1], r = e[2], s = e[3], a = e[4], n = e[5], o = e[6], h = e[7], e = e[8];
  return t * a * e - t * n * h - i * s * e + i * n * o + r * s * h - r * a * o;
 },
 getInverse: function(e, t) {
  e && e.isMatrix4 && console.error("Matrix3: .getInverse() no longer takes a Matrix4 argument.");
  var e = e.elements, i = this.elements, r = e[0], s = e[1], a = e[2], n = e[3], o = e[4], h = e[5], u = e[6], l = e[7], e = e[8], _ = e * o - h * l, c = h * u - e * n, d = l * n - o * u, m = r * _ + s * c + a * d;
  if (0 == m) {
   var g = "Matrix3: .getInverse() can't invert matrix, determinant is 0";
   if (!0 === t) throw new Error(g);
   return console.warn(g), this.identity();
  }
  t = 1 / m;
  return i[0] = _ * t, i[1] = (a * l - e * s) * t, i[2] = (h * s - a * o) * t, i[3] = c * t, 
  i[4] = (e * r - a * u) * t, i[5] = (a * n - h * r) * t, i[6] = d * t, i[7] = (s * u - l * r) * t, 
  i[8] = (o * r - s * n) * t, this;
 },
 transpose: function() {
  var e = this.elements, t = e[1];
  return e[1] = e[3], e[3] = t, t = e[2], e[2] = e[6], e[6] = t, t = e[5], e[5] = e[7], 
  e[7] = t, this;
 },
 getNormalMatrix: function(e) {
  return this.setFromMatrix4(e).getInverse(this).transpose();
 },
 transposeIntoArray: function(e) {
  var t = this.elements;
  return e[0] = t[0], e[1] = t[3], e[2] = t[6], e[3] = t[1], e[4] = t[4], e[5] = t[7], 
  e[6] = t[2], e[7] = t[5], e[8] = t[8], this;
 },
 setUvTransform: function(e, t, i, r, s, a, n) {
  var o = Math.cos(s), s = Math.sin(s);
  this.set(i * o, i * s, -i * (o * a + s * n) + a + e, -r * s, r * o, -r * (-s * a + o * n) + n + t, 0, 0, 1);
 },
 scale: function(e, t) {
  var i = this.elements;
  return i[0] *= e, i[3] *= e, i[6] *= e, i[1] *= t, i[4] *= t, i[7] *= t, this;
 },
 rotate: function(e) {
  var t = Math.cos(e), e = Math.sin(e), i = this.elements, r = i[0], s = i[3], a = i[6], n = i[1], o = i[4], h = i[7];
  return i[0] = t * r + e * n, i[3] = t * s + e * o, i[6] = t * a + e * h, i[1] = -e * r + t * n, 
  i[4] = -e * s + t * o, i[7] = -e * a + t * h, this;
 },
 translate: function(e, t) {
  var i = this.elements;
  return i[0] += e * i[2], i[3] += e * i[5], i[6] += e * i[8], i[1] += t * i[2], 
  i[4] += t * i[5], i[7] += t * i[8], this;
 },
 equals: function(e) {
  for (var t = this.elements, i = e.elements, r = 0; r < 9; r++) if (t[r] !== i[r]) return !1;
  return !0;
 },
 fromArray: function(e, t) {
  void 0 === t && (t = 0);
  for (var i = 0; i < 9; i++) this.elements[i] = e[i + t];
  return this;
 },
 toArray: function(e, t) {
  var i = this.elements;
  return (e = void 0 === e ? [] : e)[t = void 0 === t ? 0 : t] = i[0], e[t + 1] = i[1], 
  e[t + 2] = i[2], e[t + 3] = i[3], e[t + 4] = i[4], e[t + 5] = i[5], e[t + 6] = i[6], 
  e[t + 7] = i[7], e[t + 8] = i[8], e;
 }
});

var _vector1 = new Vector3(), _vector2 = new Vector3(), _normalMatrix = new Matrix3();

function Plane(e, t) {
 this.normal = void 0 !== e ? e : new Vector3(1, 0, 0), this.constant = void 0 !== t ? t : 0;
}

Object.assign(Plane.prototype, {
 isPlane: !0,
 set: function(e, t) {
  return this.normal.copy(e), this.constant = t, this;
 },
 setComponents: function(e, t, i, r) {
  return this.normal.set(e, t, i), this.constant = r, this;
 },
 setFromNormalAndCoplanarPoint: function(e, t) {
  return this.normal.copy(e), this.constant = -t.dot(this.normal), this;
 },
 setFromCoplanarPoints: function(e, t, i) {
  i = _vector1.subVectors(i, t).cross(_vector2.subVectors(e, t)).normalize();
  return this.setFromNormalAndCoplanarPoint(i, e), this;
 },
 clone: function() {
  return new this.constructor().copy(this);
 },
 copy: function(e) {
  return this.normal.copy(e.normal), this.constant = e.constant, this;
 },
 normalize: function() {
  var e = 1 / this.normal.length();
  return this.normal.multiplyScalar(e), this.constant *= e, this;
 },
 negate: function() {
  return this.constant *= -1, this.normal.negate(), this;
 },
 distanceToPoint: function(e) {
  return this.normal.dot(e) + this.constant;
 },
 distanceToSphere: function(e) {
  return this.distanceToPoint(e.center) - e.radius;
 },
 projectPoint: function(e, t) {
  return void 0 === t && (console.warn("Plane: .projectPoint() target is now required"), 
  t = new Vector3()), t.copy(this.normal).multiplyScalar(-this.distanceToPoint(e)).add(e);
 },
 intersectLine: function(e, t) {
  void 0 === t && (console.warn("Plane: .intersectLine() target is now required"), 
  t = new Vector3());
  var i = e.delta(_vector1), r = this.normal.dot(i);
  return 0 === r ? 0 === this.distanceToPoint(e.start) ? t.copy(e.start) : void 0 : (r = -(e.start.dot(this.normal) + this.constant) / r) < 0 || 1 < r ? void 0 : t.copy(i).multiplyScalar(r).add(e.start);
 },
 intersectsLine: function(e) {
  var t = this.distanceToPoint(e.start), e = this.distanceToPoint(e.end);
  return t < 0 && 0 < e || e < 0 && 0 < t;
 },
 intersectsBox: function(e) {
  return e.intersectsPlane(this);
 },
 intersectsSphere: function(e) {
  return e.intersectsPlane(this);
 },
 coplanarPoint: function(e) {
  return void 0 === e && (console.warn("Plane: .coplanarPoint() target is now required"), 
  e = new Vector3()), e.copy(this.normal).multiplyScalar(-this.constant);
 },
 applyMatrix4: function(e, t) {
  t = t || _normalMatrix.getNormalMatrix(e), e = this.coplanarPoint(_vector1).applyMatrix4(e), 
  t = this.normal.applyMatrix3(t).normalize();
  return this.constant = -e.dot(t), this;
 },
 translate: function(e) {
  return this.constant -= e.dot(this.normal), this;
 },
 equals: function(e) {
  return e.normal.equals(this.normal) && e.constant === this.constant;
 }
});

var _sphere = new Sphere(), _vector$2 = new Vector3();

function Frustum(e, t, i, r, s, a) {
 this.planes = [ void 0 !== e ? e : new Plane(), void 0 !== t ? t : new Plane(), void 0 !== i ? i : new Plane(), void 0 !== r ? r : new Plane(), void 0 !== s ? s : new Plane(), void 0 !== a ? a : new Plane() ];
}

Object.assign(Frustum.prototype, {
 set: function(e, t, i, r, s, a) {
  var n = this.planes;
  return n[0].copy(e), n[1].copy(t), n[2].copy(i), n[3].copy(r), n[4].copy(s), n[5].copy(a), 
  this;
 },
 clone: function() {
  return new this.constructor().copy(this);
 },
 copy: function(e) {
  for (var t = this.planes, i = 0; i < 6; i++) t[i].copy(e.planes[i]);
  return this;
 },
 setFromMatrix: function(e) {
  var t = this.planes, e = e.elements, i = e[0], r = e[1], s = e[2], a = e[3], n = e[4], o = e[5], h = e[6], u = e[7], l = e[8], _ = e[9], c = e[10], d = e[11], m = e[12], g = e[13], p = e[14], e = e[15];
  return t[0].setComponents(a - i, u - n, d - l, e - m).normalize(), t[1].setComponents(a + i, u + n, d + l, e + m).normalize(), 
  t[2].setComponents(a + r, u + o, d + _, e + g).normalize(), t[3].setComponents(a - r, u - o, d - _, e - g).normalize(), 
  t[4].setComponents(a - s, u - h, d - c, e - p).normalize(), t[5].setComponents(a + s, u + h, d + c, e + p).normalize(), 
  this;
 },
 intersectsObject: function(e) {
  var t = e.geometry;
  return null === t.boundingSphere && t.computeBoundingSphere(), _sphere.copy(t.boundingSphere).applyMatrix4(e.matrixWorld), 
  this.intersectsSphere(_sphere);
 },
 intersectsSprite: function(e) {
  return _sphere.center.set(0, 0, 0), _sphere.radius = .7071067811865476, _sphere.applyMatrix4(e.matrixWorld), 
  this.intersectsSphere(_sphere);
 },
 intersectsSphere: function(e) {
  for (var t = this.planes, i = e.center, r = -e.radius, s = 0; s < 6; s++) if (t[s].distanceToPoint(i) < r) return !1;
  return !0;
 },
 intersectsBox: function(e) {
  for (var t = this.planes, i = 0; i < 6; i++) {
   var r = t[i];
   if (_vector$2.x = (0 < r.normal.x ? e.max : e.min).x, _vector$2.y = (0 < r.normal.y ? e.max : e.min).y, 
   _vector$2.z = (0 < r.normal.z ? e.max : e.min).z, r.distanceToPoint(_vector$2) < 0) return !1;
  }
  return !0;
 },
 containsPoint: function(e) {
  for (var t = this.planes, i = 0; i < 6; i++) if (t[i].distanceToPoint(e) < 0) return !1;
  return !0;
 }
});

var _vector$1 = new Vector3(), _segCenter = new Vector3(), _segDir = new Vector3(), _diff = new Vector3(), _edge1 = new Vector3(), _edge2 = new Vector3(), _normal = new Vector3();

function Ray(e, t) {
 this.origin = void 0 !== e ? e : new Vector3(), this.direction = void 0 !== t ? t : new Vector3();
}

Object.assign(Ray.prototype, {
 set: function(e, t) {
  return this.origin.copy(e), this.direction.copy(t), this;
 },
 clone: function() {
  return new this.constructor().copy(this);
 },
 copy: function(e) {
  return this.origin.copy(e.origin), this.direction.copy(e.direction), this;
 },
 at: function(e, t) {
  return void 0 === t && (console.warn("Ray: .at() target is now required"), t = new Vector3()), 
  t.copy(this.direction).multiplyScalar(e).add(this.origin);
 },
 lookAt: function(e) {
  return this.direction.copy(e).sub(this.origin).normalize(), this;
 },
 recast: function(e) {
  return this.origin.copy(this.at(e, _vector$1)), this;
 },
 closestPointToPoint: function(e, t) {
  void 0 === t && (console.warn("Ray: .closestPointToPoint() target is now required"), 
  t = new Vector3()), t.subVectors(e, this.origin);
  e = t.dot(this.direction);
  return e < 0 ? t.copy(this.origin) : t.copy(this.direction).multiplyScalar(e).add(this.origin);
 },
 distanceToPoint: function(e) {
  return Math.sqrt(this.distanceSqToPoint(e));
 },
 distanceSqToPoint: function(e) {
  var t = _vector$1.subVectors(e, this.origin).dot(this.direction);
  return (t < 0 ? this.origin : (_vector$1.copy(this.direction).multiplyScalar(t).add(this.origin), 
  _vector$1)).distanceToSquared(e);
 },
 distanceSqToSegment: function(e, t, i, r) {
  _segCenter.copy(e).add(t).multiplyScalar(.5), _segDir.copy(t).sub(e).normalize(), 
  _diff.copy(this.origin).sub(_segCenter);
  var s, a, n, e = .5 * e.distanceTo(t), t = -this.direction.dot(_segDir), o = _diff.dot(this.direction), h = -_diff.dot(_segDir), u = _diff.lengthSq(), l = Math.abs(1 - t * t);
  return l = 0 < l ? (a = t * o - h, n = e * l, 0 <= (s = t * h - o) ? -n <= a ? a <= n ? (s *= l = 1 / l) * (s + t * (a *= l) + 2 * o) + a * (t * s + a + 2 * h) + u : (a = e, 
  -(s = Math.max(0, -(t * a + o))) * s + a * (a + 2 * h) + u) : (a = -e, -(s = Math.max(0, -(t * a + o))) * s + a * (a + 2 * h) + u) : a <= -n ? -(s = Math.max(0, -(-t * e + o))) * s + (a = 0 < s ? -e : Math.min(Math.max(-e, -h), e)) * (a + 2 * h) + u : a <= n ? (s = 0, 
  (a = Math.min(Math.max(-e, -h), e)) * (a + 2 * h) + u) : -(s = Math.max(0, -(t * e + o))) * s + (a = 0 < s ? e : Math.min(Math.max(-e, -h), e)) * (a + 2 * h) + u) : (a = 0 < t ? -e : e, 
  -(s = Math.max(0, -(t * a + o))) * s + a * (a + 2 * h) + u), i && i.copy(this.direction).multiplyScalar(s).add(this.origin), 
  r && r.copy(_segDir).multiplyScalar(a).add(_segCenter), l;
 },
 intersectSphere: function(e, t) {
  _vector$1.subVectors(e.center, this.origin);
  var i = _vector$1.dot(this.direction), r = _vector$1.dot(_vector$1) - i * i, e = e.radius * e.radius;
  return e < r || (r = i + (e = Math.sqrt(e - r)), (i = i - e) < 0 && r < 0) ? null : i < 0 ? this.at(r, t) : this.at(i, t);
 },
 intersectsSphere: function(e) {
  return this.distanceSqToPoint(e.center) <= e.radius * e.radius;
 },
 distanceToPlane: function(e) {
  var t = e.normal.dot(this.direction);
  return 0 === t ? 0 === e.distanceToPoint(this.origin) ? 0 : null : 0 <= (e = -(this.origin.dot(e.normal) + e.constant) / t) ? e : null;
 },
 intersectPlane: function(e, t) {
  e = this.distanceToPlane(e);
  return null === e ? null : this.at(e, t);
 },
 intersectsPlane: function(e) {
  var t = e.distanceToPoint(this.origin);
  return 0 === t || e.normal.dot(this.direction) * t < 0;
 },
 intersectBox: function(e, t) {
  var i, r, s, a = 1 / this.direction.x, n = 1 / this.direction.y, o = 1 / this.direction.z, h = this.origin, a = 0 <= a ? (i = (e.min.x - h.x) * a, 
  (e.max.x - h.x) * a) : (i = (e.max.x - h.x) * a, (e.min.x - h.x) * a), n = 0 <= n ? (s = (e.min.y - h.y) * n, 
  (e.max.y - h.y) * n) : (s = (e.max.y - h.y) * n, (e.min.y - h.y) * n);
  return n < i || a < s || ((i < s || i != i) && (i = s), (n < a || a != a) && (a = n), 
  (s = 0 <= o ? (r = (e.min.z - h.z) * o, (e.max.z - h.z) * o) : (r = (e.max.z - h.z) * o, 
  (e.min.z - h.z) * o)) < i) || a < r || ((i < r || i != i) && (i = r), (a = s < a || a != a ? s : a) < 0) ? null : this.at(0 <= i ? i : a, t);
 },
 intersectsBox: function(e) {
  return null !== this.intersectBox(e, _vector$1);
 },
 intersectTriangle: function(e, t, i, r, s) {
  _edge1.subVectors(t, e), _edge2.subVectors(i, e), _normal.crossVectors(_edge1, _edge2);
  var a, t = this.direction.dot(_normal);
  if (0 < t) {
   if (r) return null;
   a = 1;
  } else {
   if (!(t < 0)) return null;
   a = -1, t = -t;
  }
  _diff.subVectors(this.origin, e);
  i = a * this.direction.dot(_edge2.crossVectors(_diff, _edge2));
  return i < 0 || (r = a * this.direction.dot(_edge1.cross(_diff))) < 0 || t < i + r || (e = -a * _diff.dot(_normal)) < 0 ? null : this.at(e / t, s);
 },
 applyMatrix4: function(e) {
  return this.origin.applyMatrix4(e), this.direction.transformDirection(e), this;
 },
 equals: function(e) {
  return e.origin.equals(this.origin) && e.direction.equals(this.direction);
 }
});

var _v1 = new Vector3(), _m1 = new Matrix4(), _zero = new Vector3(0, 0, 0), _one = new Vector3(1, 1, 1), _x = new Vector3(), _y = new Vector3(), _z = new Vector3();

function Matrix4() {
 this.elements = [ 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1 ], 0 < arguments.length && console.error("Matrix4: the constructor no longer reads arguments. use .set() instead.");
}

function Vector2(e, t) {
 this.x = e || 0, this.y = t || 0;
}

Object.assign(Matrix4.prototype, {
 isMatrix4: !0,
 set: function(e, t, i, r, s, a, n, o, h, u, l, _, c, d, m, g) {
  var p = this.elements;
  return p[0] = e, p[4] = t, p[8] = i, p[12] = r, p[1] = s, p[5] = a, p[9] = n, 
  p[13] = o, p[2] = h, p[6] = u, p[10] = l, p[14] = _, p[3] = c, p[7] = d, p[11] = m, 
  p[15] = g, this;
 },
 identity: function() {
  return this.set(1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1), this;
 },
 clone: function() {
  return new Matrix4().fromArray(this.elements);
 },
 copy: function(e) {
  var t = this.elements, e = e.elements;
  return t[0] = e[0], t[1] = e[1], t[2] = e[2], t[3] = e[3], t[4] = e[4], t[5] = e[5], 
  t[6] = e[6], t[7] = e[7], t[8] = e[8], t[9] = e[9], t[10] = e[10], t[11] = e[11], 
  t[12] = e[12], t[13] = e[13], t[14] = e[14], t[15] = e[15], this;
 },
 copyPosition: function(e) {
  var t = this.elements, e = e.elements;
  return t[12] = e[12], t[13] = e[13], t[14] = e[14], this;
 },
 extractBasis: function(e, t, i) {
  return e.setFromMatrixColumn(this, 0), t.setFromMatrixColumn(this, 1), i.setFromMatrixColumn(this, 2), 
  this;
 },
 makeBasis: function(e, t, i) {
  return this.set(e.x, t.x, i.x, 0, e.y, t.y, i.y, 0, e.z, t.z, i.z, 0, 0, 0, 0, 1), 
  this;
 },
 extractRotation: function(e) {
  var t = this.elements, i = e.elements, r = 1 / _v1.setFromMatrixColumn(e, 0).length(), s = 1 / _v1.setFromMatrixColumn(e, 1).length(), e = 1 / _v1.setFromMatrixColumn(e, 2).length();
  return t[0] = i[0] * r, t[1] = i[1] * r, t[2] = i[2] * r, t[3] = 0, t[4] = i[4] * s, 
  t[5] = i[5] * s, t[6] = i[6] * s, t[7] = 0, t[8] = i[8] * e, t[9] = i[9] * e, 
  t[10] = i[10] * e, t[11] = 0, t[12] = 0, t[13] = 0, t[14] = 0, t[15] = 1, this;
 },
 makeRotationFromEuler: function(e) {
  e && e.isEuler || console.error("Matrix4: .makeRotationFromEuler() now expects a Euler rotation rather than a Vector3 and order.");
  var t, i, r, s, a, n, o, h, u, l, _, c, d = this.elements, m = e.x, g = e.y, p = e.z, f = Math.cos(m), m = Math.sin(m), y = Math.cos(g), g = Math.sin(g), T = Math.cos(p), p = Math.sin(p);
  return "XYZ" === e.order ? (a = f * T, n = f * p, o = m * T, h = m * p, d[0] = y * T, 
  d[4] = -y * p, d[8] = g, d[1] = n + o * g, d[5] = a - h * g, d[9] = -m * y, d[2] = h - a * g, 
  d[6] = o + n * g, d[10] = f * y) : "YXZ" === e.order ? (i = y * p, r = g * T, 
  d[0] = (t = y * T) + (s = g * p) * m, d[4] = r * m - i, d[8] = f * g, d[1] = f * p, 
  d[5] = f * T, d[9] = -m, d[2] = i * m - r, d[6] = s + t * m, d[10] = f * y) : "ZXY" === e.order ? (i = y * p, 
  r = g * T, d[0] = (t = y * T) - (s = g * p) * m, d[4] = -f * p, d[8] = r + i * m, 
  d[1] = i + r * m, d[5] = f * T, d[9] = s - t * m, d[2] = -f * g, d[6] = m, d[10] = f * y) : "ZYX" === e.order ? (a = f * T, 
  n = f * p, o = m * T, h = m * p, d[0] = y * T, d[4] = o * g - n, d[8] = a * g + h, 
  d[1] = y * p, d[5] = h * g + a, d[9] = n * g - o, d[2] = -g, d[6] = m * y, d[10] = f * y) : "YZX" === e.order ? (u = f * y, 
  l = f * g, _ = m * y, c = m * g, d[0] = y * T, d[4] = c - u * p, d[8] = _ * p + l, 
  d[1] = p, d[5] = f * T, d[9] = -m * T, d[2] = -g * T, d[6] = l * p + _, d[10] = u - c * p) : "XZY" === e.order && (u = f * y, 
  l = f * g, _ = m * y, c = m * g, d[0] = y * T, d[4] = -p, d[8] = g * T, d[1] = u * p + c, 
  d[5] = f * T, d[9] = l * p - _, d[2] = _ * p - l, d[6] = m * T, d[10] = c * p + u), 
  d[3] = 0, d[7] = 0, d[11] = 0, d[12] = 0, d[13] = 0, d[14] = 0, d[15] = 1, this;
 },
 makeRotationFromQuaternion: function(e) {
  return this.compose(_zero, e, _one);
 },
 lookAt: function(e, t, i) {
  var r = this.elements;
  return _z.subVectors(e, t), 0 === _z.lengthSq() && (_z.z = 1), _z.normalize(), 
  _x.crossVectors(i, _z), 0 === _x.lengthSq() && (1 === Math.abs(i.z) ? _z.x += 1e-4 : _z.z += 1e-4, 
  _z.normalize(), _x.crossVectors(i, _z)), _x.normalize(), _y.crossVectors(_z, _x), 
  r[0] = _x.x, r[4] = _y.x, r[8] = _z.x, r[1] = _x.y, r[5] = _y.y, r[9] = _z.y, 
  r[2] = _x.z, r[6] = _y.z, r[10] = _z.z, this;
 },
 multiply: function(e, t) {
  return void 0 !== t ? (console.warn("Matrix4: .multiply() now only accepts one argument. Use .multiplyMatrices( a, b ) instead."), 
  this.multiplyMatrices(e, t)) : this.multiplyMatrices(this, e);
 },
 premultiply: function(e) {
  return this.multiplyMatrices(e, this);
 },
 multiplyMatrices: function(e, t) {
  var e = e.elements, t = t.elements, i = this.elements, r = e[0], s = e[4], a = e[8], n = e[12], o = e[1], h = e[5], u = e[9], l = e[13], _ = e[2], c = e[6], d = e[10], m = e[14], g = e[3], p = e[7], f = e[11], e = e[15], y = t[0], T = t[4], x = t[8], S = t[12], E = t[1], A = t[5], R = t[9], v = t[13], P = t[2], w = t[6], M = t[10], b = t[14], L = t[3], C = t[7], F = t[11], t = t[15];
  return i[0] = r * y + s * E + a * P + n * L, i[4] = r * T + s * A + a * w + n * C, 
  i[8] = r * x + s * R + a * M + n * F, i[12] = r * S + s * v + a * b + n * t, i[1] = o * y + h * E + u * P + l * L, 
  i[5] = o * T + h * A + u * w + l * C, i[9] = o * x + h * R + u * M + l * F, i[13] = o * S + h * v + u * b + l * t, 
  i[2] = _ * y + c * E + d * P + m * L, i[6] = _ * T + c * A + d * w + m * C, i[10] = _ * x + c * R + d * M + m * F, 
  i[14] = _ * S + c * v + d * b + m * t, i[3] = g * y + p * E + f * P + e * L, i[7] = g * T + p * A + f * w + e * C, 
  i[11] = g * x + p * R + f * M + e * F, i[15] = g * S + p * v + f * b + e * t, 
  this;
 },
 multiplyScalar: function(e) {
  var t = this.elements;
  return t[0] *= e, t[4] *= e, t[8] *= e, t[12] *= e, t[1] *= e, t[5] *= e, t[9] *= e, 
  t[13] *= e, t[2] *= e, t[6] *= e, t[10] *= e, t[14] *= e, t[3] *= e, t[7] *= e, 
  t[11] *= e, t[15] *= e, this;
 },
 applyToBufferAttribute: function(e) {
  for (var t = 0, i = e.count; t < i; t++) _v1.x = e.getX(t), _v1.y = e.getY(t), 
  _v1.z = e.getZ(t), _v1.applyMatrix4(this), e.setXYZ(t, _v1.x, _v1.y, _v1.z);
  return e;
 },
 determinant: function() {
  var e = this.elements, t = e[0], i = e[4], r = e[8], s = e[12], a = e[1], n = e[5], o = e[9], h = e[13], u = e[2], l = e[6], _ = e[10], c = e[14];
  return e[3] * (+s * o * l - r * h * l - s * n * _ + i * h * _ + r * n * c - i * o * c) + e[7] * (+t * o * c - t * h * _ + s * a * _ - r * a * c + r * h * u - s * o * u) + e[11] * (+t * h * l - t * n * c - s * a * l + i * a * c + s * n * u - i * h * u) + e[15] * (-r * n * u - t * o * l + t * n * _ + r * a * l - i * a * _ + i * o * u);
 },
 transpose: function() {
  var e = this.elements, t = e[1];
  return e[1] = e[4], e[4] = t, t = e[2], e[2] = e[8], e[8] = t, t = e[6], e[6] = e[9], 
  e[9] = t, t = e[3], e[3] = e[12], e[12] = t, t = e[7], e[7] = e[13], e[13] = t, 
  t = e[11], e[11] = e[14], e[14] = t, this;
 },
 setPosition: function(e, t, i) {
  var r = this.elements;
  return e.isVector3 ? (r[12] = e.x, r[13] = e.y, r[14] = e.z) : (r[12] = e, r[13] = t, 
  r[14] = i), this;
 },
 getInverse: function(e, t) {
  var i = this.elements, e = e.elements, r = e[0], s = e[1], a = e[2], n = e[3], o = e[4], h = e[5], u = e[6], l = e[7], _ = e[8], c = e[9], d = e[10], m = e[11], g = e[12], p = e[13], f = e[14], e = e[15], y = c * f * l - p * d * l + p * u * m - h * f * m - c * u * e + h * d * e, T = g * d * l - _ * f * l - g * u * m + o * f * m + _ * u * e - o * d * e, x = _ * p * l - g * c * l + g * h * m - o * p * m - _ * h * e + o * c * e, S = g * c * u - _ * p * u - g * h * d + o * p * d + _ * h * f - o * c * f, E = r * y + s * T + a * x + n * S;
  if (0 == E) {
   var A = "Matrix4: .getInverse() can't invert matrix, determinant is 0";
   if (!0 === t) throw new Error(A);
   return console.warn(A), this.identity();
  }
  t = 1 / E;
  return i[0] = y * t, i[1] = (p * d * n - c * f * n - p * a * m + s * f * m + c * a * e - s * d * e) * t, 
  i[2] = (h * f * n - p * u * n + p * a * l - s * f * l - h * a * e + s * u * e) * t, 
  i[3] = (c * u * n - h * d * n - c * a * l + s * d * l + h * a * m - s * u * m) * t, 
  i[4] = T * t, i[5] = (_ * f * n - g * d * n + g * a * m - r * f * m - _ * a * e + r * d * e) * t, 
  i[6] = (g * u * n - o * f * n - g * a * l + r * f * l + o * a * e - r * u * e) * t, 
  i[7] = (o * d * n - _ * u * n + _ * a * l - r * d * l - o * a * m + r * u * m) * t, 
  i[8] = x * t, i[9] = (g * c * n - _ * p * n - g * s * m + r * p * m + _ * s * e - r * c * e) * t, 
  i[10] = (o * p * n - g * h * n + g * s * l - r * p * l - o * s * e + r * h * e) * t, 
  i[11] = (_ * h * n - o * c * n - _ * s * l + r * c * l + o * s * m - r * h * m) * t, 
  i[12] = S * t, i[13] = (_ * p * a - g * c * a + g * s * d - r * p * d - _ * s * f + r * c * f) * t, 
  i[14] = (g * h * a - o * p * a - g * s * u + r * p * u + o * s * f - r * h * f) * t, 
  i[15] = (o * c * a - _ * h * a + _ * s * u - r * c * u - o * s * d + r * h * d) * t, 
  this;
 },
 scale: function(e) {
  var t = this.elements, i = e.x, r = e.y, e = e.z;
  return t[0] *= i, t[4] *= r, t[8] *= e, t[1] *= i, t[5] *= r, t[9] *= e, t[2] *= i, 
  t[6] *= r, t[10] *= e, t[3] *= i, t[7] *= r, t[11] *= e, this;
 },
 getMaxScaleOnAxis: function() {
  var e = this.elements, t = e[0] * e[0] + e[1] * e[1] + e[2] * e[2], i = e[4] * e[4] + e[5] * e[5] + e[6] * e[6], e = e[8] * e[8] + e[9] * e[9] + e[10] * e[10];
  return Math.sqrt(Math.max(t, i, e));
 },
 makeTranslation: function(e, t, i) {
  return this.set(1, 0, 0, e, 0, 1, 0, t, 0, 0, 1, i, 0, 0, 0, 1), this;
 },
 makeRotationX: function(e) {
  var t = Math.cos(e), e = Math.sin(e);
  return this.set(1, 0, 0, 0, 0, t, -e, 0, 0, e, t, 0, 0, 0, 0, 1), this;
 },
 makeRotationY: function(e) {
  var t = Math.cos(e), e = Math.sin(e);
  return this.set(t, 0, e, 0, 0, 1, 0, 0, -e, 0, t, 0, 0, 0, 0, 1), this;
 },
 makeRotationZ: function(e) {
  var t = Math.cos(e), e = Math.sin(e);
  return this.set(t, -e, 0, 0, e, t, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1), this;
 },
 makeRotationAxis: function(e, t) {
  var i = Math.cos(t), t = Math.sin(t), r = 1 - i, s = e.x, a = e.y, e = e.z, n = r * s, o = r * a;
  return this.set(n * s + i, n * a - t * e, n * e + t * a, 0, n * a + t * e, o * a + i, o * e - t * s, 0, n * e - t * a, o * e + t * s, r * e * e + i, 0, 0, 0, 0, 1), 
  this;
 },
 makeScale: function(e, t, i) {
  return this.set(e, 0, 0, 0, 0, t, 0, 0, 0, 0, i, 0, 0, 0, 0, 1), this;
 },
 makeShear: function(e, t, i) {
  return this.set(1, t, i, 0, e, 1, i, 0, e, t, 1, 0, 0, 0, 0, 1), this;
 },
 compose: function(e, t, i) {
  var r = this.elements, s = t._x, a = t._y, n = t._z, t = t._w, o = s + s, h = a + a, u = n + n, l = s * o, _ = s * h, s = s * u, c = a * h, a = a * u, n = n * u, o = t * o, h = t * h, t = t * u, u = i.x, d = i.y, i = i.z;
  return r[0] = (1 - (c + n)) * u, r[1] = (_ + t) * u, r[2] = (s - h) * u, r[3] = 0, 
  r[4] = (_ - t) * d, r[5] = (1 - (l + n)) * d, r[6] = (a + o) * d, r[7] = 0, r[8] = (s + h) * i, 
  r[9] = (a - o) * i, r[10] = (1 - (l + c)) * i, r[11] = 0, r[12] = e.x, r[13] = e.y, 
  r[14] = e.z, r[15] = 1, this;
 },
 decompose: function(e, t, i) {
  var r = this.elements, s = _v1.set(r[0], r[1], r[2]).length(), a = _v1.set(r[4], r[5], r[6]).length(), n = _v1.set(r[8], r[9], r[10]).length(), e = (this.determinant() < 0 && (s = -s), 
  e.x = r[12], e.y = r[13], e.z = r[14], _m1.copy(this), 1 / s), r = 1 / a, o = 1 / n;
  return _m1.elements[0] *= e, _m1.elements[1] *= e, _m1.elements[2] *= e, _m1.elements[4] *= r, 
  _m1.elements[5] *= r, _m1.elements[6] *= r, _m1.elements[8] *= o, _m1.elements[9] *= o, 
  _m1.elements[10] *= o, t.setFromRotationMatrix(_m1), i.x = s, i.y = a, i.z = n, 
  this;
 },
 makePerspective: function(e, t, i, r, s, a) {
  void 0 === a && console.warn("Matrix4: .makePerspective() has been redefined and has a new signature. Please check the docs.");
  var n = this.elements, o = 2 * s / (i - r), h = (t + e) / (t - e), i = (i + r) / (i - r), r = -(a + s) / (a - s), a = -2 * a * s / (a - s);
  return n[0] = 2 * s / (t - e), n[4] = 0, n[8] = h, n[12] = 0, n[1] = 0, n[5] = o, 
  n[9] = i, n[13] = 0, n[2] = 0, n[6] = 0, n[10] = r, n[14] = a, n[3] = 0, n[7] = 0, 
  n[11] = -1, n[15] = 0, this;
 },
 makeOrthographic: function(e, t, i, r, s, a) {
  var n = this.elements, o = 1 / (t - e), h = 1 / (i - r), u = 1 / (a - s), t = (t + e) * o, e = (i + r) * h, i = (a + s) * u;
  return n[0] = 2 * o, n[4] = 0, n[8] = 0, n[12] = -t, n[1] = 0, n[5] = 2 * h, n[9] = 0, 
  n[13] = -e, n[2] = 0, n[6] = 0, n[10] = -2 * u, n[14] = -i, n[3] = 0, n[7] = 0, 
  n[11] = 0, n[15] = 1, this;
 },
 equals: function(e) {
  for (var t = this.elements, i = e.elements, r = 0; r < 16; r++) if (t[r] !== i[r]) return !1;
  return !0;
 },
 fromArray: function(e, t) {
  void 0 === t && (t = 0);
  for (var i = 0; i < 16; i++) this.elements[i] = e[i + t];
  return this;
 },
 toArray: function(e, t) {
  var i = this.elements;
  return (e = void 0 === e ? [] : e)[t = void 0 === t ? 0 : t] = i[0], e[t + 1] = i[1], 
  e[t + 2] = i[2], e[t + 3] = i[3], e[t + 4] = i[4], e[t + 5] = i[5], e[t + 6] = i[6], 
  e[t + 7] = i[7], e[t + 8] = i[8], e[t + 9] = i[9], e[t + 10] = i[10], e[t + 11] = i[11], 
  e[t + 12] = i[12], e[t + 13] = i[13], e[t + 14] = i[14], e[t + 15] = i[15], e;
 }
}), Object.defineProperties(Vector2.prototype, {
 width: {
  get: function() {
   return this.x;
  },
  set: function(e) {
   this.x = e;
  }
 },
 height: {
  get: function() {
   return this.y;
  },
  set: function(e) {
   this.y = e;
  }
 }
}), Object.assign(Vector2.prototype, {
 isVector2: !0,
 set: function(e, t) {
  return this.x = e, this.y = t, this;
 },
 setScalar: function(e) {
  return this.x = e, this.y = e, this;
 },
 setX: function(e) {
  return this.x = e, this;
 },
 setY: function(e) {
  return this.y = e, this;
 },
 setComponent: function(e, t) {
  switch (e) {
  case 0:
   this.x = t;
   break;

  case 1:
   this.y = t;
   break;

  default:
   throw new Error("index is out of range: " + e);
  }
  return this;
 },
 getComponent: function(e) {
  switch (e) {
  case 0:
   return this.x;

  case 1:
   return this.y;

  default:
   throw new Error("index is out of range: " + e);
  }
 },
 clone: function() {
  return new this.constructor(this.x, this.y);
 },
 copy: function(e) {
  return this.x = e.x, this.y = e.y, this;
 },
 add: function(e, t) {
  return void 0 !== t ? (console.warn("Vector2: .add() now only accepts one argument. Use .addVectors( a, b ) instead."), 
  this.addVectors(e, t)) : (this.x += e.x, this.y += e.y, this);
 },
 addScalar: function(e) {
  return this.x += e, this.y += e, this;
 },
 addVectors: function(e, t) {
  return this.x = e.x + t.x, this.y = e.y + t.y, this;
 },
 addScaledVector: function(e, t) {
  return this.x += e.x * t, this.y += e.y * t, this;
 },
 sub: function(e, t) {
  return void 0 !== t ? (console.warn("Vector2: .sub() now only accepts one argument. Use .subVectors( a, b ) instead."), 
  this.subVectors(e, t)) : (this.x -= e.x, this.y -= e.y, this);
 },
 subScalar: function(e) {
  return this.x -= e, this.y -= e, this;
 },
 subVectors: function(e, t) {
  return this.x = e.x - t.x, this.y = e.y - t.y, this;
 },
 multiply: function(e) {
  return this.x *= e.x, this.y *= e.y, this;
 },
 multiplyScalar: function(e) {
  return this.x *= e, this.y *= e, this;
 },
 divide: function(e) {
  return this.x /= e.x, this.y /= e.y, this;
 },
 divideScalar: function(e) {
  return this.multiplyScalar(1 / e);
 },
 applyMatrix3: function(e) {
  var t = this.x, i = this.y, e = e.elements;
  return this.x = e[0] * t + e[3] * i + e[6], this.y = e[1] * t + e[4] * i + e[7], 
  this;
 },
 min: function(e) {
  return this.x = Math.min(this.x, e.x), this.y = Math.min(this.y, e.y), this;
 },
 max: function(e) {
  return this.x = Math.max(this.x, e.x), this.y = Math.max(this.y, e.y), this;
 },
 clamp: function(e, t) {
  return this.x = Math.max(e.x, Math.min(t.x, this.x)), this.y = Math.max(e.y, Math.min(t.y, this.y)), 
  this;
 },
 clampScalar: function(e, t) {
  return this.x = Math.max(e, Math.min(t, this.x)), this.y = Math.max(e, Math.min(t, this.y)), 
  this;
 },
 clampLength: function(e, t) {
  var i = this.length();
  return this.divideScalar(i || 1).multiplyScalar(Math.max(e, Math.min(t, i)));
 },
 floor: function() {
  return this.x = Math.floor(this.x), this.y = Math.floor(this.y), this;
 },
 ceil: function() {
  return this.x = Math.ceil(this.x), this.y = Math.ceil(this.y), this;
 },
 round: function() {
  return this.x = Math.round(this.x), this.y = Math.round(this.y), this;
 },
 roundToZero: function() {
  return this.x = this.x < 0 ? Math.ceil(this.x) : Math.floor(this.x), this.y = this.y < 0 ? Math.ceil(this.y) : Math.floor(this.y), 
  this;
 },
 negate: function() {
  return this.x = -this.x, this.y = -this.y, this;
 },
 dot: function(e) {
  return this.x * e.x + this.y * e.y;
 },
 cross: function(e) {
  return this.x * e.y - this.y * e.x;
 },
 lengthSq: function() {
  return this.x * this.x + this.y * this.y;
 },
 length: function() {
  return Math.sqrt(this.x * this.x + this.y * this.y);
 },
 manhattanLength: function() {
  return Math.abs(this.x) + Math.abs(this.y);
 },
 normalize: function() {
  return this.divideScalar(this.length() || 1);
 },
 angle: function() {
  var e = Math.atan2(this.y, this.x);
  return e < 0 && (e += 2 * Math.PI), e;
 },
 distanceTo: function(e) {
  return Math.sqrt(this.distanceToSquared(e));
 },
 distanceToSquared: function(e) {
  var t = this.x - e.x, e = this.y - e.y;
  return t * t + e * e;
 },
 manhattanDistanceTo: function(e) {
  return Math.abs(this.x - e.x) + Math.abs(this.y - e.y);
 },
 setLength: function(e) {
  return this.normalize().multiplyScalar(e);
 },
 lerp: function(e, t) {
  return this.x += (e.x - this.x) * t, this.y += (e.y - this.y) * t, this;
 },
 lerpVectors: function(e, t, i) {
  return this.subVectors(t, e).multiplyScalar(i).add(e);
 },
 equals: function(e) {
  return e.x === this.x && e.y === this.y;
 },
 fromArray: function(e, t) {
  return this.x = e[t = void 0 === t ? 0 : t], this.y = e[t + 1], this;
 },
 toArray: function(e, t) {
  return (e = void 0 === e ? [] : e)[t = void 0 === t ? 0 : t] = this.x, e[t + 1] = this.y, 
  e;
 },
 fromBufferAttribute: function(e, t, i) {
  return void 0 !== i && console.warn("Vector2: offset has been removed from .fromBufferAttribute()."), 
  this.x = e.getX(t), this.y = e.getY(t), this;
 },
 rotateAround: function(e, t) {
  var i = Math.cos(t), t = Math.sin(t), r = this.x - e.x, s = this.y - e.y;
  return this.x = r * i - s * t + e.x, this.y = r * t + s * i + e.y, this;
 }
});

var _vector = new Vector2();

function Box2(e, t) {
 this.min = void 0 !== e ? e : new Vector2(1 / 0, 1 / 0), this.max = void 0 !== t ? t : new Vector2(-1 / 0, -1 / 0);
}

Object.assign(Box2.prototype, {
 set: function(e, t) {
  return this.min.copy(e), this.max.copy(t), this;
 },
 setFromPoints: function(e) {
  this.makeEmpty();
  for (var t = 0, i = e.length; t < i; t++) this.expandByPoint(e[t]);
  return this;
 },
 setFromCenterAndSize: function(e, t) {
  t = _vector.copy(t).multiplyScalar(.5);
  return this.min.copy(e).sub(t), this.max.copy(e).add(t), this;
 },
 clone: function() {
  return new this.constructor().copy(this);
 },
 copy: function(e) {
  return this.min.copy(e.min), this.max.copy(e.max), this;
 },
 makeEmpty: function() {
  return this.min.x = this.min.y = 1 / 0, this.max.x = this.max.y = -1 / 0, this;
 },
 isEmpty: function() {
  return this.max.x < this.min.x || this.max.y < this.min.y;
 },
 getCenter: function(e) {
  return void 0 === e && (console.warn("Box2: .getCenter() target is now required"), 
  e = new Vector2()), this.isEmpty() ? e.set(0, 0) : e.addVectors(this.min, this.max).multiplyScalar(.5);
 },
 getSize: function(e) {
  return void 0 === e && (console.warn("Box2: .getSize() target is now required"), 
  e = new Vector2()), this.isEmpty() ? e.set(0, 0) : e.subVectors(this.max, this.min);
 },
 expandByPoint: function(e) {
  return this.min.min(e), this.max.max(e), this;
 },
 expandByVector: function(e) {
  return this.min.sub(e), this.max.add(e), this;
 },
 expandByScalar: function(e) {
  return this.min.addScalar(-e), this.max.addScalar(e), this;
 },
 containsPoint: function(e) {
  return !(e.x < this.min.x || e.x > this.max.x || e.y < this.min.y || e.y > this.max.y);
 },
 containsBox: function(e) {
  return this.min.x <= e.min.x && e.max.x <= this.max.x && this.min.y <= e.min.y && e.max.y <= this.max.y;
 },
 getParameter: function(e, t) {
  return void 0 === t && (console.warn("Box2: .getParameter() target is now required"), 
  t = new Vector2()), t.set((e.x - this.min.x) / (this.max.x - this.min.x), (e.y - this.min.y) / (this.max.y - this.min.y));
 },
 intersectsBox: function(e) {
  return !(e.max.x < this.min.x || e.min.x > this.max.x || e.max.y < this.min.y || e.min.y > this.max.y);
 },
 clampPoint: function(e, t) {
  return void 0 === t && (console.warn("Box2: .clampPoint() target is now required"), 
  t = new Vector2()), t.copy(e).clamp(this.min, this.max);
 },
 distanceToPoint: function(e) {
  return _vector.copy(e).clamp(this.min, this.max).sub(e).length();
 },
 intersect: function(e) {
  return this.min.max(e.min), this.max.min(e.max), this;
 },
 union: function(e) {
  return this.min.min(e.min), this.max.max(e.max), this;
 },
 translate: function(e) {
  return this.min.add(e), this.max.add(e), this;
 },
 equals: function(e) {
  return e.min.equals(this.min) && e.max.equals(this.max);
 }
});

var _startP = new Vector3(), _startEnd = new Vector3();

function Line3(e, t) {
 this.start = void 0 !== e ? e : new Vector3(), this.end = void 0 !== t ? t : new Vector3();
}

Object.assign(Line3.prototype, {
 set: function(e, t) {
  return this.start.copy(e), this.end.copy(t), this;
 },
 clone: function() {
  return new this.constructor().copy(this);
 },
 copy: function(e) {
  return this.start.copy(e.start), this.end.copy(e.end), this;
 },
 getCenter: function(e) {
  return void 0 === e && (console.warn("Line3: .getCenter() target is now required"), 
  e = new Vector3()), e.addVectors(this.start, this.end).multiplyScalar(.5);
 },
 delta: function(e) {
  return void 0 === e && (console.warn("Line3: .delta() target is now required"), 
  e = new Vector3()), e.subVectors(this.end, this.start);
 },
 distanceSq: function() {
  return this.start.distanceToSquared(this.end);
 },
 distance: function() {
  return this.start.distanceTo(this.end);
 },
 at: function(e, t) {
  return void 0 === t && (console.warn("Line3: .at() target is now required"), t = new Vector3()), 
  this.delta(t).multiplyScalar(e).add(this.start);
 },
 closestPointToPointParameter: function(e, t) {
  _startP.subVectors(e, this.start), _startEnd.subVectors(this.end, this.start);
  e = _startEnd.dot(_startEnd), e = _startEnd.dot(_startP) / e;
  return e = t ? _Math.clamp(e, 0, 1) : e;
 },
 closestPointToPoint: function(e, t, i) {
  e = this.closestPointToPointParameter(e, t);
  return void 0 === i && (console.warn("Line3: .closestPointToPoint() target is now required"), 
  i = new Vector3()), this.delta(i).multiplyScalar(e).add(this.start);
 },
 applyMatrix4: function(e) {
  return this.start.applyMatrix4(e), this.end.applyMatrix4(e), this;
 },
 equals: function(e) {
  return e.start.equals(this.start) && e.end.equals(this.end);
 }
});

var _matrix = new Matrix4(), _quaternion = new Quaternion();

function Euler(e, t, i, r) {
 this._x = e || 0, this._y = t || 0, this._z = i || 0, this._order = r || Euler.DefaultOrder;
}

function Vector4(e, t, i, r) {
 this.x = e || 0, this.y = t || 0, this.z = i || 0, this.w = void 0 !== r ? r : 1;
}

Euler.RotationOrders = [ "XYZ", "YZX", "ZXY", "XZY", "YXZ", "ZYX" ], Euler.DefaultOrder = "XYZ", 
Object.defineProperties(Euler.prototype, {
 x: {
  get: function() {
   return this._x;
  },
  set: function(e) {
   this._x = e, this._onChangeCallback();
  }
 },
 y: {
  get: function() {
   return this._y;
  },
  set: function(e) {
   this._y = e, this._onChangeCallback();
  }
 },
 z: {
  get: function() {
   return this._z;
  },
  set: function(e) {
   this._z = e, this._onChangeCallback();
  }
 },
 order: {
  get: function() {
   return this._order;
  },
  set: function(e) {
   this._order = e, this._onChangeCallback();
  }
 }
}), Object.assign(Euler.prototype, {
 isEuler: !0,
 set: function(e, t, i, r) {
  return this._x = e, this._y = t, this._z = i, this._order = r || this._order, 
  this._onChangeCallback(), this;
 },
 clone: function() {
  return new this.constructor(this._x, this._y, this._z, this._order);
 },
 copy: function(e) {
  return this._x = e._x, this._y = e._y, this._z = e._z, this._order = e._order, 
  this._onChangeCallback(), this;
 },
 setFromRotationMatrix: function(e, t, i) {
  var r = _Math.clamp, e = e.elements, s = e[0], a = e[4], n = e[8], o = e[1], h = e[5], u = e[9], l = e[2], _ = e[6], e = e[10];
  return "XYZ" === (t = t || this._order) ? (this._y = Math.asin(r(n, -1, 1)), Math.abs(n) < .9999999 ? (this._x = Math.atan2(-u, e), 
  this._z = Math.atan2(-a, s)) : (this._x = Math.atan2(_, h), this._z = 0)) : "YXZ" === t ? (this._x = Math.asin(-r(u, -1, 1)), 
  Math.abs(u) < .9999999 ? (this._y = Math.atan2(n, e), this._z = Math.atan2(o, h)) : (this._y = Math.atan2(-l, s), 
  this._z = 0)) : "ZXY" === t ? (this._x = Math.asin(r(_, -1, 1)), Math.abs(_) < .9999999 ? (this._y = Math.atan2(-l, e), 
  this._z = Math.atan2(-a, h)) : (this._y = 0, this._z = Math.atan2(o, s))) : "ZYX" === t ? (this._y = Math.asin(-r(l, -1, 1)), 
  Math.abs(l) < .9999999 ? (this._x = Math.atan2(_, e), this._z = Math.atan2(o, s)) : (this._x = 0, 
  this._z = Math.atan2(-a, h))) : "YZX" === t ? (this._z = Math.asin(r(o, -1, 1)), 
  Math.abs(o) < .9999999 ? (this._x = Math.atan2(-u, h), this._y = Math.atan2(-l, s)) : (this._x = 0, 
  this._y = Math.atan2(n, e))) : "XZY" === t ? (this._z = Math.asin(-r(a, -1, 1)), 
  Math.abs(a) < .9999999 ? (this._x = Math.atan2(_, h), this._y = Math.atan2(n, s)) : (this._x = Math.atan2(-u, e), 
  this._y = 0)) : console.warn("Euler: .setFromRotationMatrix() given unsupported order: " + t), 
  this._order = t, !1 !== i && this._onChangeCallback(), this;
 },
 setFromQuaternion: function(e, t, i) {
  return _matrix.makeRotationFromQuaternion(e), this.setFromRotationMatrix(_matrix, t, i);
 },
 setFromVector3: function(e, t) {
  return this.set(e.x, e.y, e.z, t || this._order);
 },
 reorder: function(e) {
  return _quaternion.setFromEuler(this), this.setFromQuaternion(_quaternion, e);
 },
 equals: function(e) {
  return e._x === this._x && e._y === this._y && e._z === this._z && e._order === this._order;
 },
 fromArray: function(e) {
  return this._x = e[0], this._y = e[1], this._z = e[2], void 0 !== e[3] && (this._order = e[3]), 
  this._onChangeCallback(), this;
 },
 toArray: function(e, t) {
  return (e = void 0 === e ? [] : e)[t = void 0 === t ? 0 : t] = this._x, e[t + 1] = this._y, 
  e[t + 2] = this._z, e[t + 3] = this._order, e;
 },
 toVector3: function(e) {
  return e ? e.set(this._x, this._y, this._z) : new Vector3(this._x, this._y, this._z);
 },
 _onChange: function(e) {
  return this._onChangeCallback = e, this;
 },
 _onChangeCallback: function() {}
}), Object.defineProperties(Vector4.prototype, {
 width: {
  get: function() {
   return this.z;
  },
  set: function(e) {
   this.z = e;
  }
 },
 height: {
  get: function() {
   return this.w;
  },
  set: function(e) {
   this.w = e;
  }
 }
}), Object.assign(Vector4.prototype, {
 isVector4: !0,
 set: function(e, t, i, r) {
  return this.x = e, this.y = t, this.z = i, this.w = r, this;
 },
 setScalar: function(e) {
  return this.x = e, this.y = e, this.z = e, this.w = e, this;
 },
 setX: function(e) {
  return this.x = e, this;
 },
 setY: function(e) {
  return this.y = e, this;
 },
 setZ: function(e) {
  return this.z = e, this;
 },
 setW: function(e) {
  return this.w = e, this;
 },
 setComponent: function(e, t) {
  switch (e) {
  case 0:
   this.x = t;
   break;

  case 1:
   this.y = t;
   break;

  case 2:
   this.z = t;
   break;

  case 3:
   this.w = t;
   break;

  default:
   throw new Error("index is out of range: " + e);
  }
  return this;
 },
 getComponent: function(e) {
  switch (e) {
  case 0:
   return this.x;

  case 1:
   return this.y;

  case 2:
   return this.z;

  case 3:
   return this.w;

  default:
   throw new Error("index is out of range: " + e);
  }
 },
 clone: function() {
  return new this.constructor(this.x, this.y, this.z, this.w);
 },
 copy: function(e) {
  return this.x = e.x, this.y = e.y, this.z = e.z, this.w = void 0 !== e.w ? e.w : 1, 
  this;
 },
 add: function(e, t) {
  return void 0 !== t ? (console.warn("Vector4: .add() now only accepts one argument. Use .addVectors( a, b ) instead."), 
  this.addVectors(e, t)) : (this.x += e.x, this.y += e.y, this.z += e.z, this.w += e.w, 
  this);
 },
 addScalar: function(e) {
  return this.x += e, this.y += e, this.z += e, this.w += e, this;
 },
 addVectors: function(e, t) {
  return this.x = e.x + t.x, this.y = e.y + t.y, this.z = e.z + t.z, this.w = e.w + t.w, 
  this;
 },
 addScaledVector: function(e, t) {
  return this.x += e.x * t, this.y += e.y * t, this.z += e.z * t, this.w += e.w * t, 
  this;
 },
 sub: function(e, t) {
  return void 0 !== t ? (console.warn("Vector4: .sub() now only accepts one argument. Use .subVectors( a, b ) instead."), 
  this.subVectors(e, t)) : (this.x -= e.x, this.y -= e.y, this.z -= e.z, this.w -= e.w, 
  this);
 },
 subScalar: function(e) {
  return this.x -= e, this.y -= e, this.z -= e, this.w -= e, this;
 },
 subVectors: function(e, t) {
  return this.x = e.x - t.x, this.y = e.y - t.y, this.z = e.z - t.z, this.w = e.w - t.w, 
  this;
 },
 multiplyScalar: function(e) {
  return this.x *= e, this.y *= e, this.z *= e, this.w *= e, this;
 },
 applyMatrix4: function(e) {
  var t = this.x, i = this.y, r = this.z, s = this.w, e = e.elements;
  return this.x = e[0] * t + e[4] * i + e[8] * r + e[12] * s, this.y = e[1] * t + e[5] * i + e[9] * r + e[13] * s, 
  this.z = e[2] * t + e[6] * i + e[10] * r + e[14] * s, this.w = e[3] * t + e[7] * i + e[11] * r + e[15] * s, 
  this;
 },
 divideScalar: function(e) {
  return this.multiplyScalar(1 / e);
 },
 setAxisAngleFromQuaternion: function(e) {
  this.w = 2 * Math.acos(e.w);
  var t = Math.sqrt(1 - e.w * e.w);
  return t < 1e-4 ? (this.x = 1, this.y = 0, this.z = 0) : (this.x = e.x / t, this.y = e.y / t, 
  this.z = e.z / t), this;
 },
 setAxisAngleFromRotationMatrix: function(e) {
  var t, i, r, s, a, n, o, h, u, l, e = e.elements, _ = e[0], c = e[4], d = e[8], m = e[1], g = e[5], p = e[9], f = e[2], y = e[6], e = e[10];
  return Math.abs(c - m) < .01 && Math.abs(d - f) < .01 && Math.abs(p - y) < .01 ? Math.abs(c + m) < .1 && Math.abs(d + f) < .1 && Math.abs(p + y) < .1 && Math.abs(_ + g + e - 3) < .1 ? this.set(1, 0, 0, 0) : (s = Math.PI, 
  n = (e + 1) / 2, o = (c + m) / 4, h = (d + f) / 4, u = (p + y) / 4, (a = (g + 1) / 2) < (l = (_ + 1) / 2) && n < l ? r = l < .01 ? (t = 0, 
  i = .707106781) : (i = o / (t = Math.sqrt(l)), h / t) : n < a ? r = a < .01 ? (i = 0, 
  t = .707106781) : (t = o / (i = Math.sqrt(a)), u / i) : n < .01 ? (i = t = .707106781, 
  r = 0) : (t = h / (r = Math.sqrt(n)), i = u / r), this.set(t, i, r, s)) : (l = Math.sqrt((y - p) * (y - p) + (d - f) * (d - f) + (m - c) * (m - c)), 
  Math.abs(l) < .001 && (l = 1), this.x = (y - p) / l, this.y = (d - f) / l, this.z = (m - c) / l, 
  this.w = Math.acos((_ + g + e - 1) / 2)), this;
 },
 min: function(e) {
  return this.x = Math.min(this.x, e.x), this.y = Math.min(this.y, e.y), this.z = Math.min(this.z, e.z), 
  this.w = Math.min(this.w, e.w), this;
 },
 max: function(e) {
  return this.x = Math.max(this.x, e.x), this.y = Math.max(this.y, e.y), this.z = Math.max(this.z, e.z), 
  this.w = Math.max(this.w, e.w), this;
 },
 clamp: function(e, t) {
  return this.x = Math.max(e.x, Math.min(t.x, this.x)), this.y = Math.max(e.y, Math.min(t.y, this.y)), 
  this.z = Math.max(e.z, Math.min(t.z, this.z)), this.w = Math.max(e.w, Math.min(t.w, this.w)), 
  this;
 },
 clampScalar: function(e, t) {
  return this.x = Math.max(e, Math.min(t, this.x)), this.y = Math.max(e, Math.min(t, this.y)), 
  this.z = Math.max(e, Math.min(t, this.z)), this.w = Math.max(e, Math.min(t, this.w)), 
  this;
 },
 clampLength: function(e, t) {
  var i = this.length();
  return this.divideScalar(i || 1).multiplyScalar(Math.max(e, Math.min(t, i)));
 },
 floor: function() {
  return this.x = Math.floor(this.x), this.y = Math.floor(this.y), this.z = Math.floor(this.z), 
  this.w = Math.floor(this.w), this;
 },
 ceil: function() {
  return this.x = Math.ceil(this.x), this.y = Math.ceil(this.y), this.z = Math.ceil(this.z), 
  this.w = Math.ceil(this.w), this;
 },
 round: function() {
  return this.x = Math.round(this.x), this.y = Math.round(this.y), this.z = Math.round(this.z), 
  this.w = Math.round(this.w), this;
 },
 roundToZero: function() {
  return this.x = this.x < 0 ? Math.ceil(this.x) : Math.floor(this.x), this.y = this.y < 0 ? Math.ceil(this.y) : Math.floor(this.y), 
  this.z = this.z < 0 ? Math.ceil(this.z) : Math.floor(this.z), this.w = this.w < 0 ? Math.ceil(this.w) : Math.floor(this.w), 
  this;
 },
 negate: function() {
  return this.x = -this.x, this.y = -this.y, this.z = -this.z, this.w = -this.w, 
  this;
 },
 dot: function(e) {
  return this.x * e.x + this.y * e.y + this.z * e.z + this.w * e.w;
 },
 lengthSq: function() {
  return this.x * this.x + this.y * this.y + this.z * this.z + this.w * this.w;
 },
 length: function() {
  return Math.sqrt(this.x * this.x + this.y * this.y + this.z * this.z + this.w * this.w);
 },
 manhattanLength: function() {
  return Math.abs(this.x) + Math.abs(this.y) + Math.abs(this.z) + Math.abs(this.w);
 },
 normalize: function() {
  return this.divideScalar(this.length() || 1);
 },
 setLength: function(e) {
  return this.normalize().multiplyScalar(e);
 },
 lerp: function(e, t) {
  return this.x += (e.x - this.x) * t, this.y += (e.y - this.y) * t, this.z += (e.z - this.z) * t, 
  this.w += (e.w - this.w) * t, this;
 },
 lerpVectors: function(e, t, i) {
  return this.subVectors(t, e).multiplyScalar(i).add(e);
 },
 equals: function(e) {
  return e.x === this.x && e.y === this.y && e.z === this.z && e.w === this.w;
 },
 fromArray: function(e, t) {
  return this.x = e[t = void 0 === t ? 0 : t], this.y = e[t + 1], this.z = e[t + 2], 
  this.w = e[t + 3], this;
 },
 toArray: function(e, t) {
  return (e = void 0 === e ? [] : e)[t = void 0 === t ? 0 : t] = this.x, e[t + 1] = this.y, 
  e[t + 2] = this.z, e[t + 3] = this.w, e;
 },
 fromBufferAttribute: function(e, t, i) {
  return void 0 !== i && console.warn("Vector4: offset has been removed from .fromBufferAttribute()."), 
  this.x = e.getX(t), this.y = e.getY(t), this.z = e.getZ(t), this.w = e.getW(t), 
  this;
 }
});

var _colorKeywords = {
 aliceblue: 15792383,
 antiquewhite: 16444375,
 aqua: 65535,
 aquamarine: 8388564,
 azure: 15794175,
 beige: 16119260,
 bisque: 16770244,
 black: 0,
 blanchedalmond: 16772045,
 blue: 255,
 blueviolet: 9055202,
 brown: 10824234,
 burlywood: 14596231,
 cadetblue: 6266528,
 chartreuse: 8388352,
 chocolate: 13789470,
 coral: 16744272,
 cornflowerblue: 6591981,
 cornsilk: 16775388,
 crimson: 14423100,
 cyan: 65535,
 darkblue: 139,
 darkcyan: 35723,
 darkgoldenrod: 12092939,
 darkgray: 11119017,
 darkgreen: 25600,
 darkgrey: 11119017,
 darkkhaki: 12433259,
 darkmagenta: 9109643,
 darkolivegreen: 5597999,
 darkorange: 16747520,
 darkorchid: 10040012,
 darkred: 9109504,
 darksalmon: 15308410,
 darkseagreen: 9419919,
 darkslateblue: 4734347,
 darkslategray: 3100495,
 darkslategrey: 3100495,
 darkturquoise: 52945,
 darkviolet: 9699539,
 deeppink: 16716947,
 deepskyblue: 49151,
 dimgray: 6908265,
 dimgrey: 6908265,
 dodgerblue: 2003199,
 firebrick: 11674146,
 floralwhite: 16775920,
 forestgreen: 2263842,
 fuchsia: 16711935,
 gainsboro: 14474460,
 ghostwhite: 16316671,
 gold: 16766720,
 goldenrod: 14329120,
 gray: 8421504,
 green: 32768,
 greenyellow: 11403055,
 grey: 8421504,
 honeydew: 15794160,
 hotpink: 16738740,
 indianred: 13458524,
 indigo: 4915330,
 ivory: 16777200,
 khaki: 15787660,
 lavender: 15132410,
 lavenderblush: 16773365,
 lawngreen: 8190976,
 lemonchiffon: 16775885,
 lightblue: 11393254,
 lightcoral: 15761536,
 lightcyan: 14745599,
 lightgoldenrodyellow: 16448210,
 lightgray: 13882323,
 lightgreen: 9498256,
 lightgrey: 13882323,
 lightpink: 16758465,
 lightsalmon: 16752762,
 lightseagreen: 2142890,
 lightskyblue: 8900346,
 lightslategray: 7833753,
 lightslategrey: 7833753,
 lightsteelblue: 11584734,
 lightyellow: 16777184,
 lime: 65280,
 limegreen: 3329330,
 linen: 16445670,
 magenta: 16711935,
 maroon: 8388608,
 mediumaquamarine: 6737322,
 mediumblue: 205,
 mediumorchid: 12211667,
 mediumpurple: 9662683,
 mediumseagreen: 3978097,
 mediumslateblue: 8087790,
 mediumspringgreen: 64154,
 mediumturquoise: 4772300,
 mediumvioletred: 13047173,
 midnightblue: 1644912,
 mintcream: 16121850,
 mistyrose: 16770273,
 moccasin: 16770229,
 navajowhite: 16768685,
 navy: 128,
 oldlace: 16643558,
 olive: 8421376,
 olivedrab: 7048739,
 orange: 16753920,
 orangered: 16729344,
 orchid: 14315734,
 palegoldenrod: 15657130,
 palegreen: 10025880,
 paleturquoise: 11529966,
 palevioletred: 14381203,
 papayawhip: 16773077,
 peachpuff: 16767673,
 peru: 13468991,
 pink: 16761035,
 plum: 14524637,
 powderblue: 11591910,
 purple: 8388736,
 rebeccapurple: 6697881,
 red: 16711680,
 rosybrown: 12357519,
 royalblue: 4286945,
 saddlebrown: 9127187,
 salmon: 16416882,
 sandybrown: 16032864,
 seagreen: 3050327,
 seashell: 16774638,
 sienna: 10506797,
 silver: 12632256,
 skyblue: 8900331,
 slateblue: 6970061,
 slategray: 7372944,
 slategrey: 7372944,
 snow: 16775930,
 springgreen: 65407,
 steelblue: 4620980,
 tan: 13808780,
 teal: 32896,
 thistle: 14204888,
 tomato: 16737095,
 turquoise: 4251856,
 violet: 15631086,
 wheat: 16113331,
 white: 16777215,
 whitesmoke: 16119285,
 yellow: 16776960,
 yellowgreen: 10145074
}, _hslA = {
 h: 0,
 s: 0,
 l: 0
}, _hslB = {
 h: 0,
 s: 0,
 l: 0
};

function Color(e, t, i) {
 return void 0 === t && void 0 === i ? this.set(e) : this.setRGB(e, t, i);
}

function hue2rgb(e, t, i) {
 return i < 0 && (i += 1), 1 < i && --i, i < 1 / 6 ? e + 6 * (t - e) * i : i < .5 ? t : i < 2 / 3 ? e + 6 * (t - e) * (2 / 3 - i) : e;
}

function SRGBToLinear(e) {
 return e < .04045 ? .0773993808 * e : Math.pow(.9478672986 * e + .0521327014, 2.4);
}

function LinearToSRGB(e) {
 return e < .0031308 ? 12.92 * e : 1.055 * Math.pow(e, .41666) - .055;
}

Object.assign(Color.prototype, {
 isColor: !0,
 r: 1,
 g: 1,
 b: 1,
 set: function(e) {
  return e && e.isColor ? this.copy(e) : "number" == typeof e ? this.setHex(e) : "string" == typeof e && this.setStyle(e), 
  this;
 },
 setScalar: function(e) {
  return this.r = e, this.g = e, this.b = e, this;
 },
 setHex: function(e) {
  return e = Math.floor(e), this.r = (e >> 16 & 255) / 255, this.g = (e >> 8 & 255) / 255, 
  this.b = (255 & e) / 255, this;
 },
 setRGB: function(e, t, i) {
  return this.r = e, this.g = t, this.b = i, this;
 },
 setHSL: function(e, t, i) {
  return e = _Math.euclideanModulo(e, 1), t = _Math.clamp(t, 0, 1), i = _Math.clamp(i, 0, 1), 
  0 === t ? this.r = this.g = this.b = i : (this.r = hue2rgb(t = 2 * i - (i = i <= .5 ? i * (1 + t) : i + t - i * t), i, e + 1 / 3), 
  this.g = hue2rgb(t, i, e), this.b = hue2rgb(t, i, e - 1 / 3)), this;
 },
 setStyle: function(t) {
  function e(e) {
   void 0 !== e && parseFloat(e) < 1 && console.warn("Color: Alpha component of " + t + " will be ignored.");
  }
  if (h = /^((?:rgb|hsl)a?)\(\s*([^\)]*)\)/.exec(t)) {
   var i, r, s, a, n = h[1], o = h[2];
   switch (n) {
   case "rgb":
   case "rgba":
    if (i = /^(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*(,\s*([0-9]*\.?[0-9]+)\s*)?$/.exec(o)) return this.r = Math.min(255, parseInt(i[1], 10)) / 255, 
    this.g = Math.min(255, parseInt(i[2], 10)) / 255, this.b = Math.min(255, parseInt(i[3], 10)) / 255, 
    e(i[5]), this;
    if (i = /^(\d+)\%\s*,\s*(\d+)\%\s*,\s*(\d+)\%\s*(,\s*([0-9]*\.?[0-9]+)\s*)?$/.exec(o)) return this.r = Math.min(100, parseInt(i[1], 10)) / 100, 
    this.g = Math.min(100, parseInt(i[2], 10)) / 100, this.b = Math.min(100, parseInt(i[3], 10)) / 100, 
    e(i[5]), this;
    break;

   case "hsl":
   case "hsla":
    if (i = /^([0-9]*\.?[0-9]+)\s*,\s*(\d+)\%\s*,\s*(\d+)\%\s*(,\s*([0-9]*\.?[0-9]+)\s*)?$/.exec(o)) return r = parseFloat(i[1]) / 360, 
    s = parseInt(i[2], 10) / 100, a = parseInt(i[3], 10) / 100, e(i[5]), this.setHSL(r, s, a);
   }
  } else if (h = /^\#([A-Fa-f0-9]+)$/.exec(t)) {
   var n = h[1], h = n.length;
   if (3 === h) return this.r = parseInt(n.charAt(0) + n.charAt(0), 16) / 255, this.g = parseInt(n.charAt(1) + n.charAt(1), 16) / 255, 
   this.b = parseInt(n.charAt(2) + n.charAt(2), 16) / 255, this;
   if (6 === h) return this.r = parseInt(n.charAt(0) + n.charAt(1), 16) / 255, this.g = parseInt(n.charAt(2) + n.charAt(3), 16) / 255, 
   this.b = parseInt(n.charAt(4) + n.charAt(5), 16) / 255, this;
  }
  return t && 0 < t.length ? this.setColorName(t) : this;
 },
 setColorName: function(e) {
  var t = _colorKeywords[e];
  return void 0 !== t ? this.setHex(t) : console.warn("Color: Unknown color " + e), 
  this;
 },
 clone: function() {
  return new this.constructor(this.r, this.g, this.b);
 },
 copy: function(e) {
  return this.r = e.r, this.g = e.g, this.b = e.b, this;
 },
 copyGammaToLinear: function(e, t) {
  return void 0 === t && (t = 2), this.r = Math.pow(e.r, t), this.g = Math.pow(e.g, t), 
  this.b = Math.pow(e.b, t), this;
 },
 copyLinearToGamma: function(e, t) {
  t = 0 < (t = void 0 === t ? 2 : t) ? 1 / t : 1;
  return this.r = Math.pow(e.r, t), this.g = Math.pow(e.g, t), this.b = Math.pow(e.b, t), 
  this;
 },
 convertGammaToLinear: function(e) {
  return this.copyGammaToLinear(this, e), this;
 },
 convertLinearToGamma: function(e) {
  return this.copyLinearToGamma(this, e), this;
 },
 copySRGBToLinear: function(e) {
  return this.r = SRGBToLinear(e.r), this.g = SRGBToLinear(e.g), this.b = SRGBToLinear(e.b), 
  this;
 },
 copyLinearToSRGB: function(e) {
  return this.r = LinearToSRGB(e.r), this.g = LinearToSRGB(e.g), this.b = LinearToSRGB(e.b), 
  this;
 },
 convertSRGBToLinear: function() {
  return this.copySRGBToLinear(this), this;
 },
 convertLinearToSRGB: function() {
  return this.copyLinearToSRGB(this), this;
 },
 getHex: function() {
  return 255 * this.r << 16 ^ 255 * this.g << 8 ^ 255 * this.b << 0;
 },
 getHexString: function() {
  return ("000000" + this.getHex().toString(16)).slice(-6);
 },
 getHSL: function(e) {
  void 0 === e && (console.warn("Color: .getHSL() target is now required"), e = {
   h: 0,
   s: 0,
   l: 0
  });
  var t, i = this.r, r = this.g, s = this.b, a = Math.max(i, r, s), n = Math.min(i, r, s), o = (n + a) / 2;
  if (n === a) u = t = 0; else {
   var h = a - n, u = o <= .5 ? h / (a + n) : h / (2 - a - n);
   switch (a) {
   case i:
    t = (r - s) / h + (r < s ? 6 : 0);
    break;

   case r:
    t = (s - i) / h + 2;
    break;

   case s:
    t = (i - r) / h + 4;
   }
   t /= 6;
  }
  return e.h = t, e.s = u, e.l = o, e;
 },
 getStyle: function() {
  return "rgb(" + (255 * this.r | 0) + "," + (255 * this.g | 0) + "," + (255 * this.b | 0) + ")";
 },
 offsetHSL: function(e, t, i) {
  return this.getHSL(_hslA), _hslA.h += e, _hslA.s += t, _hslA.l += i, this.setHSL(_hslA.h, _hslA.s, _hslA.l), 
  this;
 },
 add: function(e) {
  return this.r += e.r, this.g += e.g, this.b += e.b, this;
 },
 addColors: function(e, t) {
  return this.r = e.r + t.r, this.g = e.g + t.g, this.b = e.b + t.b, this;
 },
 addScalar: function(e) {
  return this.r += e, this.g += e, this.b += e, this;
 },
 sub: function(e) {
  return this.r = Math.max(0, this.r - e.r), this.g = Math.max(0, this.g - e.g), 
  this.b = Math.max(0, this.b - e.b), this;
 },
 multiply: function(e) {
  return this.r *= e.r, this.g *= e.g, this.b *= e.b, this;
 },
 multiplyScalar: function(e) {
  return this.r *= e, this.g *= e, this.b *= e, this;
 },
 lerp: function(e, t) {
  return this.r += (e.r - this.r) * t, this.g += (e.g - this.g) * t, this.b += (e.b - this.b) * t, 
  this;
 },
 lerpHSL: function(e, t) {
  this.getHSL(_hslA), e.getHSL(_hslB);
  var e = _Math.lerp(_hslA.h, _hslB.h, t), i = _Math.lerp(_hslA.s, _hslB.s, t), t = _Math.lerp(_hslA.l, _hslB.l, t);
  return this.setHSL(e, i, t), this;
 },
 equals: function(e) {
  return e.r === this.r && e.g === this.g && e.b === this.b;
 },
 fromArray: function(e, t) {
  return this.r = e[t = void 0 === t ? 0 : t], this.g = e[t + 1], this.b = e[t + 2], 
  this;
 },
 toArray: function(e, t) {
  return (e = void 0 === e ? [] : e)[t = void 0 === t ? 0 : t] = this.r, e[t + 1] = this.g, 
  e[t + 2] = this.b, e;
 },
 toJSON: function() {
  return this.getHex();
 }
}), Color.NAMES = _colorKeywords;

var Cache = {
 enabled: !1,
 files: {},
 add: function(e, t) {
  !1 !== this.enabled && (this.files[e] = t);
 },
 get: function(e) {
  if (!1 !== this.enabled) return this.files[e];
 },
 remove: function(e) {
  delete this.files[e];
 },
 clear: function() {
  this.files = {};
 }
}, ImageCache = {
 cached: new Map(),
 incoming: new Map(),
 verbose: !1,
 deliver: function(t, i) {
  this.verbose && console.log("ImageCache deliver", this.cacheid, t);
  var e = this.cached.get(t);
  if (void 0 !== e) this.verbose && console.log("ImageCache HAS", t), i(t, e, !1); else {
   e = this.incoming.get(t);
   if (void 0 !== e) this.verbose && console.log("ImageCache EXPECTING", t), e.push(i); else {
    this.verbose && console.log("ImageCache does NOT HAVE -- requesting", t), this.incoming.set(t, [ i ]);
    let e = new Image();
    e.onload = () => {
     this.image_loaded(t, e);
    }, e.onerror = () => {
     this.image_loaded(t, null);
    }, e.src = t;
   }
  }
 },
 image_loaded: function(t, i) {
  i ? this.verbose && console.log("ImageCache image_loaded success", t) : console.error("ImageCache image_loaded error loading", t), 
  this.cached.set(t, i);
  var r = this.incoming.get(t);
  for (let e = 0; e < r.length; ++e) r[e](t, i, !0);
  this.incoming.delete(t);
 },
 remove: function(e) {
  this.cached.delete(e);
 },
 clear: function() {
  this.cached.clear();
 }
};

class TextureCache {
 constructor() {
  this.tex_cache = new Map(), this.tex_precache = new Map(), this.verbose = !1;
 }
 deliver(e, t, i, r) {
  var s = this.tex_cache.get(e);
  void 0 !== s ? (this.verbose && console.log("TextureCache HAS", e), s && t(s)) : void 0 !== (s = this.tex_precache.get(e)) ? (this.verbose && console.log("TextureCache url is incoming -- appending callback", e), 
  s.array.push(t)) : (this.tex_precache.set(e, {
   img2tex: i,
   delayed: r,
   array: [ t ]
  }), ImageCache.deliver(e, this.image_loaded.bind(this)));
 }
 image_loaded(e, t, i) {
  var r = this.tex_precache.get(e), s = t ? r.img2tex(t) : null;
  if (this.tex_cache.set(e, s), s) for (let e = 0; e < r.array.length; ++e) r.array[e](s);
  s && i && r.delayed(), this.tex_precache.delete(e);
 }
 remove(e) {
  this.tex_cache.delete(e);
 }
 clear() {
  this.tex_cache.clear();
 }
}

class LoadingManager {
 constructor(e, t, i) {
  var r = this, s = !1, a = 0, n = 0;
  this.onStart = void 0, this.onLoad = e, this.onProgress = t, this.onError = i, 
  this.itemStart = function(e) {
   n++, !1 === s && void 0 !== r.onStart && r.onStart(e, a, n), s = !0;
  }, this.itemEnd = function(e) {
   a++, void 0 !== r.onProgress && r.onProgress(e, a, n), a === n && (s = !1, void 0 !== r.onLoad) && r.onLoad(e, a, n);
  }, this.itemError = function(e) {
   void 0 !== r.onError && r.onError(e);
  };
 }
}

class XHRLoader {
 constructor(e = new LoadingManager(), t = "") {
  this.manager = e, this.responseType = t;
 }
 load(i, r, t, s) {
  void 0 !== this.path && (i = this.path + i);
  var e, a = this, n = Cache.get(i);
  return void 0 !== n ? (r && setTimeout(function() {
   r(n);
  }, 0), n) : ((e = new XMLHttpRequest()).overrideMimeType("text/plain"), e.responseType = this.responseType, 
  e.open("GET", i, !0), e.addEventListener("load", function(e) {
   var t = e.target.response;
   Cache.add(i, t), 200 === this.status || 0 === this.status ? (r && r(t), a.manager.itemEnd(i)) : (s && s(e), 
   a.manager.itemError(i));
  }, !1), void 0 !== t && e.addEventListener("progress", function(e) {
   t(e);
  }, !1), e.addEventListener("error", function(e) {
   s && s(e), a.manager.itemError(i);
  }, !1), void 0 !== this.responseType && (e.responseType = this.responseType), 
  void 0 !== this.withCredentials && (e.withCredentials = this.withCredentials), 
  e.send(null), a.manager.itemStart(i), e);
 }
 setPath(e) {
  this.path = e;
 }
 setResponseType(e) {
  this.responseType = e;
 }
 setWithCredentials(e) {
  this.withCredentials = e;
 }
 extractUrlBase(e) {
  e = e.split("/");
  return 1 === e.length ? "./" : (e.pop(), e.join("/") + "/");
 }
}

class ShaderLoader {
 static sAllPrograms = new Set();
 constructor(e = new LoadingManager(), t) {
  this._xhrLoader = new XHRLoader(e), this._pending_urls = [], this._programs = {}, 
  this._executor = this.executor, this._queue = [], this._inProgress = !1;
 }
 addUrls(...e) {
  for (var t = 0; t < e.length; t++) "/" !== e[t].slice(-1) && (e[t] += "/");
  this._pending_urls = [ ...new Set([].concat(this._pending_urls, e)) ];
 }
 loadProgramList(h, u, t) {
  var l = this;
  this._executor(function(s) {
   const a = l._pending_urls.length;
   for (var n = 0, e = 0; e < a; e++) {
    const o = l._pending_urls[e];
    l._xhrLoader.load(o + "programs.json", function(e) {
     var t, i = JSON.parse(e);
     for (t in i) {
      var r = l._programs[t];
      void 0 === r && (r = i[t], l._programs[t] = r), void 0 === r.urls ? r.urls = [ o ] : r.urls.push(o);
     }
     n++, void 0 !== u && (e = new ProgressEvent("ProgramListLoaded", {
      lengthComputable: !0,
      loaded: n,
      total: a
     }), u(e)), a === n && (void 0 !== h && h(l._programs), s());
    }, void 0, function(e) {
     n++, void 0 !== t && t(e), void 0 !== u && (e = new ProgressEvent("ProgramListLoaded", {
      lengthComputable: !0,
      loaded: n,
      total: a
     }), u(e)), a === n && (void 0 !== h && h(l._programs), s());
    });
   }
   l._pending_urls = [];
  });
 }
 loadProgramSources(l, _, c, d) {
  0 < this._pending_urls.length && this.loadProgramList();
  var m = this;
  this._executor(function(i) {
   var e = m._programs[l];
   if (void 0 === e) d(), i(); else {
    var t = e.shaders, r = Object.keys(t), s = 0;
    const h = r.length;
    for (var a = {
     sources: {}
    }, n = 0; n < r.length; n++) {
     const u = r[n];
     var o = e.urls[0] + t[u];
     m._xhrLoader.load(o, function(e) {
      var t;
      s++, ShaderLoader.sAllPrograms.add(l), void 0 !== c && (t = new ProgressEvent("ShaderSourceLoaded", {
       lengthComputable: !0,
       loaded: s,
       total: h
      }), c(t)), a.id = l, a.sources[u] = e, s === h && (void 0 !== _ && _(a), i());
     }, void 0, function(e) {
      var t;
      s++, void 0 !== c && (t = new ProgressEvent("ShaderSourceLoaded", {
       lengthComputable: !0,
       loaded: s,
       total: h
      }), c(t)), void 0 !== d && d(e), s === h && (void 0 !== _ && _(programSources), 
      i());
     });
    }
   }
  });
 }
 loadMultipleProgramSources(e, i, r, s) {
  var a = 0;
  const n = e.length;
  for (var o = [], t = function(e) {
   a++, o.push(e), void 0 !== r && (e = new ProgressEvent("ProgramSourcesLoaded", {
    lengthComputable: !0,
    loaded: a,
    total: n
   }), r(e)), void 0 !== i && a === n && i(o);
  }, h = function(e) {
   var t;
   a++, void 0 !== r && (t = new ProgressEvent("ProgramSourcesLoaded", {
    lengthComputable: !0,
    loaded: a,
    total: n
   }), r(t)), null != s && s(e), void 0 !== i && a === n && i(o);
  }, u = 0; u < n; u++) this.loadProgramSources(e[u], t, void 0, h);
 }
 get programList() {
  return Object.keys(this._programs);
 }
 resolvePrograms(e, t = !0) {
  var i, r = {};
  for (i of e) {
   var s = structuredClone(this._programs[i]);
   t && delete s.urls, r[i] = s;
  }
  return r;
 }
 executor(e, ...t) {
  const i = this;
  var r;
  this._queue.push({
   exec: e,
   args: t
  }), !1 === this._inProgress && (this._inProgress = !0, (r = function() {
   var e;
   0 < i._queue.length ? (e = i._queue.shift()).exec(r, e.args) : i._inProgress = !1;
  })());
 }
}

class ImageLoader {
 constructor(e) {
  this.manager = e || new LoadingManager();
 }
 load(t, i, r, s) {
  var a = this, e = (void 0 !== this.path && (t = this.path + t), this.manager.itemStart(t), 
  Cache.get(t));
  if (void 0 !== e) return i ? setTimeout(function() {
   i(e), a.manager.itemEnd(t);
  }, 0) : a.manager.itemEnd(t), e;
  var n = new Image();
  n.src = t, n.addEventListener("load", function(e) {
   Cache.add(t, this), void 0 !== i && i(n), a.manager.itemEnd(t);
  }), n.addEventListener("progress", function(e) {
   void 0 !== r && r(e);
  }), n.addEventListener("error", function(e) {
   s && s(e), a.manager.itemError(t);
  }), void 0 !== this.crossOrigin && (n.crossOrigin = this.crossOrigin);
 }
 setCrossOrigin(e) {
  this.crossOrigin = e;
 }
 setPath(e) {
  this.path = e;
 }
}

class UpdateListener {
 constructor(e, t, i, r) {
  this._onObjectUpdate = e || function() {}, this._onHierarchyUpdate = t || function() {}, 
  this._onMaterialUpdate = i || function() {}, this._onGeometryUpdate = r || function() {};
 }
 get objectUpdate() {
  return this._onObjectUpdate;
 }
 get hierarchyUpdate() {
  return this._onHierarchyUpdate;
 }
 get materialUpdate() {
  return this._onMaterialUpdate;
 }
 get geometryUpdate() {
  return this._onGeometryUpdate;
 }
 set objectUpdate(e) {
  this._onObjectUpdate = e;
 }
 set hierarchyUpdate(e) {
  this._onHierarchyUpdate = e;
 }
 set materialUpdate(e) {
  this._onMaterialUpdate = e;
 }
 set geometryUpdate(e) {
  this._onGeometryUpdate = e;
 }
}

class BufferAttribute {
 static TARGET = {
  ARRAY_BUFFER: 0,
  ELEMENT_ARRAY_BUFFER: 1,
  COPY_READ_BUFFER: 2,
  COPY_WRITE_BUFFER: 3,
  TRANSFORM_FEEDBACK_BUFFER: 4,
  UNIFORM_BUFFER: 5,
  PIXEL_PACK_BUFFER: 6,
  PIXEL_UNPACK_BUFFER: 7
 };
 static DRAW_TYPE = {
  STATIC: 0,
  STREAMING: 1,
  DYNAMIC: 2
 };
 constructor(e, t, i = 0, r = {}) {
  this._array = e, this._itemSize = t, this._divisor = i, this._dirty = !0, this._drawType = BufferAttribute.DRAW_TYPE.STATIC, 
  this._update = !1, this.target = void 0 !== r.target ? r.target : BufferAttribute.TARGET.ARRAY_BUFFER, 
  this.idleTime = 0, this._locations = new Array();
 }
 count() {
  return this._array.length / this._itemSize;
 }
 set array(e) {
  this._array.length == e.length ? this._update = !0 : this._dirty = !0, this._array = e;
 }
 set itemSize(e) {
  this._itemSize = e, this._dirty = !0;
 }
 set dirty(e) {
  this._dirty = e;
 }
 set drawType(e) {
  this._drawType = e;
 }
 get array() {
  return this._array;
 }
 get itemSize() {
  return this._itemSize;
 }
 get size() {
  return this.array.byteLength;
 }
 get dirty() {
  return this._dirty;
 }
 get update() {
  return this._update;
 }
 set update(e) {
  this._update = e;
 }
 get divisor() {
  return this._divisor;
 }
 set divisor(e) {
  this._divisor = e;
 }
 get drawType() {
  return this._drawType;
 }
 get target() {
  return this._target;
 }
 set target(e) {
  this._target = e;
 }
 get locations() {
  return this._locations;
 }
 set locations(e) {
  this._locations = e;
 }
 update() {
  this._update = !0;
 }
}

function Int8Attribute(e, t, i = 0) {
 return new BufferAttribute(new Int8Array(e), t, i);
}

function Uint8Attribute(e, t, i = 0) {
 return new BufferAttribute(new Uint8Array(e), t, i);
}

function Uint8ClampedAttribute(e, t, i = 0) {
 return new BufferAttribute(new Uint8ClampedArray(e), t, i);
}

function Int16Attribute(e, t, i = 0) {
 return new BufferAttribute(new Int16Array(e), t, i);
}

function Uint16Attribute(e, t, i = 0) {
 return new BufferAttribute(new Uint16Array(e), t, i);
}

function Int32Attribute(e, t, i = 0) {
 return new BufferAttribute(new Int32Array(e), t, i);
}

function Uint32Attribute(e, t, i = 0) {
 return new BufferAttribute(new Uint32Array(e), t, i);
}

function Float32Attribute(e, t, i = 0) {
 return new BufferAttribute(new Float32Array(e), t, i);
}

function Float64Attribute(e, t, i = 0) {
 return new BufferAttribute(new Float64Array(e), t, i);
}

class GLAttributeManager {
 constructor(e) {
  this._gl = e, this._cached_buffers = new Map(), this.DRAW_TYPE = new Map([ [ BufferAttribute.DRAW_TYPE.STATIC, e.STATIC_DRAW ], [ BufferAttribute.DRAW_TYPE.STREAMING, e.STREAM_DRAW ], [ BufferAttribute.DRAW_TYPE.DYNAMIC, e.DYNAMIC_DRAW ] ]), 
  this.TARGET = new Map([ [ BufferAttribute.TARGET.ARRAY_BUFFER, e.ARRAY_BUFFER ], [ BufferAttribute.TARGET.ELEMENT_ARRAY_BUFFER, e.ELEMENT_ARRAY_BUFFER ], [ BufferAttribute.TARGET.COPY_READ_BUFFER, e.COPY_READ_BUFFER ], [ BufferAttribute.TARGET.COPY_WRITE_BUFFER, e.COPY_WRITE_BUFFER ], [ BufferAttribute.TARGET.TRANSFORM_FEEDBACK_BUFFER, e.TRANSFORM_FEEDBACK_BUFFER ], [ BufferAttribute.TARGET.UNIFORM_BUFFER, e.UNIFORM_BUFFER ], [ BufferAttribute.TARGET.PIXEL_PACK_BUFFER, e.PIXEL_PACK_BUFFER ], [ BufferAttribute.TARGET.PIXEL_UNPACK_BUFFER, e.PIXEL_UNPACK_BUFFER ] ]);
 }
 _createGLBuffer(e) {
  var t = e.target ? this.TARGET.get(e.target) : this._gl.ARRAY_BUFFER, i = e.size, r = this.DRAW_TYPE.get(e.drawType), s = this._gl.createBuffer();
  return this._gl.bindBuffer(t, s), this._gl.bufferData(t, i, r), this._gl.bindBuffer(t, null), 
  this._cached_buffers.set(e, s), s;
 }
 _updateAttribute(e) {
  var t = this._cached_buffers.get(e), i = e.target ? this.TARGET.get(e.target) : this._gl.ARRAY_BUFFER;
  (e.dirty || e._update) && (this._gl.bindBuffer(i, t), e.dirty && (t = this.DRAW_TYPE.get(e.drawType), 
  this._gl.bufferData(i, e.size, t), e.dirty = !1), this._gl.bufferSubData(i, 0, e.array, 0, 0), 
  this._gl.bindBuffer(i, null), e._update = !1);
 }
 getGLBuffer(e) {
  var t;
  return e.idleTime = 0, this._cached_buffers.has(e) ? (t = this._cached_buffers.get(e), 
  (e.dirty || e._update) && this._updateAttribute(e), t) : (t = this._createGLBuffer(e), 
  (e.dirty || e._update) && this._updateAttribute(e), t);
 }
 deleteBuffer(t, e) {
  t.dirty = !0, this._cached_buffers.delete(t), this._gl.deleteBuffer(e);
  for (let e = 0; e < t.locations.length; e++) {
   var i = t.locations[e];
   this._gl.disableVertexAttribArray(i);
  }
  t.locations = new Array();
 }
 deleteBuffers(e = !1, t = 1e3) {
  if (e) for (var [ i, r ] of this._cached_buffers) i.idleTime >= t && this.deleteBuffer(i, r); else for (var [ s, a ] of this._cached_buffers) this.deleteBuffer(s, a);
 }
 incrementTime() {
  for (var [ e, t ] of this._cached_buffers) e.idleTime = e.idleTime + 1;
 }
}

class GLFrameBufferManager {
 constructor(e) {
  this._gl = e, this._cached_fbos = new Map();
 }
 bindFramebuffer(e) {
  var t = this._cached_fbos.get(e);
  void 0 === t && (t = this._gl.createFramebuffer(), this._cached_fbos.set(e, t)), 
  this._gl.bindFramebuffer(this._gl.FRAMEBUFFER, t);
 }
 unbindFramebuffer() {
  this._gl.bindFramebuffer(this._gl.FRAMEBUFFER, null);
 }
 deleteFrameBuffer(e, t) {
  this._cached_fbos.delete(e), this._gl.deleteFramebuffer(t);
 }
 deleteFrameBuffers() {
  for (var [ e, t ] of this._cached_fbos) this.deleteFrameBuffer(e, t);
 }
}

class Texture {
 static DEFAULT_IMAGE = null;
 static FILTER = {
  NearestFilter: 0,
  NearestMipMapNearestFilter: 1,
  NearestMipMapLinearFilter: 2,
  LinearFilter: 3,
  LinearMipMapNearestFilter: 4,
  LinearMipMapLinearFilter: 5
 };
 static FORMAT = {
  ALPHA: 6,
  RGB: 7,
  RGBA: 8,
  LUMINANCE: 9,
  LUMINANCE_ALPHA: 10,
  DEPTH_COMPONENT: 11,
  DEPTH_COMPONENT24: 12,
  DEPTH_COMPONENT32F: 12.5,
  RGB16F: 13,
  RGB32F: 14,
  RGBA16F: 15,
  RGBA32F: 16,
  R16F: 17,
  R8: 17.1,
  RED: 17.2,
  RED_INTEGER: 17.25,
  R32F: 17.3,
  R32I: 17.4,
  R32UI: 17.5
 };
 static WRAPPING = {
  RepeatWrapping: 18,
  ClampToEdgeWrapping: 19,
  MirroredRepeatWrapping: 20
 };
 static TYPE = {
  UNSIGNED_BYTE: 21,
  UNSIGNED_SHORT: 22,
  UNSIGNED_INT: 23,
  HALF_FLOAT: 24,
  FLOAT: 25,
  INT: 26
 };
 _update = {
  size: !0
 };
 constructor(e, t, i, r, s, a, n, o, h = 1024, u = 1024) {
  this._uuid = _Math.generateUUID(), this.type = "Texture", this._image = e || Texture.DEFAULT_IMAGE, 
  this._magFilter = void 0 !== s ? s : Texture.FILTER.LinearFilter, this._minFilter = void 0 !== r ? r : Texture.FILTER.LinearFilter, 
  this._wrapS = void 0 !== t ? t : Texture.WRAPPING.ClampToEdgeWrapping, this._wrapT = void 0 !== i ? i : Texture.WRAPPING.ClampToEdgeWrapping, 
  this._internalFormat = void 0 !== a ? a : Texture.FORMAT.RGBA, this._format = void 0 !== n ? n : Texture.FORMAT.RGBA, 
  this._type = void 0 !== o ? o : Texture.TYPE.UNSIGNED_BYTE, this.clearFunction = 0, 
  this._generateMipmaps = !1, this._width = h, this._height = u, this._flipy = !0, 
  this._dirty = !0, this.update = {
   size: !0
  }, this.idleTime = 0;
 }
 applyConfig(e) {
  this.wrapS = e.wrapS, this.wrapT = e.wrapT, this.minFilter = e.minFilter, this.magFilter = e.magFilter, 
  this.internalFormat = e.internalFormat, this.format = e.format, this.type = e.type, 
  this.clearFunction = e.clearFunction;
 }
 get dirty() {
  return this._dirty;
 }
 set dirty(e) {
  this._dirty = e;
 }
 get update() {
  return this._update;
 }
 set update(e) {
  this._update = e;
 }
 get image() {
  return this._image;
 }
 get wrapS() {
  return this._wrapS;
 }
 get wrapT() {
  return this._wrapT;
 }
 get minFilter() {
  return this._minFilter;
 }
 get magFilter() {
  return this._magFilter;
 }
 get internalFormat() {
  return this._internalFormat;
 }
 get format() {
  return this._format;
 }
 get type() {
  return this._type;
 }
 get width() {
  return this._width;
 }
 get height() {
  return this._height;
 }
 get flipy() {
  return this._flipy;
 }
 set image(e) {
  e !== this._image && (this._image = e, this._dirty = !0);
 }
 set wrapS(e) {
  e !== this._wrapS && (this._wrapS = e, this._dirty = !0);
 }
 set wrapT(e) {
  e !== this._wrapT && (this._wrapT = e, this._dirty = !0);
 }
 set minFilter(e) {
  e !== this._minFilter && (this._minFilter = e, this._dirty = !0);
 }
 set magFilter(e) {
  e !== this._magFilter && (this._magFilter = e, this._dirty = !0);
 }
 set internalFormat(e) {
  e !== this._internalFormat && (this._internalFormat = e, this._dirty = !0);
 }
 set format(e) {
  e !== this._format && (this._format = e, this._dirty = !0);
 }
 set width(e) {
  e !== this._width && (this._width = e, this._dirty = !0, this.update.size = !0);
 }
 set height(e) {
  e !== this._height && (this._height = e, this._dirty = !0, this.update.size = !0);
 }
 set flipy(e) {
  e !== this._flipy && (this._flipy = e, this._dirty = !0);
 }
 set type(e) {
  e !== this._type && (this._type = e, this._dirty = !0);
 }
}

class GLTextureManager {
 _activeTexture;
 constructor(e) {
  this._gl = e, this._cached_textures = new Map(), this._colorClearFramebuffer = this._gl.createFramebuffer(), 
  this.activeTexture = 0;
 }
 get activeTexture() {
  return this._activeTexture;
 }
 set activeTexture(e) {
  this._activeTexture = e, this._gl.activeTexture(this._gl.TEXTURE0 + e);
 }
 _createGLTexture(e) {
  var t = this._formatToGL(e._internalFormat), i = this._formatToGL(e._format), r = (this._magFilterToGL(e._magFilter), 
  this._minFilterToGL(e._minFilter), this._wrapToGL(e._wrapS), this._wrapToGL(e._wrapT), 
  this._typeToGL(e._type)), s = e._width, a = e._height, n = this._gl.createTexture();
  return this._gl.activeTexture(this._gl.TEXTURE0 + this._gl.getParameter(this._gl.MAX_COMBINED_TEXTURE_IMAGE_UNITS) - 1), 
  this._gl.bindTexture(this._gl.TEXTURE_2D, n), this._gl.texImage2D(this._gl.TEXTURE_2D, 0, t, s, a, 0, i, r, null), 
  this._gl.bindTexture(this._gl.TEXTURE_2D, null), this._cached_textures.set(e, n), 
  n;
 }
 _updateTexture(e) {
  var t = this._cached_textures.get(e), i = this._formatToGL(e._internalFormat), r = this._formatToGL(e._format), s = this._magFilterToGL(e._magFilter), a = this._minFilterToGL(e._minFilter), n = this._wrapToGL(e._wrapS), o = this._wrapToGL(e._wrapT), h = this._typeToGL(e._type), u = e._width, l = e._height;
  this._gl.activeTexture(this._gl.TEXTURE0 + this._gl.getParameter(this._gl.MAX_COMBINED_TEXTURE_IMAGE_UNITS) - 1), 
  this._gl.bindTexture(this._gl.TEXTURE_2D, t), e.update.size && (this._gl.texImage2D(this._gl.TEXTURE_2D, 0, i, u, l, 0, r, h, null), 
  e.update.size = !1), e.image && (this._gl.pixelStorei(this._gl.UNPACK_FLIP_Y_WEBGL, e.flipy), 
  this._gl.texSubImage2D(this._gl.TEXTURE_2D, 0, 0, 0, u, l, r, h, e.image), this._gl.pixelStorei(this._gl.UNPACK_FLIP_Y_WEBGL, !1)), 
  this._gl.texParameteri(this._gl.TEXTURE_2D, this._gl.TEXTURE_MAG_FILTER, s), this._gl.texParameteri(this._gl.TEXTURE_2D, this._gl.TEXTURE_MIN_FILTER, a), 
  this._gl.texParameteri(this._gl.TEXTURE_2D, this._gl.TEXTURE_WRAP_S, n), this._gl.texParameteri(this._gl.TEXTURE_2D, this._gl.TEXTURE_WRAP_T, o), 
  e._generateMipmaps && this._gl.generateMipmap(this._gl.TEXTURE_2D), this._gl.bindTexture(this._gl.TEXTURE_2D, null), 
  e.dirty = !1;
 }
 _createGLCubeTexture(e) {
  var t = this._formatToGL(e._internalFormat), i = this._formatToGL(e._format), r = (this._magFilterToGL(e._magFilter), 
  this._minFilterToGL(e._minFilter), this._wrapToGL(e._wrapS), this._wrapToGL(e._wrapT), 
  this._wrapToGL(e._wrapR), this._typeToGL(e._type)), s = e._width, a = e._height, s = Math.min(s, a), a = this._gl.createTexture();
  return this._gl.activeTexture(this._gl.TEXTURE0 + this._gl.getParameter(this._gl.MAX_COMBINED_TEXTURE_IMAGE_UNITS) - 1), 
  this._gl.bindTexture(this._gl.TEXTURE_CUBE_MAP, a), this._gl.texImage2D(this._gl.TEXTURE_CUBE_MAP_POSITIVE_X, 0, t, s, s, 0, i, r, null), 
  this._gl.texImage2D(this._gl.TEXTURE_CUBE_MAP_NEGATIVE_X, 0, t, s, s, 0, i, r, null), 
  this._gl.texImage2D(this._gl.TEXTURE_CUBE_MAP_POSITIVE_Y, 0, t, s, s, 0, i, r, null), 
  this._gl.texImage2D(this._gl.TEXTURE_CUBE_MAP_NEGATIVE_Y, 0, t, s, s, 0, i, r, null), 
  this._gl.texImage2D(this._gl.TEXTURE_CUBE_MAP_POSITIVE_Z, 0, t, s, s, 0, i, r, null), 
  this._gl.texImage2D(this._gl.TEXTURE_CUBE_MAP_NEGATIVE_Z, 0, t, s, s, 0, i, r, null), 
  this._gl.bindTexture(this._gl.TEXTURE_CUBE_MAP, null), this._cached_textures.set(e, a), 
  a;
 }
 _updateCubeTexture(e) {
  var t = this._cached_textures.get(e), i = this._formatToGL(e._internalFormat), r = this._formatToGL(e._format), s = this._magFilterToGL(e._magFilter), a = this._minFilterToGL(e._minFilter), n = this._wrapToGL(e._wrapS), o = this._wrapToGL(e._wrapT), h = this._wrapToGL(e._wrapR), u = this._typeToGL(e._type), l = e._width, _ = e._height, l = Math.min(l, _);
  this._gl.activeTexture(this._gl.TEXTURE0 + this._gl.getParameter(this._gl.MAX_COMBINED_TEXTURE_IMAGE_UNITS) - 1), 
  this._gl.bindTexture(this._gl.TEXTURE_CUBE_MAP, t), e.update.size && (this._gl.texImage2D(this._gl.TEXTURE_CUBE_MAP_POSITIVE_X, 0, i, l, l, 0, r, u, null), 
  this._gl.texImage2D(this._gl.TEXTURE_CUBE_MAP_NEGATIVE_X, 0, i, l, l, 0, r, u, null), 
  this._gl.texImage2D(this._gl.TEXTURE_CUBE_MAP_POSITIVE_Y, 0, i, l, l, 0, r, u, null), 
  this._gl.texImage2D(this._gl.TEXTURE_CUBE_MAP_NEGATIVE_Y, 0, i, l, l, 0, r, u, null), 
  this._gl.texImage2D(this._gl.TEXTURE_CUBE_MAP_POSITIVE_Z, 0, i, l, l, 0, r, u, null), 
  this._gl.texImage2D(this._gl.TEXTURE_CUBE_MAP_NEGATIVE_Z, 0, i, l, l, 0, r, u, null), 
  e.update.size = !1), this._gl.pixelStorei(this._gl.UNPACK_FLIP_Y_WEBGL, e.flipy), 
  e.images.right && this._gl.texSubImage2D(this._gl.TEXTURE_CUBE_MAP_POSITIVE_X, 0, 0, 0, l, l, r, u, e.images.right), 
  e.images.left && this._gl.texSubImage2D(this._gl.TEXTURE_CUBE_MAP_NEGATIVE_X, 0, 0, 0, l, l, r, u, e.images.left), 
  e.images.top && this._gl.texSubImage2D(this._gl.TEXTURE_CUBE_MAP_POSITIVE_Y, 0, 0, 0, l, l, r, u, e.images.top), 
  e.images.bottom && this._gl.texSubImage2D(this._gl.TEXTURE_CUBE_MAP_NEGATIVE_Y, 0, 0, 0, l, l, r, u, e.images.bottom), 
  e.images.front && this._gl.texSubImage2D(this._gl.TEXTURE_CUBE_MAP_POSITIVE_Z, 0, 0, 0, l, l, r, u, e.images.front), 
  e.images.back && this._gl.texSubImage2D(this._gl.TEXTURE_CUBE_MAP_NEGATIVE_Z, 0, 0, 0, l, l, r, u, e.images.back), 
  this._gl.pixelStorei(this._gl.UNPACK_FLIP_Y_WEBGL, !1), this._gl.texParameteri(this._gl.TEXTURE_CUBE_MAP, this._gl.TEXTURE_MAG_FILTER, s), 
  this._gl.texParameteri(this._gl.TEXTURE_CUBE_MAP, this._gl.TEXTURE_MIN_FILTER, a), 
  this._gl.texParameteri(this._gl.TEXTURE_CUBE_MAP, this._gl.TEXTURE_WRAP_S, n), 
  this._gl.texParameteri(this._gl.TEXTURE_CUBE_MAP, this._gl.TEXTURE_WRAP_T, o), 
  this._gl.texParameteri(this._gl.TEXTURE_CUBE_MAP, this._gl.TEXTURE_WRAP_R, h), 
  e._generateMipmaps && this._gl.generateMipmap(this._gl.TEXTURE_CUBE_MAP), this._gl.bindTexture(this._gl.TEXTURE_CUBE_MAP, null), 
  e.dirty = !1;
 }
 getGLTexture(e) {
  var t;
  return e.idleTime = 0, this._cached_textures.has(e) ? (t = this._cached_textures.get(e), 
  e.dirty && this._updateTexture(e), t) : (t = this._createGLTexture(e), e.dirty && this._updateTexture(e), 
  t);
 }
 getGLCubeTexture(e) {
  var t;
  return e.idleTime = 0, this._cached_textures.has(e) ? (t = this._cached_textures.get(e), 
  e.dirty && this._updateCubeTexture(e), t) : (t = this._createGLCubeTexture(e), 
  e.dirty && this._updateCubeTexture(e), t);
 }
 clearBoundTexture() {
  var e = this._gl.getParameter(this._gl.DRAW_FRAMEBUFFER_BINDING), t = this._gl.getParameter(this._gl.COLOR_CLEAR_VALUE);
  this._gl.bindFramebuffer(this._gl.FRAMEBUFFER, this._colorClearFramebuffer), this._gl.framebufferTexture2D(this._gl.FRAMEBUFFER, this._gl.COLOR_ATTACHMENT0, this._gl.TEXTURE_2D, glTexture, 0), 
  this._gl.drawBuffers([ this._gl.COLOR_ATTACHMENT0 ]), this._gl.clearColor(0, 0, 0, 0), 
  this._gl.clear(this._gl.COLOR_BUFFER_BIT), this._gl.framebufferTexture2D(this._gl.FRAMEBUFFER, this._gl.COLOR_ATTACHMENT0, this._gl.TEXTURE_2D, null, 0), 
  this._gl.bindFramebuffer(this._gl.FRAMEBUFFER, e), this._gl.clearColor(t[0], t[1], t[2], t[3]);
 }
 deleteTexture(e, t) {
  e.dirty = !0, this._cached_textures.delete(e), this._gl.deleteTexture(t);
 }
 deleteTextures(e = !1, t = 1e3) {
  if (e) for (var [ i, r ] of this._cached_textures) i.idleTime >= t && this.deleteTexture(i, r); else for (var [ s, a ] of this._cached_textures) this.deleteTexture(s, a);
 }
 incrementTime() {
  for (var [ e, t ] of this._cached_textures) e.idleTime = e.idleTime + 1;
 }
 _formatToGL(e) {
  switch (e) {
  case Texture.FORMAT.R8:
   return this._gl.R8;

  case Texture.FORMAT.RED:
   return this._gl.RED;

  case Texture.FORMAT.RED_INTEGER:
   return this._gl.RED_INTEGER;

  case Texture.FORMAT.RGBA:
   return this._gl.RGBA;

  case Texture.FORMAT.RGB:
   return this._gl.RGB;

  case Texture.FORMAT.ALPHA:
   return this._gl.ALPHA;

  case Texture.FORMAT.LUMINANCE:
   return this._gl.LUMINANCE;

  case Texture.FORMAT.LUMINANCE_ALPHA:
   return this._gl.LUMINANCE_ALPHA;

  case Texture.FORMAT.DEPTH_COMPONENT:
   return this._gl.DEPTH_COMPONENT;

  case Texture.FORMAT.DEPTH_COMPONENT24:
   return this._gl.DEPTH_COMPONENT24;

  case Texture.FORMAT.DEPTH_COMPONENT32F:
   return this._gl.DEPTH_COMPONENT32F;

  case Texture.FORMAT.RGB16F:
   return this._gl.RGB16F;

  case Texture.FORMAT.RGB32F:
   return this._gl.RGB32F;

  case Texture.FORMAT.RGBA16F:
   return this._gl.RGBA16F;

  case Texture.FORMAT.RGBA32F:
   return this._gl.RGBA32F;

  case Texture.FORMAT.R16F:
   return this._gl.R16F;

  case Texture.FORMAT.R32F:
   return this._gl.R32F;

  case Texture.FORMAT.R32I:
   return this._gl.R32I;

  case Texture.FORMAT.R32UI:
   return this._gl.R32UI;

  default:
   return console.warn("Warning: Received unsupported texture format: [" + e + "]!"), 
   this._gl.RGBA;
  }
 }
 _magFilterToGL(e) {
  switch (e) {
  case Texture.FILTER.NearestFilter:
   return this._gl.NEAREST;

  case Texture.FILTER.LinearFilter:
   return this._gl.LINEAR;

  default:
   return console.warn("Warning: Received unsupported texture filter: [" + e + "]!"), 
   this._gl.LINEAR;
  }
 }
 _minFilterToGL(e) {
  switch (e) {
  case Texture.FILTER.NearestFilter:
   return this._gl.NEAREST;

  case Texture.FILTER.LinearFilter:
   return this._gl.LINEAR;

  case Texture.FILTER.NearestMipMapNearestFilter:
   return this._gl.NEAREST_MIPMAP_NEAREST;

  case Texture.FILTER.NearestMipMapLinearFilter:
   return this._gl.NEAREST_MIPMAP_LINEAR;

  case Texture.FILTER.LinearMipMapNearestFilter:
   return this._gl.LINEAR_MIPMAP_NEAREST;

  case Texture.FILTER.LinearMipMapLinearFilter:
   return this._gl.LINEAR_MIPMAP_LINEAR;

  default:
   return console.warn("Warning: Received unsupported texture filter: [" + e + "]!"), 
   this._gl.LINEAR;
  }
 }
 _wrapToGL(e) {
  switch (e) {
  case Texture.WRAPPING.RepeatWrapping:
   return this._gl.REPEAT;

  case Texture.WRAPPING.ClampToEdgeWrapping:
   return this._gl.CLAMP_TO_EDGE;

  case Texture.WRAPPING.MirroredRepeatWrapping:
   return this._gl.MIRRORED_REPEAT;

  default:
   return console.warn("Warning: Received unsupported texture wrap: [" + e + "]!"), 
   this._gl.CLAMP_TO_EDGE;
  }
 }
 _typeToGL(e) {
  switch (e) {
  case Texture.TYPE.UNSIGNED_BYTE:
   return this._gl.UNSIGNED_BYTE;

  case Texture.TYPE.UNSIGNED_INT_24_8:
   return this._gl.UNSIGNED_INT_24_8;

  case Texture.TYPE.UNSIGNED_SHORT:
   return this._gl.UNSIGNED_SHORT;

  case Texture.TYPE.UNSIGNED_INT:
   return this._gl.UNSIGNED_INT;

  case Texture.TYPE.INT:
   return this._gl.INT;

  case Texture.TYPE.FLOAT:
   return this._gl.FLOAT;

  case Texture.TYPE.HALF_FLOAT:
   return this._gl.HALF_FLOAT;

  default:
   return console.warn("Warning: Received unsupported texture type: [" + e + "] (using default)!"), 
   this._gl.UNSIGNED_BYTE;
  }
 }
}

class Geometry {
 constructor(e = {}) {
  this._uuid = _Math.generateUUID(), this.type = "Geometry", this._indices = void 0 !== e.indices ? e.indices : null, 
  this._vertices = void 0 !== e.vertices ? e.vertices : null, this._normals = void 0 !== e.normals ? e.normals : null, 
  this._tangents = void 0 !== e.tangents ? e.tangents : null, this._bitangents = void 0 !== e.bitangents ? e.bitangents : null, 
  this._vertColor = void 0 !== e.vertColor ? e.vertColor : null, this._uv = void 0 !== e.uv ? e.uv : null, 
  this._wireframeIndices = void 0 !== e.wireframeIndices ? e.wireframeIndices : null, 
  this._MMat = void 0 !== e.MMat ? e.MMat : null, this._translation = void 0 !== e.translation ? e.translation : null, 
  this._boundingBox = null, this._boundingSphere = null, this._onChangeListener = null, 
  this._drawWireframe = !1;
 }
 buildWireframeBuffer() {
  var i, r, s, a = new Map(), n = [];
  if (null !== this._indices && 0 < this._indices.count()) {
   var o, h, u, l = this._indices.array;
   for (let e = 0, t = l.length; e < t; e += 3) o = l[e], h = l[e + 1], u = l[e + 2], 
   this.sanitize(a, o, h, n), this.sanitize(a, h, u, n), this.sanitize(a, u, o, n);
  } else {
   if (!(null !== this._vertices && 0 < this._vertices.count())) return;
   for (let e = 0, t = this._vertices.array.length / 3 - 1; e < t; e += 3) r = (i = e) + 1, 
   s = e + 2, n.push(i, r, r, s, s, i);
  }
  this.wireframeIndices = new BufferAttribute(new Uint32Array(n), 1);
 }
 checkContamination(t, i, r, s) {
  for (let e = s = (s = 6 * s - 18) < 0 ? 0 : s; e < t.length; e += 2) if (t[e] === i && t[e + 1] === r || t[e] === r && t[e + 1] === i) return !0;
  return !1;
 }
 sanitize(e, t, i, r) {
  let s = !1, a = !1, n = !1, o = !1, h, u;
  if (e.has(t)) {
   s = !0, h = e.get(t);
   for (let e = 0; e < h.length; e++) if (h[e] === i) {
    n = !0;
    break;
   }
  }
  if (e.has(i)) {
   a = !0, u = e.get(i);
   for (let e = 0; e < u.length; e++) if (u[e] === t) {
    o = !0;
    break;
   }
  }
  s || e.set(t, [ i ]), a || e.set(i, [ t ]), s && !n && h.push(i), a && !o && u.push(t), 
  s && a && n && o || r.push(t, i);
 }
 _normalizeNormals() {
  for (var e, t, i, r = this._normals.array, s = 0; s < r.length; s += 3) i = r[s], 
  e = r[s + 1], t = r[s + 2], i = 1 / Math.sqrt(i * i + e * e + t * t), r[s] *= i, 
  r[s + 1] *= i, r[s + 2] *= i;
 }
 computeVertexNormals() {
  if (this.vertices) {
   var e = this.vertices.array;
   if (this._normals) for (var t = this._normals.array, i = 0; i < t.length; i++) t[i] = 0; else this.normals = new BufferAttribute(new Float32Array(e.length), 3);
   var r, s, a, n = this._normals.array, o = new Vector3(), h = new Vector3(), u = new Vector3(), l = new Vector3(), _ = new Vector3();
   if (this.indices) for (var c = this.indices.array, i = 0; i < c.length; i += 3) r = 3 * c[i], 
   s = 3 * c[i + 1], a = 3 * c[i + 2], o.fromArray(e, r), h.fromArray(e, s), u.fromArray(e, a), 
   l.subVectors(u, h), _.subVectors(o, h), l.cross(_), n[r] += l.x, n[1 + r] += l.y, 
   n[2 + r] += l.z, n[s] += l.x, n[1 + s] += l.y, n[2 + s] += l.z, n[a] += l.x, 
   n[1 + a] += l.y, n[2 + a] += l.z; else for (i = 0; i < e.length; i += 9) o.fromArray(e, i), 
   h.fromArray(e, i + 3), u.fromArray(e, i + 6), l.subVectors(u, h), _.subVectors(o, h), 
   l.cross(_), n[i] = l.x, n[i + 1] = l.y, n[i + 2] = l.z, n[i + 3] = l.x, n[i + 4] = l.y, 
   n[i + 5] = l.z, n[i + 6] = l.x, n[i + 7] = l.y, n[i + 8] = l.z;
   this._normalizeNormals(), this._normals.needsUpdate = !0;
  }
 }
 computeVertexTangents() {
  if (this.indices) {
   var t = this.indices, i = this.vertices, r = this.uv, s = new Vector3(), a = new Vector3(), n = new Vector3(), o = new Vector2(), h = new Vector2(), u = new Vector2(), l = new Vector3(), _ = new Vector3(), c = new Vector2(), d = new Vector2(), m = new Vector3(), g = new Array(i.count() * i.itemSize);
   for (let e = 0; e < t.count(); e += 3) {
    s.x = i.array[t.array[e + 0] * i.itemSize + 0], s.y = i.array[t.array[e + 0] * i.itemSize + 1], 
    s.z = i.array[t.array[e + 0] * i.itemSize + 2], a.x = i.array[t.array[e + 1] * i.itemSize + 0], 
    a.y = i.array[t.array[e + 1] * i.itemSize + 1], a.z = i.array[t.array[e + 1] * i.itemSize + 2], 
    n.x = i.array[t.array[e + 2] * i.itemSize + 0], n.y = i.array[t.array[e + 2] * i.itemSize + 1], 
    n.z = i.array[t.array[e + 2] * i.itemSize + 2], o.x = r.array[t.array[e + 0] * r.itemSize + 0], 
    o.y = r.array[t.array[e + 0] * r.itemSize + 1], h.x = r.array[t.array[e + 1] * r.itemSize + 0], 
    h.y = r.array[t.array[e + 1] * r.itemSize + 1], u.x = r.array[t.array[e + 2] * r.itemSize + 0], 
    u.y = r.array[t.array[e + 2] * r.itemSize + 1], l.subVectors(a, s), _.subVectors(n, s), 
    c.subVectors(h, o), d.subVectors(u, o);
    var p = 1 / (c.x * d.y - c.y * d.x);
    m.subVectors(l.multiplyScalar(d.y), _.multiplyScalar(c.y)).multiplyScalar(p), 
    m.normalize(), g[t.array[e + 0] * i.itemSize + 0] = m.x, g[t.array[e + 0] * i.itemSize + 1] = m.y, 
    g[t.array[e + 0] * i.itemSize + 2] = m.z, g[t.array[e + 1] * i.itemSize + 0] = m.x, 
    g[t.array[e + 1] * i.itemSize + 1] = m.y, g[t.array[e + 1] * i.itemSize + 2] = m.z, 
    g[t.array[e + 2] * i.itemSize + 0] = m.x, g[t.array[e + 2] * i.itemSize + 1] = m.y, 
    g[t.array[e + 2] * i.itemSize + 2] = m.z;
   }
   this.tangents = new Float32Attribute(g, i.itemSize);
  } else {
   var f = this.vertices, y = this.uv, T = new Vector3(), x = new Vector3(), S = new Vector3(), E = new Vector2(), A = new Vector2(), R = new Vector2(), v = new Vector3(), P = new Vector3(), w = new Vector2(), M = new Vector2(), b = new Vector3(), L = new Array(f.count() * f.itemSize);
   for (let e = 0; e < f.count(); e += 3) {
    T.x = f.array[e * f.itemSize + 0], T.y = f.array[e * f.itemSize + 1], T.z = f.array[e * f.itemSize + 2], 
    x.x = f.array[e * f.itemSize + 3], x.y = f.array[e * f.itemSize + 4], x.z = f.array[e * f.itemSize + 5], 
    S.x = f.array[e * f.itemSize + 6], S.y = f.array[e * f.itemSize + 7], S.z = f.array[e * f.itemSize + 8], 
    E.x = y.array[e * y.itemSize + 0], E.y = y.array[e * y.itemSize + 1], A.x = y.array[e * y.itemSize + 2], 
    A.y = y.array[e * y.itemSize + 3], R.x = y.array[e * y.itemSize + 4], R.y = y.array[e * y.itemSize + 5], 
    v.subVectors(x, T), P.subVectors(S, T), w.subVectors(A, E), M.subVectors(R, E);
    var C = 1 / (w.x * M.y - w.y * M.x);
    b.subVectors(v.multiplyScalar(M.y), P.multiplyScalar(w.y)).multiplyScalar(C), 
    b.normalize(), L[e * f.itemSize + 0] = b.x, L[e * f.itemSize + 1] = b.y, L[e * f.itemSize + 2] = b.z, 
    L[e * f.itemSize + 3] = b.x, L[e * f.itemSize + 4] = b.y, L[e * f.itemSize + 5] = b.z, 
    L[e * f.itemSize + 6] = b.x, L[e * f.itemSize + 7] = b.y, L[e * f.itemSize + 8] = b.z;
   }
   this.tangents = new Float32Attribute(L, f.itemSize);
  }
 }
 computeVertexBitangents() {
  if (this.indices) {
   var t = this.indices, i = this.vertices, r = this.uv, s = new Vector3(), a = new Vector3(), n = new Vector3(), o = new Vector2(), h = new Vector2(), u = new Vector2(), l = new Vector3(), _ = new Vector3(), c = new Vector2(), d = new Vector2(), m = new Vector3(), g = new Array(i.count() * i.itemSize);
   for (let e = 0; e < t.count(); e += 3) {
    s.x = i.array[t.array[e + 0] * i.itemSize + 0], s.y = i.array[t.array[e + 0] * i.itemSize + 1], 
    s.z = i.array[t.array[e + 0] * i.itemSize + 2], a.x = i.array[t.array[e + 1] * i.itemSize + 0], 
    a.y = i.array[t.array[e + 1] * i.itemSize + 1], a.z = i.array[t.array[e + 1] * i.itemSize + 2], 
    n.x = i.array[t.array[e + 2] * i.itemSize + 0], n.y = i.array[t.array[e + 2] * i.itemSize + 1], 
    n.z = i.array[t.array[e + 2] * i.itemSize + 2], o.x = r.array[t.array[e + 0] * r.itemSize + 0], 
    o.y = r.array[t.array[e + 0] * r.itemSize + 1], h.x = r.array[t.array[e + 1] * r.itemSize + 0], 
    h.y = r.array[t.array[e + 1] * r.itemSize + 1], u.x = r.array[t.array[e + 2] * r.itemSize + 0], 
    u.y = r.array[t.array[e + 2] * r.itemSize + 1], l.subVectors(a, s), _.subVectors(n, s), 
    c.subVectors(h, o), d.subVectors(u, o);
    var p = 1 / (c.x * d.y - c.y * d.x);
    m.subVectors(_.multiplyScalar(c.x), l.multiplyScalar(d.x)).multiplyScalar(p), 
    m.normalize(), g[t.array[e + 0] * i.itemSize + 0] = m.x, g[t.array[e + 0] * i.itemSize + 1] = m.y, 
    g[t.array[e + 0] * i.itemSize + 2] = m.z, g[t.array[e + 1] * i.itemSize + 0] = m.x, 
    g[t.array[e + 1] * i.itemSize + 1] = m.y, g[t.array[e + 1] * i.itemSize + 2] = m.z, 
    g[t.array[e + 2] * i.itemSize + 0] = m.x, g[t.array[e + 2] * i.itemSize + 1] = m.y, 
    g[t.array[e + 2] * i.itemSize + 2] = m.z;
   }
   this.bitangents = new Float32Attribute(g, i.itemSize);
  } else {
   var f = this.vertices, y = this.uv, T = new Vector3(), x = new Vector3(), S = new Vector3(), E = new Vector2(), A = new Vector2(), R = new Vector2(), v = new Vector3(), P = new Vector3(), w = new Vector2(), M = new Vector2(), b = new Vector3(), L = new Array(f.count() * f.itemSize);
   for (let e = 0; e < f.count(); e += 3) {
    T.x = f.array[e * f.itemSize + 0], T.y = f.array[e * f.itemSize + 1], T.z = f.array[e * f.itemSize + 2], 
    x.x = f.array[e * f.itemSize + 3], x.y = f.array[e * f.itemSize + 4], x.z = f.array[e * f.itemSize + 5], 
    S.x = f.array[e * f.itemSize + 6], S.y = f.array[e * f.itemSize + 7], S.z = f.array[e * f.itemSize + 8], 
    E.x = y.array[e * y.itemSize + 0], E.y = y.array[e * y.itemSize + 1], A.x = y.array[e * y.itemSize + 2], 
    A.y = y.array[e * y.itemSize + 3], R.x = y.array[e * y.itemSize + 4], R.y = y.array[e * y.itemSize + 5], 
    v.subVectors(x, T), P.subVectors(S, T), w.subVectors(A, E), M.subVectors(R, E);
    var C = 1 / (w.x * M.y - w.y * M.x);
    b.subVectors(P.multiplyScalar(w.x), v.multiplyScalar(M.x)).multiplyScalar(C), 
    b.normalize(), L[e * f.itemSize + 0] = b.x, L[e * f.itemSize + 1] = b.y, L[e * f.itemSize + 2] = b.z, 
    L[e * f.itemSize + 3] = b.x, L[e * f.itemSize + 4] = b.y, L[e * f.itemSize + 5] = b.z, 
    L[e * f.itemSize + 6] = b.x, L[e * f.itemSize + 7] = b.y, L[e * f.itemSize + 8] = b.z;
   }
   this.bitangents = new Float32Attribute(L, f.itemSize);
  }
 }
 computeVertexNormalsIdxRange(e, t) {
  if (this.vertices && this.indices) {
   var i = this.vertices.array;
   if (this._normals) for (var r = this._normals.array, s = 0; s < r.length; s++) r[s] = 0; else this.normals = new BufferAttribute(new Float32Array(i.length), 3);
   for (var a, n, o, h = this._normals.array, u = new Vector3(), l = new Vector3(), _ = new Vector3(), c = new Vector3(), d = new Vector3(), m = this.indices.array, s = e, g = e + t; s < g; s += 3) a = 3 * m[s], 
   n = 3 * m[s + 1], o = 3 * m[s + 2], u.fromArray(i, a), l.fromArray(i, n), _.fromArray(i, o), 
   c.subVectors(_, l), d.subVectors(u, l), c.cross(d), h[a] += c.x, h[1 + a] += c.y, 
   h[2 + a] += c.z, h[n] += c.x, h[1 + n] += c.y, h[2 + n] += c.z, h[o] += c.x, 
   h[1 + o] += c.y, h[2 + o] += c.z;
   this._normalizeNormals(), this._normals.needsUpdate = !0;
  }
 }
 computeBoundingBox() {
  null === this._boundingBox && (this._boundingBox = new Box3()), this._vertices ? this._boundingBox.setFromArray(this._vertices.array) : this._boundingBox.makeEmpty(), 
  (isNaN(this._boundingBox.min.x) || isNaN(this._boundingBox.min.y) || isNaN(this._boundingBox.min.z)) && console.error("Geometry error: One or more of bounding box axis min is NaN.");
 }
 computeBoundingSphere() {
  var e = new Box3(), i = new Vector3();
  if (null === this._boundingSphere && (this._boundingSphere = new Sphere()), this._vertices) {
   var r = this._vertices.array, s = this._boundingSphere.center;
   e.setFromArray(r), e.center(s);
   let t = 0;
   for (let e = 0; e < r.length; e += 3) i.fromArray(r, e), t = Math.max(t, s.distanceToSquared(i));
   this._boundingSphere.radius = Math.sqrt(t), isNaN(this._boundingSphere.radius) && console.error("Geometry error: Bounding sphere radius is NaN.");
  }
 }
 setDrawRange(e, t) {
  this._indices ? (this._indexStart = e, this._indexCount = t, this._drawRangeSet = !0) : console.error("Geometry error: setDrawRange called before indices were set.");
 }
 get indexStart() {
  return this._drawRangeSet ? this._indexStart : 0;
 }
 get indexCount() {
  return this._drawRangeSet ? this._indexCount : this.indices.count();
 }
 get indices() {
  return this._indices;
 }
 get vertices() {
  return this._vertices;
 }
 get normals() {
  return null === this._normals && this.computeVertexNormals(), this._normals;
 }
 get tangents() {
  return this._tangents;
 }
 get bitangents() {
  return this._bitangents;
 }
 get vertColor() {
  return this._vertColor;
 }
 get uv() {
  return this._uv;
 }
 get wireframeIndices() {
  return null === this._wireframeIndices && this.buildWireframeBuffer(), this._wireframeIndices;
 }
 get MMat() {
  return this._MMat;
 }
 get translation() {
  return this._translation;
 }
 get drawWireframe() {
  return this._drawWireframe;
 }
 get boundingBox() {
  return this._boundingBox;
 }
 get boundingSphere() {
  return null === this._boundingSphere && this.computeBoundingSphere(), this._boundingSphere;
 }
 set indices(e) {
  this._indices = e, this._onChangeListener && (e = {
   uuid: this._uuid,
   changes: {
    array: this._indices.array.buffer.slice(0),
    itemSize: this._indices.itemSize
   }
  }, this._onChangeListener.geometryUpdate(e)), this._indices.target = BufferAttribute.TARGET.ELEMENT_ARRAY_BUFFER;
 }
 set vertices(e) {
  this._vertices = e, this._onChangeListener && (e = {
   uuid: this._uuid,
   changes: {
    array: this._vertices.array.buffer.slice(0),
    itemSize: this._vertices.itemSize
   }
  }, this._onChangeListener.geometryUpdate(e)), this._vertices.target = BufferAttribute.TARGET.ARRAY_BUFFER;
 }
 set normals(e) {
  this._normals = e, this._onChangeListener && (e = {
   uuid: this._uuid,
   changes: {
    array: this._normals.array.buffer.slice(0),
    itemSize: this._normals.itemSize
   }
  }, this._onChangeListener.geometryUpdate(e)), this._normals.target = BufferAttribute.TARGET.ARRAY_BUFFER;
 }
 set tangents(e) {
  this._tangents = e, this._onChangeListener && (e = {
   uuid: this._uuid,
   changes: {
    array: this._tangents.array.buffer.slice(0),
    itemSize: this._tangents.itemSize
   }
  }, this._onChangeListener.geometryUpdate(e)), this._tangents.target = BufferAttribute.TARGET.ARRAY_BUFFER;
 }
 set bitangents(e) {
  this._bitangents = e, this._onChangeListener && (e = {
   uuid: this._uuid,
   changes: {
    array: this._bitangents.array.buffer.slice(0),
    itemSize: this._bitangents.itemSize
   }
  }, this._onChangeListener.geometryUpdate(e)), this._bitangents.target = BufferAttribute.TARGET.ARRAY_BUFFER;
 }
 set vertColor(e) {
  this._vertColor = e, this._onChangeListener && (e = {
   uuid: this._uuid,
   changes: {
    array: this._vertColor.array.buffer.slice(0),
    itemSize: this._vertColor.itemSize
   }
  }, this._onChangeListener.geometryUpdate(e)), this._vertColor.target = BufferAttribute.TARGET.ARRAY_BUFFER;
 }
 set uv(e) {
  this._uv = e, this._uv.target = BufferAttribute.TARGET.ARRAY_BUFFER;
 }
 set wireframeIndices(e) {
  this._wireframeIndices = e, this._wireframeIndices.target = BufferAttribute.TARGET.ELEMENT_ARRAY_BUFFER;
 }
 set MMat(e) {
  this._MMat = e, this._MMat.target = BufferAttribute.TARGET.ARRAY_BUFFER;
 }
 set translation(e) {
  this._translation = e, this._translation.target = BufferAttribute.TARGET.ARRAY_BUFFER;
 }
 set drawWireframe(e) {
  this._drawWireframe = e;
 }
 set onChangeListener(e) {
  this._onChangeListener = e;
 }
 toJson() {
  var e = {};
  return e._uuid = this._uuid, e.type = this.type, this._indices && (e.indices = {
   array: this._indices.array.buffer.slice(0),
   itemSize: this._indices.itemSize
  }), this._vertices && (e.vertices = {
   array: this._vertices.array.buffer.slice(0),
   itemSize: this._vertices.itemSize
  }), this._normals && (e.normals = {
   array: this._normals.array.buffer.slice(0),
   itemSize: this._normals.itemSize
  }), this._vertColor && (e.vertColor = {
   array: this._vertColor.array.buffer.slice(0),
   itemSize: this._vertColor.itemSize
  }), e;
 }
 static fromJson(e) {
  var t = new Geometry();
  return t._uuid = e._uuid, e.indices && (t._indices = Uint32Attribute(e.indices.array, e.indices.itemSize)), 
  e.vertices && (t._vertices = Float32Attribute(e.vertices.array, e.vertices.itemSize)), 
  e.normals && (t._normals = Float32Attribute(e.normals.array, e.normals.itemSize)), 
  e.vertColor && (t._vertColor = Float32Attribute(e.vertColor.array, e.vertColor.itemSize)), 
  t;
 }
 update(e) {
  for (var t in e) switch (t) {
  case "indices":
   this.indices = Uint32Attribute(e.indices.array, e.indices.itemSize), delete e.indices;
   break;

  case "vertices":
   this.vertices = Float32Attribute(e.vertices.array, e.vertices.itemSize), delete e.vertices;
   break;

  case "normals":
   this.normals = Float32Attribute(e.normals.array, e.normals.itemSize), delete e.normals;
   break;

  case "tangents":
   this.tangents = Float32Attribute(e.tangents.array, e.tangents.itemSize), delete e.tangents;
   break;

  case "bitangents":
   this.bitangents = Float32Attribute(e.bitangents.array, e.bitangents.itemSize), 
   delete e.bitangents;
   break;

  case "vertColor":
   this.vertColor = Float32Attribute(e.vertColor.array, e.vertColor.itemSize), delete e.vertColor;
   break;

  default:
   console.warn("Uknown property!");
  }
 }
}

class Material {
 constructor() {
  if (new.target === Material) throw new TypeError("Cannot construct abstract Material class.");
  this._uuid = _Math.generateUUID(), this.type = "Material", this._onChangeListener = null, 
  this._name = "", this._side = FRONT_SIDE, this._depthFunc = FUNC_LEQUAL, this._depthTest = !0, 
  this._depthWrite = !0, this._transparent = !1, this._opacity = 1, this._useVertexColors = !1, 
  this.requiredProgramTemplate = null, this._usePoints = !1, this._pointSize = 1, 
  this._pointsScale = !0, this._drawCircles = !1, this._useClippingPlanes = !1, 
  this._clippingPlanes = null, this._programName = "base", this._shadingType = SmoothShading, 
  this._lights = !0, this._maps = [], this._cubemaps = [], this._diffuseMap = null, 
  this._specularMap = null, this._normalMap = null, this._heightMap = null, this._instanceData = [], 
  this._normalFlat = !1, this._heightScale = .125, this._blinn = !0, this._flags = [], 
  this._values = {}, this._instanced = !1, this._instancedTranslation = !1, this._receiveShadows = !0;
 }
 get requiredProgramTemplate() {
  return this._requiredProgramTemplate;
 }
 set requiredProgramTemplate(e) {
  this._requiredProgramTemplate = e;
 }
 set onChangeListener(e) {
  this._onChangeListener = e;
 }
 set name(e) {
  e !== this._name && (this._name = e, this._onChangeListener) && (e = {
   uuid: this._uuid,
   changes: {
    name: this._name
   }
  }, this._onChangeListener.materialUpdate(e));
 }
 set side(e) {
  e !== this._side && (this._side = e, this._onChangeListener) && (e = {
   uuid: this._uuid,
   changes: {
    side: this._side
   }
  }, this._onChangeListener.materialUpdate(e));
 }
 set depthFunc(e) {
  e !== this._depthFunc && (this._depthFunc = e, this._onChangeListener) && (e = {
   uuid: this._uuid,
   changes: {
    depthFunc: this._depthFunc
   }
  }, this._onChangeListener.materialUpdate(e));
 }
 set depthTest(e) {
  e !== this._depthTest && (this._depthTest = e, this._onChangeListener) && (e = {
   uuid: this._uuid,
   changes: {
    depthTest: this._depthTest
   }
  }, this._onChangeListener.materialUpdate(e));
 }
 set depthWrite(e) {
  e !== this._depthWrite && (this._depthWrite = e, this._onChangeListener) && (e = {
   uuid: this._uuid,
   changes: {
    depthWrite: this._depthWrite
   }
  }, this._onChangeListener.materialUpdate(e));
 }
 set transparent(e) {
  e !== this._transparent && (this._transparent = e, this._onChangeListener) && (e = {
   uuid: this._uuid,
   changes: {
    transparent: this._transparent
   }
  }, this._onChangeListener.materialUpdate(e));
 }
 set opacity(e) {
  e !== this._opacity && (this._opacity = e, this._onChangeListener) && (e = {
   uuid: this._uuid,
   changes: {
    opacity: this._opacity
   }
  }, this._onChangeListener.materialUpdate(e));
 }
 set useVertexColors(e) {
  e !== this._useVertexColors && (this.requiredProgramTemplate = null, this._useVertexColors = e, 
  this._onChangeListener) && (e = {
   uuid: this._uuid,
   changes: {
    useVertexColors: this._useVertexColors
   }
  }, this._onChangeListener.materialUpdate(e));
 }
 set usePoints(e) {
  e !== this._usePoints && (this.requiredProgramTemplate = null, this._usePoints = e, 
  this._onChangeListener) && (e = {
   uuid: this._uuid,
   changes: {
    usePoints: this._usePoints
   }
  }, this._onChangeListener.materialUpdate(e));
 }
 set pointSize(e) {
  e !== this._pointSize && (this.requiredProgramTemplate = null, this._pointSize = e, 
  this._onChangeListener) && (e = {
   uuid: this._uuid,
   changes: {
    pointSize: this._pointSize
   }
  }, this._onChangeListener.materialUpdate(e));
 }
 set pointsScale(e) {
  e !== this._pointsScale && (this.requiredProgramTemplate = null, this._pointsScale = e, 
  this._onChangeListener) && (e = {
   uuid: this._uuid,
   changes: {
    pointsScale: this._pointsScale
   }
  }, this._onChangeListener.materialUpdate(e));
 }
 set drawCircles(e) {
  e !== this._drawCircles && (this.requiredProgramTemplate = null, this._drawCircles = e, 
  this._onChangeListener) && (e = {
   uuid: this._uuid,
   changes: {
    drawCircles: this._drawCircles
   }
  }, this._onChangeListener.materialUpdate(e));
 }
 set useClippingPlanes(e) {
  e !== this._useClippingPlanes && (this.requiredProgramTemplate = null, this._useClippingPlanes = e, 
  this._onChangeListener) && (e = {
   uuid: this._uuid,
   changes: {
    useClippingPlanes: this._useClippingPlanes
   }
  }, this._onChangeListener.materialUpdate(e));
 }
 set clippingPlanes(e) {
  e !== this._clippingPlanes && (this.requiredProgramTemplate = null, this._clippingPlanes = e, 
  this._onChangeListener) && (e = {
   uuid: this._uuid,
   changes: {
    clippingPlanes: this._clippingPlanes
   }
  }, this._onChangeListener.materialUpdate(e));
 }
 set shadingType(e) {
  e !== this._shadingType && (this.requiredProgramTemplate = null, this._shadingType = e, 
  this._onChangeListener) && (e = {
   uuid: this._uuid,
   changes: {
    shadingType: this._shadingType
   }
  }, this._onChangeListener.materialUpdate(e));
 }
 set instanced(e) {
  e !== this._instanced && (this.requiredProgramTemplate = null, this._instanced = e, 
  this._onChangeListener) && (e = {
   uuid: this._uuid,
   changes: {
    instanced: this._instanced
   }
  }, this._onChangeListener.materialUpdate(e));
 }
 set instancedTranslation(e) {
  e !== this._instancedTranslation && (this.requiredProgramTemplate = null, this._instancedTranslation = e, 
  this._onChangeListener) && (e = {
   uuid: this._uuid,
   changes: {
    instancedTranslation: this._instancedTranslation
   }
  }, this._onChangeListener.materialUpdate(e));
 }
 set heightScale(e) {
  e !== this._heightScale && (this.requiredProgramTemplate = null, this._heightScale = e, 
  this._onChangeListener) && (e = {
   uuid: this._uuid,
   changes: {
    heightScale: this._heightScale
   }
  }, this._onChangeListener.materialUpdate(e));
 }
 set blinn(e) {
  e !== this._blinn && (this.requiredProgramTemplate = null, this._blinn = e, this._onChangeListener) && (e = {
   uuid: this._uuid,
   changes: {
    blinn: this._blinn
   }
  }, this._onChangeListener.materialUpdate(e));
 }
 set receiveShadows(e) {
  e !== this._receiveShadows && (this.requiredProgramTemplate = null, this._receiveShadows = e, 
  this._onChangeListener) && (e = {
   uuid: this._uuid,
   changes: {
    receiveShadows: this._receiveShadows
   }
  }, this._onChangeListener.materialUpdate(e));
 }
 set lights(e) {
  this._lights !== e && (this.requiredProgramTemplate = null, this._lights = e, 
  this._onChangeListener) && (e = {
   uuid: this._uuid,
   changes: {
    lights: this._lights
   }
  }, this._onChangeListener.materialUpdate(e));
 }
 set programName(e) {
  this._programName = e;
 }
 get name() {
  return this._name;
 }
 get side() {
  return this._side;
 }
 get depthFunc() {
  return this._depthFunc;
 }
 get depthTest() {
  return this._depthTest;
 }
 get depthWrite() {
  return this._depthWrite;
 }
 get transparent() {
  return this._transparent;
 }
 get opacity() {
  return this._opacity;
 }
 get useVertexColors() {
  return this._useVertexColors;
 }
 get usePoints() {
  return this._usePoints;
 }
 get pointSize() {
  return this._pointSize;
 }
 get pointsScale() {
  return this._pointsScale;
 }
 get drawCircles() {
  return this._drawCircles;
 }
 get useClippingPlanes() {
  return this._useClippingPlanes;
 }
 get clippingPlanes() {
  return this._clippingPlanes;
 }
 get shadingType() {
  return this._shadingType;
 }
 get instanced() {
  return this._instanced;
 }
 get instancedTranslation() {
  return this._instancedTranslation;
 }
 get heightScale() {
  return this._heightScale;
 }
 get blinn() {
  return this._blinn;
 }
 get receiveShadows() {
  return this._receiveShadows;
 }
 get lights() {
  return this._lights;
 }
 get maps() {
  return this._maps;
 }
 get cubemaps() {
  return this._cubemaps;
 }
 get diffuseMap() {
  return this._diffuseMap;
 }
 get specularMap() {
  return this._specularMap;
 }
 get normalMap() {
  return this._normalMap;
 }
 get heightMap() {
  return this._heightMap;
 }
 get instanceData() {
  return this._instanceData;
 }
 get normalFlat() {
  return this._normalFlat;
 }
 set normalFlat(e) {
  this.requiredProgramTemplate = null, this._normalFlat = e;
 }
 get programName() {
  return this._programName;
 }
 get programName2() {
  switch (this.shadingType) {
  case FlatShading:
   return this.programName + "-FLAT";

  case GouraudShading:
   return this.programName + "-GOURAUD";

  case PhongShading:
   return this.programName + "-PHONG";

  default:
   SmoothShading;
   return this.programName;
  }
 }
 get values() {
  return this._values;
 }
 set values(e) {
  this._values = e;
 }
 get flags() {
  return this._flags;
 }
 set flags(e) {
  this._flags = e;
 }
 addMap(e) {
  this.requiredProgramTemplate = null, this._maps.push(e);
 }
 addCubemap(e) {
  this.requiredProgramTemplate = null, this._cubemaps.push(e);
 }
 set diffuseMap(e) {
  this.requiredProgramTemplate = null, this._diffuseMap = e;
 }
 set specularMap(e) {
  this.requiredProgramTemplate = null, this._specularMap = e;
 }
 set normalMap(e) {
  this.requiredProgramTemplate = null, this._normalMap = e;
 }
 set heightMap(e) {
  this.requiredProgramTemplate = null, this._heightMap = e;
 }
 addInstanceData(e) {
  this.requiredProgramTemplate = null, this._instanceData.push(e);
 }
 removeMap(e) {
  e = this._maps.indexOf(e);
  -1 < e && (this.requiredProgramTemplate = null, this._maps.splice(e, 1));
 }
 removeCubemap(e) {
  e = this._cubemaps.indexOf(e);
  -1 < e && (this.requiredProgramTemplate = null, this._cubemaps.splice(e, 1));
 }
 clearMaps() {
  this.requiredProgramTemplate = null, this._maps = [];
 }
 clearCubemaps() {
  this.requiredProgramTemplate = null, this._cubemaps = [];
 }
 resetProgramFlagsAndValues() {
  this._flags = [], this._values = {}, this._lights && this._flags.push("LIGHTS"), 
  this._useVertexColors && this._flags.push("COLORS"), 0 < this._maps.length && (this._flags.push("TEXTURE"), 
  this._values.NUM_TEX = this._maps.length), 0 < this._cubemaps.length && (this._flags.push("CUBETEXTURES"), 
  this._values.NUM_CUBETEXTURES = this._cubemaps.length), this._side === FRONT_SIDE ? this._flags.push("FRONT_SIDE") : this._side === BACK_SIDE ? this._flags.push("BACK_SIDE") : this._side === FRONT_AND_BACK_SIDE && this._flags.push("FRONT_AND_BACK_SIDE"), 
  this._usePoints && this._flags.push("POINTS"), this._pointsScale && this._flags.push("POINTS_SCALE"), 
  this._drawCircles && this.flags.push("CIRCLES"), this._useClippingPlanes && (this._flags.push("CLIPPING_PLANES"), 
  this._values.NUM_CLIPPING_PLANES = this._clippingPlanes.length), this._shadingType === SmoothShading ? this._flags.push("SMOOTH_SHADING") : this._flags.push("FLAT_SHADING"), 
  !0 === this._transparent && this._flags.push("TRANSPARENT"), !0 === this._instanced && this._flags.push("INSTANCED"), 
  !0 === this._instancedTranslation && this._flags.push("INSTANCED_TRANSLATION"), 
  this._diffuseMap && this._flags.push("DIFFUSE_MAP"), this._specularMap && this._flags.push("SPECULAR_MAP"), 
  this._normalMap && this._flags.push("NORMAL_MAP"), this._heightMap && this._flags.push("HEIGHT_MAP"), 
  this._normalFlat && this._flags.push("NORMAL_FLAT");
 }
 toJson() {
  var e = {};
  return e._uuid = this._uuid, e.type = this.type, e.name = this._name, e.side = this._side, 
  e.depthFunc = this._depthFunc, e.depthTest = this._depthTest, e.depthWrite = this._depthWrite, 
  e.transparent = this._transparent, e.opacity = this._opacity, e.useVertexColors = this._useVertexColors, 
  e.lights = this._lights, e;
 }
 static fromJson(e, t) {
  return (t = t || new Material())._uuid = e._uuid, t._name = e.name, t._side = e.side, 
  t._depthFunc = e.depthFunc, t._depthTest = e.depthTest, t._depthWrite = e.depthWrite, 
  t._transparent = e.transparent, t._opacity = e.opacity, t._useVertexColors = e.useVertexColors, 
  t._lights = e.lights, t;
 }
 update(e) {
  for (var t in e) switch (t) {
  case "opacity":
   this._opacity = e.opacity, delete e.opacity;
   break;

  case "transparent":
   this._transparent = e.transparent, delete e.transparent;
   break;

  case "side":
   this._side = e.side, delete e.side;
   break;

  case "depthFunc":
   this._depthFunc = e.depthFunc, delete e.depthFunc;
   break;

  case "depthTest":
   this._depthTest = e.depthTest, delete e.depthTest;
   break;

  case "depthWrite":
   this._depthWrite = e.depthWrite, delete e.depthWrite;
   break;

  case "useVertexColors":
   this._useVertexColors = e.useVertexColors, delete e.useVertexColors;
   break;

  case "name":
   this._name = e.name, delete e.name;
   break;

  case "usePoints":
   this._usePoints = e.usePoints, delete e.usePoints;
   break;

  case "pointSize":
   this._pointSize = e.pointSize, delete e.pointSize;
   break;

  case "pointsScale":
   this._pointsScale = e.pointsScale, delete e.pointsScale;
   break;

  case "drawCircles":
   this._drawCircles = e.drawCircles, delete e.drawCircles;
   break;

  case "useClippingPlanes":
   this._useClippingPlanes = e.useClippingPlanes, delete e.useClippingPlanes;
   break;

  case "clippingPlanes":
   this._clippingPlanes = e.clippingPlanes, delete e.clippingPlanes;
   break;

  case "shadingType":
   this._shadingType = e.shadingType, delete e.shadingType;
   break;

  case "instanced":
   this._instanced = e.instanced, delete e.instanced;
   break;

  case "instancedTranslation":
   this._instancedTranslation = e.instancedTranslation, delete e.instancedTranslation;
   break;

  case "lights":
   this._lights = e.lights, delete e.lights;
  }
 }
}

class MaterialProgramTemplate {
 constructor(e, t, i, r = void 0) {
  this.name = e, this.flags = t, this.values = i, this.programID = this._generateProgramID(r);
 }
 _generateProgramID(e = void 0) {
  for (var t = this.flags.sort(), i = Object.keys(this.values).sort(), r = this.name, s = 0; s < t.length; s++) r += "|" + t[s];
  for (s = 0; s < i.length; s++) r += i[s] + this.values[i[s]];
  return void 0 !== e ? e.generateMaterialID(r) : r;
 }
 compare(e) {
  return this.programID === e.programID;
 }
}

class MeshBasicMaterial extends Material {
 constructor() {
  super(Material), this.type = "MeshBasicMaterial", this._emissive = new Color(0 * Math.random()), 
  this._color = new Color(16777215 * Math.random()), this.programName = "basic";
 }
 set emissive(e) {
  e.equals(this._emissive) || (this._emissive = e, this._onChangeListener && (e = {
   uuid: this._uuid,
   changes: {
    emissive: this._emissive.getHex()
   }
  }, this._onChangeListener.materialUpdate(e)));
 }
 set color(e) {
  e.equals(this._color) || (this._color = e, this._onChangeListener && (e = {
   uuid: this._uuid,
   changes: {
    color: this._color.getHex()
   }
  }, this._onChangeListener.materialUpdate(e)));
 }
 get emissive() {
  return this._emissive;
 }
 get color() {
  return this._color;
 }
 resetProgramFlagsAndValues() {
  super.resetProgramFlagsAndValues();
 }
 requiredProgram(e = void 0) {
  return null === this.requiredProgramTemplate && (this.resetProgramFlagsAndValues(), 
  this.requiredProgramTemplate = new MaterialProgramTemplate(this.programName2, this.flags, this.values, e)), 
  this.requiredProgramTemplate;
 }
 toJson() {
  var e = super.toJson();
  return e.emissive = this._emissive.getHex(), e.color = this._color.getHex(), e;
 }
 static fromJson(e) {
  var t = new MeshBasicMaterial();
  return (t = super.fromJson(e, t))._emissive = new Color(e.emissive), t._color = new Color(e.color), 
  t;
 }
 update(e) {
  for (var t in super.update(e), e) switch (t) {
  case "emissive":
   this._emissive = e.emissive, delete e.color;
   break;

  case "color":
   this._color = e.color, delete e.color;
  }
 }
}

let MeshPhongMaterial$1 = class MeshPhongMaterial extends Material {
 constructor() {
  super(Material), this.type = "MeshPhongMaterial", this._color = new Color(16777215 * Math.random()), 
  this._specular = new Color(16777215 * Math.random()), this._shininess = 16 * Math.random(), 
  this.programName = "phong";
 }
 set color(e) {
  this._color = e, this._onChangeListener && (e = {
   uuid: this._uuid,
   changes: {
    color: this._color.getHex()
   }
  }, this._onChangeListener.materialUpdate(e));
 }
 set specular(e) {
  this._specular = e, this._onChangeListener && (e = {
   uuid: this._uuid,
   changes: {
    specular: this._specular.getHex()
   }
  }, this._onChangeListener.materialUpdate(e));
 }
 set shininess(e) {
  this._shininess = e, this._onChangeListener && (e = {
   uuid: this._uuid,
   changes: {
    shininess: this._shininess
   }
  }, this._onChangeListener.materialUpdate(e));
 }
 get color() {
  return this._color;
 }
 get specular() {
  return this._specular;
 }
 get shininess() {
  return this._shininess;
 }
 resetProgramFlagsAndValues() {
  super.resetProgramFlagsAndValues();
 }
 requiredProgram(e = void 0) {
  return null === this.requiredProgramTemplate && (this.resetProgramFlagsAndValues(), 
  this.requiredProgramTemplate = new MaterialProgramTemplate(this.programName2, this.flags, this.values, e)), 
  this.requiredProgramTemplate;
 }
 toJson() {
  var e = super.toJson();
  return e.color = this._color.getHex(), e.specular = this._specular.getHex(), e.shininess = this._shininess, 
  e;
 }
 static fromJson(e) {
  var t = new MeshPhongMaterial();
  return (t = super.fromJson(e, t))._color = new Color(e.color), t._specular = new Color(e.specular), 
  t._shininess = e.shininess, t;
 }
 update(e) {
  for (var t in super.update(e), e) switch (t) {
  case "color":
   this._color.setHex(e.color), delete e.color;
   break;

  case "specular":
   this._specular.setHex(e.specular), delete e.specular;
   break;

  case "shininess":
   this._shininess = e.shininess, delete e.shininess;
  }
 }
};

class Object3D {
 constructor() {
  var e = this;
  this._uuid = _Math.generateUUID(), this.type = "Object3D", this._parent = null, 
  this._children = [], this._position = new Vector3(), this._rotation = new Euler(), 
  this._quaternion = new Quaternion(), this._scale = new Vector3(1, 1, 1), this._visible = !0, 
  this._frustumCulled = !0, this._rotation._onChange(function() {
   e.quaternion.setFromEuler(e.rotation, !1);
  }), this._quaternion._onChange(function() {
   e.rotation.setFromQuaternion(e.quaternion, void 0, !1);
  }), this._matrix = new Matrix4(), this._matrixWorld = new Matrix4(), this._matrixWorldNeedsUpdate = !1, 
  this._modelViewMatrix = new Matrix4(), this._normalMatrix = new Matrix3(), this._modelViewProjectionMatrix = new Matrix4(), 
  this._matrixAutoUpdate = !0, this._onChangeListener = null, this.rotateOnAxis = rotateOnAxis, 
  this.rotateX = rotateX, this.rotateY = rotateY, this.rotateZ = rotateZ, this.rotate = rotate, 
  this.lookAt = lookAt, this.translateOnAxis = translateOnAxis, this.translateX = translateX, 
  this.translateY = translateY, this.translateZ = translateZ, this.translate = translate, 
  this._renderOrder = 0, this._isStatic = !1, this._staticStateDirty = !0, this._renderingPrimitive = TRIANGLES, 
  this._pickable = !1, this._zVector = new Vector3(), this._boundingSphere = new Sphere(new Vector3(0, 0, 0), 1 / 0);
 }
 get parent() {
  return this._parent;
 }
 get children() {
  return this._children;
 }
 get position() {
  return this._position;
 }
 get positionX() {
  return this._position.x;
 }
 get positionY() {
  return this._position.y;
 }
 get positionZ() {
  return this._position.z;
 }
 get rotation() {
  return this._rotation;
 }
 get rotationX() {
  return this._rotation.x;
 }
 get rotationY() {
  return this._rotation.y;
 }
 get rotationZ() {
  return this._rotation.z;
 }
 get quaternion() {
  return this._quaternion;
 }
 get scale() {
  return this._scale;
 }
 get matrixAutoUpdate() {
  return this._matrixAutoUpdate;
 }
 get matrixWorld() {
  return this._matrixWorld;
 }
 get visible() {
  return this._visible;
 }
 get frustumCulled() {
  return this._frustumCulled;
 }
 get renderOrder() {
  return this._renderOrder;
 }
 get isStatic() {
  return this._isStatic;
 }
 get staticStateDirty() {
  return this._staticStateDirty;
 }
 get renderingPrimitive() {
  return this._renderingPrimitive;
 }
 get pickable() {
  return this._pickable;
 }
 get matrix() {
  return this._matrix;
 }
 set matrix(e) {
  this._matrix = e, this._matrixWorldNeedsUpdate = !0;
 }
 setMatrixFromArray(e) {
  this._matrix.fromArray(e), this._matrixWorldNeedsUpdate = !0;
 }
 get modelViewMatrix() {
  return this._modelViewMatrix;
 }
 get normalMatrix() {
  return this._normalMatrix;
 }
 get modelViewProjectionMatrix() {
  return this._modelViewProjectionMatrix;
 }
 set visible(e) {
  this._visible !== e && (this._visible = e, this._onChangeListener) && (e = {
   uuid: this._uuid,
   changes: {
    visible: this._visible
   }
  }, this._onChangeListener.objectUpdate(e));
 }
 set position(e) {
  e.equals(this._position) || (this._position.copy(e), this._onChangeListener && (e = {
   uuid: this._uuid,
   changes: {
    position: this._position.toArray()
   }
  }, this._onChangeListener.objectUpdate(e)));
 }
 set positionX(e) {
  this._position.x !== e && (this._position.x = e, this._onChangeListener) && (e = {
   uuid: this._uuid,
   changes: {
    position: this._position.toArray()
   }
  }, this._onChangeListener.objectUpdate(e));
 }
 set positionY(e) {
  this._position.y !== e && (this._position.y = e, this._onChangeListener) && (e = {
   uuid: this._uuid,
   changes: {
    position: this._position.toArray()
   }
  }, this._onChangeListener.objectUpdate(e));
 }
 set positionZ(e) {
  this._position.z !== e && (this._position.z = e, this._onChangeListener) && (e = {
   uuid: this._uuid,
   changes: {
    position: this._position.toArray()
   }
  }, this._onChangeListener.objectUpdate(e));
 }
 set rotation(e) {
  e.equals(this._rotation) || (this._rotation.copy(e), this._onChangeListener && (e = {
   uuid: this._uuid,
   changes: {
    quaternion: this._quaternion.toArray()
   }
  }, this._onChangeListener.objectUpdate(e)));
 }
 set rotationX(e) {
  this._rotation.x !== e && (this._rotation.x = e, this._onChangeListener) && (e = {
   uuid: this._uuid,
   changes: {
    quaternion: this._quaternion.toArray()
   }
  }, this._onChangeListener.objectUpdate(e));
 }
 set rotationY(e) {
  this._rotation.y !== e && (this._rotation.y = e, this._onChangeListener) && (e = {
   uuid: this._uuid,
   changes: {
    quaternion: this._quaternion.toArray()
   }
  }, this._onChangeListener.objectUpdate(e));
 }
 set rotationZ(e) {
  this._rotation.z !== e && (this._rotation.z = e, this._onChangeListener) && (e = {
   uuid: this._uuid,
   changes: {
    quaternion: this._quaternion.toArray()
   }
  }, this._onChangeListener.objectUpdate(e));
 }
 set quaternion(e) {
  e.equals(this._quaternion) || (this._quaternion.copy(e), this._onChangeListener && (e = {
   uuid: this._uuid,
   changes: {
    quaternion: this._quaternion.toArray()
   }
  }, this._onChangeListener.objectUpdate(e)));
 }
 set scale(e) {
  e.equals(this._scale) || (this._scale = e, this._onChangeListener && (e = {
   uuid: this._uuid,
   changes: {
    scale: this._scale.toArray()
   }
  }, this._onChangeListener.objectUpdate(e)));
 }
 set matrixAutoUpdate(e) {
  e !== this._matrixAutoUpdate && (this._matrixAutoUpdate = e, this._onChangeListener) && (e = {
   uuid: this._uuid,
   changes: {
    matrixAutoUpdate: this._matrixAutoUpdate
   }
  }, this._onChangeListener.objectUpdate(e));
 }
 set frustumCulled(e) {
  e !== this._frustumCulled && (this._frustumCulled = e, this._onChangeListener) && (e = {
   uuid: this._uuid,
   changes: {
    frustumCulled: this._frustumCulled
   }
  }, this._onChangeListener.objectUpdate(e));
 }
 set renderOrder(e) {
  e !== this._renderOrder && (this._renderOrder = e, this._onChangeListener) && (e = {
   uuid: this._uuid,
   changes: {
    renderOrder: this._renderOrder
   }
  }, this._onChangeListener.objectUpdate(e));
 }
 set isStatic(e) {
  e !== this._isStatic && (this._isStatic = e, this._onChangeListener) && (e = {
   uuid: this._uuid,
   changes: {
    isStatic: this._isStatic
   }
  }, this._onChangeListener.objectUpdate(e));
 }
 set staticStateDirty(e) {
  e !== this._staticStateDirty && (this._staticStateDirty = e, this._onChangeListener) && (e = {
   uuid: this._uuid,
   changes: {
    staticStateDirty: this._staticStateDirty
   }
  }, this._onChangeListener.objectUpdate(e));
 }
 set renderingPrimitive(e) {
  e !== this._renderingPrimitive && (this._renderingPrimitive = e, this._onChangeListener) && (e = {
   uuid: this._uuid,
   changes: {
    renderingPrimitive: this._renderingPrimitive
   }
  }, this._onChangeListener.objectUpdate(e));
 }
 set pickable(e) {
  e !== this._pickable && (this._pickable = e, this._onChangeListener) && (e = {
   uuid: this._uuid,
   changes: {
    pickable: this._pickable
   }
  }, this._onChangeListener.objectUpdate(e));
 }
 set modelViewMatrix(e) {
  this._modelViewMatrix = e;
 }
 set normalMatrix(e) {
  this._normalMatrix = e;
 }
 set modelViewProjectionMatrix(e) {
  this._modelViewProjectionMatrix = e;
 }
 addOnChangeListener(e, t) {
  if (this._onChangeListener = e, t) for (var i = 0; i < this._children.length; i++) this._children[i].addOnChangeListener(e, t);
 }
 applyMatrix(e) {
  this._matrix.multiplyMatrices(e, this._matrix), this._matrix.decompose(this._position, this._quaternion, this._scale), 
  this._onChangeListener && (e = {
   uuid: this._uuid,
   changes: {
    position: this._position.toArray(),
    quaternion: this._quaternion.toArray(),
    scale: this._scale.toArray()
   }
  }, this._onChangeListener.objectUpdate(e));
 }
 updateMatrix() {
  this._matrix.compose(this._position, this._quaternion, this._scale), this._matrixWorldNeedsUpdate = !0, 
  this._UPDATE_BOUNDS = !0;
 }
 updateMatrixWorld(e = !1) {
  this._matrixAutoUpdate && this.updateMatrix(), (this._matrixWorldNeedsUpdate || e) && (null === this.parent ? this._matrixWorld.copy(this._matrix) : this._matrixWorld.multiplyMatrices(this.parent._matrixWorld, this._matrix), 
  this._matrixWorldNeedsUpdate = !1, this._UPDATE_BOUNDS = e = !0);
  for (var t = 0; t < this._children.length; t++) this._children[t].updateMatrixWorld(e);
 }
 updateWorldMatrix(e, t) {
  var i = this.parent;
  if (!0 === e && null !== i && i.updateWorldMatrix(!0, !1), this.matrixAutoUpdate && this.updateMatrix(), 
  null === this.parent ? this.matrixWorld.copy(this._matrix) : this.matrixWorld.multiplyMatrices(this.parent.matrixWorld, this._matrix), 
  (this._UPDATE_BOUNDS = !0) === t) for (var r = this.children, s = r.length; 0 < s; ) r[0].updateWorldMatrix(!1, !0);
 }
 add(e) {
  e !== this && (null !== e._parent && e._parent.remove(e), (e._parent = this)._children.push(e), 
  this._onChangeListener) && (e.onChangeListener = this._onChangeListener, e = {
   uuid: e._uuid,
   changes: {
    parentUuid: this._uuid,
    objectRef: e
   }
  }, this._onChangeListener.hierarchyUpdate(e));
 }
 remove(e) {
  var t = this._children.indexOf(e);
  -1 !== t && (e._parent = null, this._children.splice(t, 1), this._onChangeListener) && (t = {
   uuid: e._uuid,
   changes: {
    parentUuid: null,
    objectRef: e
   }
  }, this._onChangeListener.hierarchyUpdate(t));
 }
 clear() {
  let t = this;
  this._children = this._children.filter(function(e) {
   return t._onChangeListener && (e = {
    uuid: e._uuid,
    changes: {
     parentUuid: null,
     objectRef: e
    }
   }, t._onChangeListener.hierarchyUpdate(e)), !1;
  });
 }
 traverse(i) {
  i(this);
  for (let e = 0, t = this._children.length; e < t; e++) this._children[e].traverse(i);
 }
 raycast() {}
 computeBoundingSphere() {
  let t = [];
  return this.traverse(function(e) {
   e instanceof Mesh && null != e.geometry && (e = e.geometry.boundingSphere, !isNaN(e.radius)) && 0 < e.radius && t.push(e);
  }), 0 < t.length ? _Math.computeSpheresBoundingSphere(t) : new Sphere();
 }
 toJson() {
  var e = {};
  return e.uuid = this._uuid, e.type = this.type, this._parent && (e.parentUuid = this._parent._uuid), 
  e.position = this._position.toArray(), e.quaternion = this._quaternion.toArray(), 
  e.scale = this._scale.toArray(), e.visible = this._visible, e.frustumCulled = this._frustumCulled, 
  e.matrixAutoUpdate = this._matrixAutoUpdate, e;
 }
 static fromJson(e, t) {
  return (t = t || new Object3D())._uuid = e.uuid, t._position.fromArray(e.position), 
  t._quaternion.fromArray(e.quaternion), t._scale.fromArray(e.scale), t._visible = e.visible, 
  t._frustumCulled = e.frustumCulled, t._matrixWorldNeedsUpdate = !0, t._matrixAutoUpdate = e.matrixAutoUpdate, 
  t;
 }
 static importHierarchy(e, t, i) {
  var r, s = {};
  for (r of Object.keys(e)) switch ((u = e[r]).type) {
  case "Mesh":
  case "Circle":
  case "Quad":
  case "Line":
   var a = t[u.geometryUuid], n = i[u.materialUuid];
   if (a ? a = Geometry.fromJson(a) : (a = void 0, console.warn("Could not find geometry for the mesh: " + u.uuid)), 
   n) switch (n.type) {
   case "Material":
    n = Material.fromJson(n);
    break;

   case "MeshBasicMaterial":
    n = MeshBasicMaterial.fromJson(n);
    break;

   case "MeshPhongMaterial":
    n = MeshPhongMaterial$1.fromJson(n);
    break;

   default:
    n = void 0;
   } else n = void 0, console.warn("Could not find material for the mesh: " + u.uuid);
   s[u.uuid] = Mesh.fromJson(u, a, n);
   break;

  default:
   s[u.uuid] = RC[u.type].fromJson(u);
  }
  var o, h = [];
  for (o of Object.keys(e)) {
   var u = s[o], l = e[o].parentUuid;
   (l && (l = s[l]) ? (u._parent = l).children : h).push(u);
  }
  return h;
 }
 exportHierarchy(e, t) {
  e.objects && e.geometries && e.materials || (e.objects = {}, e.geometries = {}, 
  e.materials = {});
  var i = this.toJson();
  t || delete i.parentUuid, e.objects[i.uuid] = i, "Mesh" !== this.type && "Quad" !== this.type && "Circle" !== this.type && "Line" !== this.type || (e.geometries[this._geometry._uuid] = this._geometry.toJson(), 
  e.materials[this._material._uuid] = this._material.toJson());
  for (var r = 0; r < this.children.length; r++) this._children[r].exportHierarchy(e, !0);
 }
 update(e) {
  for (var t in e) switch (t) {
  case "position":
   this._position.fromArray(e.position), delete e.position;
   break;

  case "quaternion":
   this._quaternion.fromArray(e.quaternion), delete e.quaternion;
   break;

  case "scale":
   this._scale.fromArray(e.scale), delete e.scale;
   break;

  case "visible":
   this._visible = e.visible, delete e.visible;
   break;

  case "frustumCulled":
   this._frustumCulled = e.frustumCulled, delete e.frustumCulled;
   break;

  case "matrixAutoUpdate":
   this._matrixAutoUpdate = e.matrixAutoUpdate, delete e.matrixAutoUpdate;
  }
 }
 fillRenderArray(e) {
  throw console.warn("-----------------------------------------------"), console.warn(this), 
  console.warn("Object has missing method: fillRenderArray"), console.warn("-----------------------------------------------"), 
  new Error("Not implemented");
 }
 project(e) {
  throw console.warn("-----------------------------------------------"), console.warn(this), 
  console.warn("Object has missing method: project missing"), console.warn("-----------------------------------------------"), 
  new Error("Not implemented");
 }
 getRequiredPrograms(e) {
  throw console.warn("-----------------------------------------------"), console.warn(this), 
  console.warn("Object has missing method: getRequiredPrograms"), console.warn("-----------------------------------------------"), 
  new Error("Not implemented");
 }
 update(e, t) {
  throw console.warn("-----------------------------------------------"), console.warn(this), 
  console.warn("Object has missing method: update"), console.warn("-----------------------------------------------"), 
  new Error("Not implemented");
 }
 get boundingSphere() {
  return this._geometry ? this._geometry.boundingSphere : this._boundingSphere;
 }
}

let rotateOnAxis = function() {
 let i = new Quaternion();
 return function(e, t) {
  if (0 !== t) return i.setFromAxisAngle(e, t), this._quaternion.multiply(i), this._onChangeListener && (e = {
   uuid: this._uuid,
   changes: {
    quaternion: this._quaternion.toArray()
   }
  }, this._onChangeListener.objectUpdate(e)), this;
 };
}(), rotateX = function() {
 let t = new Vector3(1, 0, 0);
 return function(e) {
  return this.rotateOnAxis(t, e);
 };
}(), rotateY = function() {
 var t = new Vector3(0, 1, 0);
 return function(e) {
  return this.rotateOnAxis(t, e);
 };
}(), rotateZ = function() {
 var t = new Vector3(0, 0, 1);
 return function(e) {
  return this.rotateOnAxis(t, e);
 };
}(), rotate = function(e) {
 this.rotateX(e.x), this.rotateY(e.y), this.rotateZ(e.z);
}, lookAt = function() {
 let i = new Matrix4(), r = new Quaternion();
 return function(e, t) {
  i.lookAt(this._position, e, t), r.setFromRotationMatrix(i), r.equals(this._quaternion) || (this._quaternion.copy(r), 
  this._onChangeListener && (e = {
   uuid: this._uuid,
   changes: {
    quaternion: this._quaternion.toArray()
   }
  }, this._onChangeListener.objectUpdate(e)));
 };
}(), translateOnAxis = function() {
 let i = new Vector3();
 return function(e, t) {
  return 0 !== t && (i.copy(e).applyQuaternion(this._quaternion), this._position.add(i.multiplyScalar(t)), 
  this._onChangeListener) && (e = {
   uuid: this._uuid,
   changes: {
    position: this._position.toArray()
   }
  }, this._onChangeListener.objectUpdate(e)), this;
 };
}(), translateX = function() {
 let t = new Vector3(1, 0, 0);
 return function(e) {
  return this.translateOnAxis(t, e);
 };
}(), translateY = function() {
 let t = new Vector3(0, 1, 0);
 return function(e) {
  return this.translateOnAxis(t, e);
 };
}(), translateZ = function() {
 let t = new Vector3(0, 0, 1);
 return function(e) {
  return this.translateOnAxis(t, e);
 };
}(), translate = function(e) {
 this.translateX(e.x), this.translateY(e.y), this.translateZ(e.z);
};

class CustomShaderMaterial extends Material {
 constructor(e, t = {}, i = {}) {
  super(Material), this.type = "CustomShaderMaterial", this._uniforms = t, this._attributes = i, 
  this._flagsSB = [], this._valuesSB = {}, this.programName = "custom_" + e;
 }
 addSBFlag(e) {
  this._flagsSB.push(e);
 }
 rmSBFlag(e) {
  e = this._flagsSB.indexOf(e);
  -1 < e && this._flagsSB.splice(e, 1);
 }
 hasSBFlag(e) {
  return -1 < this._flagsSB.indexOf(e);
 }
 clearSBFlags() {
  this._flagsSB.clear();
 }
 addSBValue(e, t) {
  this._valuesSB[e] = t;
 }
 rmSBValue(e) {
  delete this._valuesSB[e];
 }
 clearSBValues() {
  this._valuesSB = {};
 }
 setUniform(e, t) {
  this._uniforms[e] = t;
 }
 removeUniform(e) {
  delete this._uniforms[e];
 }
 getUniform(e) {
  return this._uniforms[e];
 }
 setAttribute(e, t) {
  this._attributes[e] = t;
 }
 removeAttribute(e) {
  delete this._attributes[e];
 }
 getAttribute(e) {
  return this._attributes[e];
 }
 resetProgramFlagsAndValues() {
  super.resetProgramFlagsAndValues();
  for (let e = 0; e < this._flagsSB.length; e++) this.flags.push(this._flagsSB[e]);
  for (var e in this._valuesSB) this._valuesSB.hasOwnProperty(e) && (this.values[e] = this._valuesSB[e]);
 }
 requiredProgram(e = void 0, t = !1) {
  if (!t) return null === this.requiredProgramTemplate && (this.resetProgramFlagsAndValues(), 
  this.requiredProgramTemplate = new MaterialProgramTemplate(this.programName2, this.flags, this.values, e)), 
  this.requiredProgramTemplate;
  console.warn("THIS SEGMENT IS DEPRECATED"), this.resetProgramFlagsAndValues();
 }
}

class PickingShaderMaterial extends CustomShaderMaterial {
 static PICK_MODE = {
  RGB: 0,
  UINT: 1
 };
 static DEFAULT_PICK_MODE = PickingShaderMaterial.PICK_MODE.RGB;
 constructor(e = "TRIANGLES", t = {}, i = {}, r = {}) {
  super("picker_" + e, t, i, r), this.type = "PickingShaderMaterial", this._pickMode = null, 
  this.pickMode = r.mode || PickingShaderMaterial.DEFAULT_PICK_MODE;
 }
 get pickMode() {
  return this._pickMode;
 }
 set pickMode(e) {
  e !== this._pickMode && (this.requiredProgramTemplate = null, (this._pickMode = e) === PickingShaderMaterial.PICK_MODE.RGB ? (this.removeUniform("u_PickInstance"), 
  this.rmSBFlag("PICK_MODE_UINT"), this.addSBFlag("PICK_MODE_RGB")) : e === PickingShaderMaterial.PICK_MODE.UINT ? (this.rmSBFlag("PICK_MODE_RGB"), 
  this.addSBFlag("PICK_MODE_UINT"), this.setUniform("u_PickInstance", !1)) : console.error("Unknown pick mode: [" + e + "]."), 
  this._onChangeListener) && (e = {
   uuid: this._uuid,
   changes: {
    pickMode: this._pickMode
   }
  }, this._onChangeListener.materialUpdate(e));
 }
 resetProgramFlagsAndValues() {
  super.resetProgramFlagsAndValues();
 }
 requiredProgram(e = void 0) {
  return null === this.requiredProgramTemplate && (this.resetProgramFlagsAndValues(), 
  this.requiredProgramTemplate = new MaterialProgramTemplate(this.programName, this.flags, this.values, e)), 
  this.requiredProgramTemplate;
 }
}

class Mesh extends Object3D {
 static sDefaultPickable = !1;
 constructor(e, t, i, r, s = {}) {
  super(Object3D), this.type = "Mesh", this._geometry = void 0 !== e ? e : new Geometry(), 
  this._material = void 0 !== t ? t : new MeshBasicMaterial({
   color: 16777215 * Math.random()
  }), this._pickingMaterial = i, this._outlineMaterial = r, this.GBufferMaterial = s.GBufferMaterial, 
  this.raycast = _raycast, this._RGB_ID = new Color(0, 0, 0), this._UINT_ID = 0, 
  this._drawOutline = !1, this._instanced = !1, this._instancedTranslation = !1, 
  this._instanceCount = 1, this.pickable = Mesh.sDefaultPickable;
 }
 addOnChangeListener(e, t) {
  this._material.onChangeListener = e, this._geometry.onChangeListener = e, super.addOnChangeListener(e, t);
 }
 get material() {
  return this._material;
 }
 get pickingMaterial() {
  return this._pickingMaterial;
 }
 get outlineMaterial() {
  return this._outlineMaterial;
 }
 get geometry() {
  return this._geometry;
 }
 get RGB_ID() {
  return this._RGB_ID;
 }
 get UINT_ID() {
  return this._UINT_ID;
 }
 get drawOutline() {
  return this._drawOutline;
 }
 get pickable() {
  return super.pickable;
 }
 get instanced() {
  return this._instanced;
 }
 get instancedTranslation() {
  return this._instancedTranslation;
 }
 get instanceCount() {
  return this._instanceCount;
 }
 set material(e) {
  this._material = e, this._staticStateDirty = !0, this._material.instanced = this._instanced, 
  this._material.instancedTranslation = this._instancedTranslation;
 }
 set pickingMaterial(e) {
  this._pickingMaterial = e, this._staticStateDirty = !0, this._pickingMaterial.instanced = this._instanced, 
  this._pickingMaterial.instancedTranslation = this._instancedTranslation;
 }
 set outlineMaterial(e) {
  this._outlineMaterial = e, this._staticStateDirty = !0, this._outlineMaterial.instanced = this._instanced;
 }
 get GBufferMaterial() {
  return void 0 === this._GBufferMaterial && (this.GBufferMaterial = new CustomShaderMaterial("multi")), 
  this._GBufferMaterial;
 }
 set GBufferMaterial(e) {
  this._GBufferMaterial = e, this._staticStateDirty = !0;
 }
 set geometry(e) {
  this._geometry = e;
 }
 set onChangeListener(e) {
  super.onChangeListener = e, this._geometry.onChangeListener = e, this._material.onChangeListener = e;
 }
 set RGB_ID(e) {
  this._RGB_ID = e;
 }
 set UINT_ID(e) {
  this._UINT_ID = e;
 }
 set drawOutline(e) {
  this._drawOutline = e;
 }
 set pickable(e) {
  (super.pickable = e) && !this._pickingMaterial && (this.pickingMaterial = new PickingShaderMaterial("TRIANGLES"), 
  this.pickingMaterial.side = this.material.side);
 }
 set instanced(e) {
  this._instanced = e, this._material.instanced = e, this._pickingMaterial && (this._pickingMaterial.instanced = e), 
  this._outlineMaterial && (this._outlineMaterial.instanced = e);
 }
 set instancedTranslation(e) {
  this._instanced = e, this._material.instancedTranslation = e, this._pickingMaterial && (this._pickingMaterial.instancedTranslation = e), 
  this._outlineMaterial && (this._outlineMaterial.instancedTranslation = e);
 }
 set instanceCount(e) {
  this._instanceCount = e;
 }
 toJson() {
  var e = super.toJson();
  return e.geometryUuid = this._geometry._uuid, e.materialUuid = this._material._uuid, 
  e;
 }
 static fromJson(e, t, i, r) {
  return r = r || new Mesh(t, i), r = super.fromJson(e, r);
 }
 fillRenderArray(e) {
  (this.material.transparent ? e.transparentObjects : e.opaqueObjects).addlast(this);
 }
 project(e) {
  this.material.transparent && (this._zVector.setFromMatrixPosition(this.matrixWorld), 
  this._zVector.applyMatrix4(e));
 }
 getRequiredPrograms(e) {
  var t = [ this._material.requiredProgram(e) ];
  return this._pickingMaterial && this.pickable && t.push(this._pickingMaterial.requiredProgram(e)), 
  this._outlineMaterial && this.drawOutline && t.push(this._outlineMaterial.requiredProgram(e)), 
  3 == e._renderMode && t.push(this.GBufferMaterial.requiredProgram(e)), this._staticStateDirty = !1, 
  t;
 }
 update(e, t) {
  this.modelViewMatrix.multiplyMatrices(t.matrixWorldInverse, this._matrixWorld), 
  this.normalMatrix.getNormalMatrix(this._modelViewMatrix);
 }
 draw(e, t, i = 0) {
  var r;
  this.geometry.drawWireframe ? (r = t.getGLBuffer(this.geometry.wireframeIndices), 
  e.bindBuffer(e.ELEMENT_ARRAY_BUFFER, r), this._instanced || this._instancedTranslation ? (i = i || this._instanceCount, 
  e.drawElementsInstanced(e.LINES, this.geometry.wireframeIndices.count(), e.UNSIGNED_INT, 0, i)) : e.drawElements(e.LINES, this.geometry.wireframeIndices.count(), e.UNSIGNED_INT, 0)) : this.geometry.indices ? (r = t.getGLBuffer(this.geometry.indices), 
  e.bindBuffer(e.ELEMENT_ARRAY_BUFFER, r), this._instanced || this._instancedTranslation ? (i = i || this._instanceCount, 
  e.drawElementsInstanced(this.renderingPrimitive, this.geometry.indexCount, e.UNSIGNED_INT, 4 * this.geometry.indexStart, i)) : e.drawElements(this.renderingPrimitive, this.geometry.indexCount, e.UNSIGNED_INT, 4 * this.geometry.indexStart)) : this._instanced || this._instancedTranslation ? (i = i || this._instanceCount, 
  e.drawArraysInstanced(this.renderingPrimitive, 0, this.geometry.vertices.count(), i)) : e.drawArrays(this.renderingPrimitive, 0, this.geometry.vertices.count());
 }
}

let _raycast = function() {
 let h = new Vector3(), u = new Vector3(), l = new Vector3(), i = new Matrix4(), _ = new Ray(), r = new Sphere(), c = new Vector3(), d = new Vector3();
 function m(e, t, i, r, s, a, n) {
  h.fromArray(r.array, 3 * s), u.fromArray(r.array, 3 * a), l.fromArray(r.array, 3 * n);
  let o;
  s = e.material;
  if (null === (o = s.side === BACK_SIDE ? i.intersectTriangle(l, u, h, !0, c) : i.intersectTriangle(h, u, l, s.side !== FRONT_AND_BACK_SIDE, c))) return null;
  d.copy(c), d.applyMatrix4(e.matrixWorld);
  a = t.ray.origin.distanceTo(d);
  return a < t.near || a > t.far ? null : {
   distance: a,
   point: d.clone(),
   triangle: [ h.applyMatrix4(e.matrixWorld).clone(), u.applyMatrix4(e.matrixWorld).clone(), l.applyMatrix4(e.matrixWorld).clone() ],
   object: e
  };
 }
 return function(a, n) {
  var o = this.geometry, e = this.material, t = this.matrixWorld;
  if (void 0 !== e && void 0 !== o && (null === o.boundingSphere && o.computeBoundingSphere(), 
  r.copy(o.boundingSphere), r.applyMatrix4(t), !1 !== a.ray.intersectsSphere(r)) && (i.getInverse(t), 
  _.copy(a.ray).applyMatrix4(i), null === o.boundingBox || !1 !== _.intersectsBox(o.boundingBox))) {
   let t, i, r, s;
   var h = o.indices, u = o.vertices;
   if (null !== h) for (let e = 0; e < h.array.length; e += 3) i = h[e], r = h[e + 1], 
   s = h[e + 2], (t = m(this, a, _, u, i, r, s)) && (t.faceIndex = Math.floor(e / 3), 
   n.push(t)); else for (let e = 0; e < o.vertices.array.length; e += 9) i = e / 3, 
   r = i + 1, s = i + 2, (t = m(this, a, _, u, i, r, s)) && (t.index = i, n.push(t));
  }
 };
}();

class Line extends Mesh {
 constructor(e, t) {
  super(e, t = void 0 === t ? new MeshBasicMaterial() : t), this.type = "Line", 
  this.renderingPrimitive = LINE_STRIP;
 }
 setPoints(e) {
  void 0 === this._geometry && (this._geometry = new Geometry()), this._geometry.vertices.array = new Float32Array(e);
 }
 static fromJson(e, t, i) {
  t = new Line(t, i);
  return super.fromJson(e, void 0, void 0, t);
 }
}

function Interpolant(e, t, i, r) {
 this.parameterPositions = e, this._cachedIndex = 0, this.resultBuffer = void 0 !== r ? r : new t.constructor(i), 
 this.sampleValues = t, this.valueSize = i;
}

function QuaternionLinearInterpolant(e, t, i, r) {
 Interpolant.call(this, e, t, i, r);
}

function LinearInterpolant(e, t, i, r) {
 Interpolant.call(this, e, t, i, r);
}

function DiscreteInterpolant(e, t, i, r) {
 Interpolant.call(this, e, t, i, r);
}

function CubicInterpolant(e, t, i, r) {
 Interpolant.call(this, e, t, i, r), this._weightPrev = -0, this._offsetPrev = -0, 
 this._weightNext = -0, this._offsetNext = -0;
}

function SphericalHarmonics3() {
 this.coefficients = [];
 for (var e = 0; e < 9; e++) this.coefficients.push(new Vector3());
}

Object.assign(Interpolant.prototype, {
 evaluate: function(e) {
  var t, i = this.parameterPositions, r = this._cachedIndex, s = i[r], a = i[r - 1];
  e: {
   t: {
    i: {
     r: if (!(e < s)) {
      for (var n = r + 2; ;) {
       if (void 0 === s) {
        if (e < a) break r;
        return r = i.length, this._cachedIndex = r, this.afterEnd_(r - 1, e, a);
       }
       if (r === n) break;
       if (a = s, e < (s = i[++r])) break t;
      }
      t = i.length;
      break i;
     }
     if (a <= e) break e;
     var o = i[1];
     e < o && (r = 2, a = o);
     for (n = r - 2; ;) {
      if (void 0 === a) return this._cachedIndex = 0, this.beforeStart_(0, e, s);
      if (r === n) break;
      if (s = a, (a = i[--r - 1]) <= e) break t;
     }
     t = r, r = 0;
    }
    for (;r < t; ) {
     var h = r + t >>> 1;
     e < i[h] ? t = h : r = 1 + h;
    }
    if (s = i[r], void 0 === (a = i[r - 1])) return this._cachedIndex = 0, this.beforeStart_(0, e, s);
    if (void 0 === s) return r = i.length, this._cachedIndex = r, this.afterEnd_(r - 1, a, e);
   }
   this._cachedIndex = r, this.intervalChanged_(r, a, s);
  }
  return this.interpolate_(r, a, e, s);
 },
 settings: null,
 DefaultSettings_: {},
 getSettings_: function() {
  return this.settings || this.DefaultSettings_;
 },
 copySampleValue_: function(e) {
  for (var t = this.resultBuffer, i = this.sampleValues, r = this.valueSize, s = e * r, a = 0; a !== r; ++a) t[a] = i[s + a];
  return t;
 },
 interpolate_: function() {
  throw new Error("call to abstract method");
 },
 intervalChanged_: function() {}
}), Object.assign(Interpolant.prototype, {
 beforeStart_: Interpolant.prototype.copySampleValue_,
 afterEnd_: Interpolant.prototype.copySampleValue_
}), QuaternionLinearInterpolant.prototype = Object.assign(Object.create(Interpolant.prototype), {
 constructor: QuaternionLinearInterpolant,
 interpolate_: function(e, t, i, r) {
  for (var s = this.resultBuffer, a = this.sampleValues, n = this.valueSize, o = e * n, h = (i - t) / (r - t), u = o + n; o !== u; o += 4) Quaternion.slerpFlat(s, 0, a, o - n, a, o, h);
  return s;
 }
}), LinearInterpolant.prototype = Object.assign(Object.create(Interpolant.prototype), {
 constructor: LinearInterpolant,
 interpolate_: function(e, t, i, r) {
  for (var s = this.resultBuffer, a = this.sampleValues, n = this.valueSize, o = e * n, h = o - n, u = (i - t) / (r - t), l = 1 - u, _ = 0; _ !== n; ++_) s[_] = a[h + _] * l + a[o + _] * u;
  return s;
 }
}), DiscreteInterpolant.prototype = Object.assign(Object.create(Interpolant.prototype), {
 constructor: DiscreteInterpolant,
 interpolate_: function(e) {
  return this.copySampleValue_(e - 1);
 }
}), CubicInterpolant.prototype = Object.assign(Object.create(Interpolant.prototype), {
 constructor: CubicInterpolant,
 DefaultSettings_: {
  endingStart: ZeroCurvatureEnding,
  endingEnd: ZeroCurvatureEnding
 },
 intervalChanged_: function(e, t, i) {
  var r = this.parameterPositions, s = e - 2, a = e + 1, n = r[s], o = r[a];
  if (void 0 === n) switch (this.getSettings_().endingStart) {
  case ZeroSlopeEnding:
   s = e, n = 2 * t - i;
   break;

  case WrapAroundEnding:
   n = t + r[s = r.length - 2] - r[s + 1];
   break;

  default:
   s = e, n = i;
  }
  if (void 0 === o) switch (this.getSettings_().endingEnd) {
  case ZeroSlopeEnding:
   a = e, o = 2 * i - t;
   break;

  case WrapAroundEnding:
   o = i + r[a = 1] - r[0];
   break;

  default:
   a = e - 1, o = t;
  }
  var h = .5 * (i - t), u = this.valueSize;
  this._weightPrev = h / (t - n), this._weightNext = h / (o - i), this._offsetPrev = s * u, 
  this._offsetNext = a * u;
 },
 interpolate_: function(e, t, i, r) {
  for (var s = this.resultBuffer, a = this.sampleValues, n = this.valueSize, o = e * n, h = o - n, u = this._offsetPrev, l = this._offsetNext, e = this._weightPrev, _ = this._weightNext, i = (i - t) / (r - t), r = i * i, t = r * i, c = -e * t + 2 * e * r - e * i, d = (1 + e) * t + (-1.5 - 2 * e) * r + (-.5 + e) * i + 1, m = (-1 - _) * t + (1.5 + _) * r + .5 * i, g = _ * t - _ * r, p = 0; p !== n; ++p) s[p] = c * a[u + p] + d * a[h + p] + m * a[o + p] + g * a[l + p];
  return s;
 }
}), Object.assign(SphericalHarmonics3.prototype, {
 isSphericalHarmonics3: !0,
 set: function(e) {
  for (var t = 0; t < 9; t++) this.coefficients[t].copy(e[t]);
  return this;
 },
 zero: function() {
  for (var e = 0; e < 9; e++) this.coefficients[e].set(0, 0, 0);
  return this;
 },
 getAt: function(e, t) {
  var i = e.x, r = e.y, e = e.z, s = this.coefficients;
  return t.copy(s[0]).multiplyScalar(.282095), t.addScale(s[1], .488603 * r), t.addScale(s[2], .488603 * e), 
  t.addScale(s[3], .488603 * i), t.addScale(s[4], i * r * 1.092548), t.addScale(s[5], r * e * 1.092548), 
  t.addScale(s[6], .315392 * (3 * e * e - 1)), t.addScale(s[7], i * e * 1.092548), 
  t.addScale(s[8], .546274 * (i * i - r * r)), t;
 },
 getIrradianceAt: function(e, t) {
  var i = e.x, r = e.y, e = e.z, s = this.coefficients;
  return t.copy(s[0]).multiplyScalar(.886227), t.addScale(s[1], 1.023328 * r), t.addScale(s[2], 1.023328 * e), 
  t.addScale(s[3], 1.023328 * i), t.addScale(s[4], .858086 * i * r), t.addScale(s[5], .858086 * r * e), 
  t.addScale(s[6], .743125 * e * e - .247708), t.addScale(s[7], .858086 * i * e), 
  t.addScale(s[8], .429043 * (i * i - r * r)), t;
 },
 add: function(e) {
  for (var t = 0; t < 9; t++) this.coefficients[t].add(e.coefficients[t]);
  return this;
 },
 scale: function(e) {
  for (var t = 0; t < 9; t++) this.coefficients[t].multiplyScalar(e);
  return this;
 },
 lerp: function(e, t) {
  for (var i = 0; i < 9; i++) this.coefficients[i].lerp(e.coefficients[i], t);
  return this;
 },
 equals: function(e) {
  for (var t = 0; t < 9; t++) if (!this.coefficients[t].equals(e.coefficients[t])) return !1;
  return !0;
 },
 copy: function(e) {
  return this.set(e.coefficients);
 },
 clone: function() {
  return new this.constructor().copy(this);
 },
 fromArray: function(e, t) {
  void 0 === t && (t = 0);
  for (var i = this.coefficients, r = 0; r < 9; r++) i[r].fromArray(e, t + 3 * r);
  return this;
 },
 toArray: function(e, t) {
  void 0 === e && (e = []), void 0 === t && (t = 0);
  for (var i = this.coefficients, r = 0; r < 9; r++) i[r].toArray(e, t + 3 * r);
  return e;
 }
}), Object.assign(SphericalHarmonics3, {
 getBasisAt: function(e, t) {
  var i = e.x, r = e.y, e = e.z;
  t[0] = .282095, t[1] = .488603 * r, t[2] = .488603 * e, t[3] = .488603 * i, t[4] = 1.092548 * i * r, 
  t[5] = 1.092548 * r * e, t[6] = .315392 * (3 * e * e - 1), t[7] = 1.092548 * i * e, 
  t[8] = .546274 * (i * i - r * r);
 }
});

class XHRStreamer {
 constructor(e = new LoadingManager(), t = "", i) {
  this._manager = e, this._responseType = t, this._chunkSize = i, this._size = 0, 
  this._position = 0, this._chunkSizeDownlaoded = 0;
 }
 load(t, i, r, s, a, n, o) {
  const h = this;
  this.get_fileSize(t, function(e) {
   h._size = e, n({
    size: h._size,
    type: "bytes"
   }), h.get_fileData(h, t, i, r, s, a, o);
  });
 }
 get_fileSize(e, t) {
  const i = new XMLHttpRequest();
  i.onreadystatechange = function(e) {
   this.readyState === this.DONE && t(parseInt(i.getResponseHeader("Content-Length")));
  }, i.open("HEAD", e, !0), i.send();
 }
 get_fileData(i, r, s, t, a, n, o) {
  const h = new XMLHttpRequest();
  h.responseType = this._responseType, h.onreadystatechange = function(e) {
   this.readyState !== this.LOADING && (this.readyState, this.DONE);
  }, h.onprogress = function(e) {
   t(e);
  }, h.onload = function(e) {
   var t;
   206 === this.status ? (i._position += i._chunkSize, t = h.response, i._position < i._size ? (o(t), 
   h.open("GET", r, !0), h.setRequestHeader("Range", "bytes=" + i._position + "-" + (i._position + i._chunkSize - 1)), 
   h.send()) : (i._manager.itemEnd(r), o(t), s(e))) : i._manager.itemError(r);
  }, h.onerror = function(e) {
   a(e), i._manager.itemError(r);
  }, h.onabort = function(e) {
   n(e);
  }, h.open("GET", r, !0), h.setRequestHeader("Range", "bytes=" + this._position + "-" + (this._position + this._chunkSize - 1)), 
  h.send(), this._manager.itemStart(r);
 }
}

class LASLoader {
 constructor(e = new LoadingManager(), t = "", i = !0, r = 1048576) {
  this._manager = e, this._responseType = t, this._stream = i, this._chunkSize = r, 
  this.PHBLoaded = !1, this.VLRsLoaded = !1, this.PDRLoaded = !1, this.PointsLoaded = 0, 
  this.PHB = null, this.DataBuffer = null, this.DataView = null, this.LASSize = 0, 
  this.LASLoaded = 0, this.LASChunk = 0, this.output = {};
 }
 load(e, t, i, r, s, a, n, o) {
  this._loadStream(e, t, i, r, s, a, n, o);
 }
 _loadStream(e, i, t, r, s, a, n, o) {
  const h = this;
  new XHRStreamer(this._manager, this._responseType, this._chunkSize).load(e, function(e) {
   t(e), h.output = {};
  }, function(e) {
   h.LASChunk = e.total, r(e);
  }, s, a, function(e) {
   h.LASSize = e.size, h.DataBuffer = new ArrayBuffer(e.size), h.DataView = new DataView(h.DataBuffer), 
   h.PHB = new LASLoader.PHB(), n(e);
  }, function(e) {
   var t = null;
   h._copyArray(h.DataBuffer, e, 0, h.LASLoaded, h.LASChunk), h.LASLoaded += h.LASChunk, 
   !1 === h.PHBLoaded && (h.PHBLoaded = h._parseHeader(h.DataView, h.LASLoaded, h.PHB), 
   h.PHBLoaded) && (console.log("PHB is loaded"), h._printHeader(h.PHB), 0 === h.PHB.inserts.NUMBER_OF_VARIABLE_LENGTH_RECORDS.data) && (h.VLRsLoaded = !0), 
   !0 === h.PHBLoaded && h.VLRsLoaded, null != (t = !0 === h.PHBLoaded && !1 === h.PDRLoaded ? h._parsePointData(h.DataView, h.LASLoaded, i) : t) && o(t);
  });
 }
 _parsePointData(r, e, s) {
  let t = this.PHB.inserts.LEGACY_NUMBER_OF_POINT_RECORDS.data;
  -1 === t && (t = this.PHB.inserts.NUMBER_OF_POINT_RECORDS.data);
  var a = this.PHB.inserts.POINT_DATA_RECORD_LENGTH.data, n = this._generateFormat(this.PHB.inserts.POINT_DATA_RECORD_FORMAT.data), o = this.PHB.inserts.OFFSET_TO_POINT_DATA.data, h = this.PHB.inserts.X_OFFSET.data, u = this.PHB.inserts.Y_OFFSET.data, l = this.PHB.inserts.Z_OFFSET.data, _ = this.PHB.inserts.X_SCALE_FACTOR.data, c = this.PHB.inserts.Y_SCALE_FACTOR.data, d = this.PHB.inserts.Z_SCALE_FACTOR.data, m = null;
  for (let i = this.PointsLoaded; i < t; i++) {
   var g = o + a * i;
   if (e <= g + a) break;
   for (let t = 0; t < s.length; t++) {
    let e = this._readFromDataView(r, n.inserts[s[t]], g);
    switch (s[t]) {
    case LASLoader.PDRFormat0.Keys.X:
     e = e * _ + h;
     break;

    case LASLoader.PDRFormat0.Keys.Y:
     e = e * c + u;
     break;

    case LASLoader.PDRFormat0.Keys.Z:
     e = e * d + l;
    }
    void 0 === (m = null == m ? {} : m)[s[t]] && (m[s[t]] = new Array()), m[s[t]][i] = e;
   }
   this.PointsLoaded++;
  }
  return m;
 }
 _generateFormat(e) {
  let t = null;
  switch (e) {
  case 0:
   t = new LASLoader.PDRFormat0();
   break;

  case 1:
   t = new LASLoader.PDRFormat1();
   break;

  case 2:
   t = new LASLoader.PDRFormat2();
   break;

  case 3:
   t = new LASLoader.PDRFormat3();
   break;

  case 4:
   t = new LASLoader.PDRFormat4();
   break;

  case 5:
   t = new LASLoader.PDRFormat5();
   break;

  case 6:
   t = new LASLoader.PDRFormat6();
   break;

  case 7:
   t = new LASLoader.PDRFormat7();
   break;

  case 8:
   t = new LASLoader.PDRFormat8();
   break;

  case 9:
   t = new LASLoader.PDRFormat9();
   break;

  case 10:
   t = new LASLoader.PDRFormat10();
   break;

  default:
   console.error("Unknown LAS format: " + e);
  }
  return t;
 }
 _copyArray(e, t, i, r, s) {
  e = new Uint8Array(e), t = new Uint8Array(t, i, s);
  e.set(t, r);
 }
 _readFromArrayBuffer(e, t, i) {
  var r = new ArrayBuffer(i), s = new Uint8Array(e), a = new Uint8Array(r);
  for (let e = 0; e < i; e++) a[e] = s[t + e];
  return r;
 }
 _parseHeader(e, t, i) {
  for (var r in console.log("Trying to parse header with " + t + " bytes loaded"), 
  i.inserts) if (i.inserts.hasOwnProperty(r) && !i.inserts[r].hasData) {
   if (i.inserts[r].endOffset > t && 1 == i.inserts[r].required) return console.log("property " + r + " requires " + i.inserts[r].endOffset + " bytes"), 
   !1;
   i.inserts[r].data = this._readFromDataView(e, i.inserts[r]), console.log("Read " + r + ": " + i.inserts[r].data);
  }
  return !0;
 }
 _printHeader(e) {
  for (var t in e.inserts) e.inserts.hasOwnProperty(t) && console.log(t + ": " + e.inserts[t].data);
 }
 _readFromDataView(e, t, i = 0) {
  var r = i + t.offset;
  switch (t.format.type) {
  case "char":
   return this._typedArray2String(new Int8Array(e.buffer, r, t.size));

  case "unsigned char":
   return this._typedArray2String(new Uint8Array(e.buffer, r, t.size));

  case "unsigned int8":
   return e.getUint8(r);

  case "short":
   return e.getInt16(r, !0);

  case "unsigned short":
   return e.getUint16(r, !0);

  case "long":
   return e.getInt32(r, !0);

  case "unsigned long":
   return e.getUint32(r, !0);

  case "long long":
   return e.getBigInt64(r, !0);

  case "unsigned long long":
   return e.getBigUint64(r, !0);

  case "float":
   return e.getFloat32(r, !0);

  case "double":
   return e.getFloat64(r, !0);

  default:
   console.error("Unknown LAZ insert format type.");
  }
 }
 _typedArray2String(e) {
  return String.fromCharCode.apply(null, e);
 }
}

LASLoader.DataTypes = {
 char: {
  type: "char",
  byteSize: 1
 },
 unsignedChar: {
  type: "unsigned char",
  byteSize: 1
 },
 uint8: {
  type: "unsigned int8",
  byteSize: 1
 },
 short: {
  type: "short",
  byteSize: 2
 },
 unsignedShort: {
  type: "unsigned short",
  byteSize: 2
 },
 long: {
  type: "long",
  byteSize: 4
 },
 unsignedLong: {
  type: "unsigned long",
  byteSize: 4
 },
 longLong: {
  type: "long long",
  byteSize: 8
 },
 unsignedLongLong: {
  type: "unsigned long long",
  byteSize: 8
 },
 float: {
  type: "float",
  byteSize: 4
 },
 double: {
  type: "double",
  byteSize: 8
 },
 string: void 0
}, LASLoader.PHB = class {
 constructor() {
  this._headerLength = 375, this._dataTypes = LASLoader.DataTypes, this._inserts = {
   FILE_SIGNATURE: new LASLoader.PHBInsert("File Signature (“LASF”)", this._dataTypes.char, 4, !0, 0),
   FILE_SOURCE_ID: new LASLoader.PHBInsert("File Source ID", this._dataTypes.unsignedShort, 1, !0, 4),
   GLOBAL_ENCODING: new LASLoader.PHBInsert("Global Encoding", this._dataTypes.unsignedShort, 1, !0, 6),
   GUID_DATA_1: new LASLoader.PHBInsert("Project ID - GUID Data 1", this._dataTypes.unsignedLong, 1, !1, 8),
   GUID_DATA_2: new LASLoader.PHBInsert("Project ID - GUID Data 2", this._dataTypes.unsignedShort, 1, !1, 12),
   GUID_DATA_3: new LASLoader.PHBInsert("Project ID - GUID Data 3", this._dataTypes.unsignedShort, 1, !1, 14),
   GUID_DATA_4: new LASLoader.PHBInsert("Project ID - GUID Data 4", this._dataTypes.unsignedChar, 8, !1, 16),
   VERSION_MAJOR: new LASLoader.PHBInsert("Version Major", this._dataTypes.uint8, 1, !0, 24),
   VERSION_MINOR: new LASLoader.PHBInsert("Version Minor", this._dataTypes.uint8, 1, !0, 25),
   SYSTEM_IDENTIFIER: new LASLoader.PHBInsert("System Identifier", this._dataTypes.char, 32, !0, 26),
   GENERATING_SOFTWARE: new LASLoader.PHBInsert("Generating Software ", this._dataTypes.char, 32, !0, 58),
   FILE_CREATION_DAY: new LASLoader.PHBInsert("File Creation Day of Year", this._dataTypes.unsignedShort, 1, !0, 90),
   FILE_CREATION_YEAR: new LASLoader.PHBInsert("File Creation Year", this._dataTypes.unsignedShort, 1, !0, 92),
   HEADER_SIZE: new LASLoader.PHBInsert("Header Size", this._dataTypes.unsignedShort, 1, !0, 94),
   OFFSET_TO_POINT_DATA: new LASLoader.PHBInsert("Offset to Point Data", this._dataTypes.unsignedLong, 1, !0, 96),
   NUMBER_OF_VARIABLE_LENGTH_RECORDS: new LASLoader.PHBInsert("Number of Variable Length Records", this._dataTypes.unsignedLong, 1, !0, 100),
   POINT_DATA_RECORD_FORMAT: new LASLoader.PHBInsert("Point Data Record Format", this._dataTypes.uint8, 1, !0, 104),
   POINT_DATA_RECORD_LENGTH: new LASLoader.PHBInsert("Point Data Record Length", this._dataTypes.unsignedShort, 1, !0, 105),
   LEGACY_NUMBER_OF_POINT_RECORDS: new LASLoader.PHBInsert("Legacy Number of Point Records", this._dataTypes.unsignedLong, 1, !0, 107),
   LEGACY_NUMBER_OF_POINT_BY_RETURN: new LASLoader.PHBInsert("Legacy Number of Point by Return", this._dataTypes.unsignedLong, 20, !0, 111),
   X_SCALE_FACTOR: new LASLoader.PHBInsert("X Scale Factor", this._dataTypes.double, 1, !0, 131),
   Y_SCALE_FACTOR: new LASLoader.PHBInsert("Y Scale Factor", this._dataTypes.double, 1, !0, 139),
   Z_SCALE_FACTOR: new LASLoader.PHBInsert("Z Scale Factor", this._dataTypes.double, 1, !0, 147),
   X_OFFSET: new LASLoader.PHBInsert("X Offset", this._dataTypes.double, 1, !0, 155),
   Y_OFFSET: new LASLoader.PHBInsert("Y Offset", this._dataTypes.double, 1, !0, 163),
   Z_OFFSET: new LASLoader.PHBInsert("Z Offset", this._dataTypes.double, 1, !0, 171),
   MAX_X: new LASLoader.PHBInsert("Max X", this._dataTypes.double, 1, !0, 179),
   MAX_Y: new LASLoader.PHBInsert("Max Y", this._dataTypes.double, 1, !0, 187),
   MAX_Z: new LASLoader.PHBInsert("Max Z", this._dataTypes.double, 1, !0, 195),
   MIN_X: new LASLoader.PHBInsert("Min X", this._dataTypes.double, 1, !0, 203),
   MIN_Y: new LASLoader.PHBInsert("Min Y", this._dataTypes.double, 1, !0, 211),
   MIN_Z: new LASLoader.PHBInsert("Min Z", this._dataTypes.double, 1, !0, 219),
   START_OF_WAVEFORM_DATA_PACKET_RECORD: new LASLoader.PHBInsert("Start of Waveform Data Packet Record", this._dataTypes.unsignedLongLong, 1, !0, 227),
   START_OF_FIRST_EXTENDED_VARIABLE_LENGTH_RECORD: new LASLoader.PHBInsert("Start of First Extended Variable Length Record", this._dataTypes.unsignedLongLong, 1, !0, 235),
   NUMBER_OF_EXTENDED_VARIABLE_LENGTH_RECORDS: new LASLoader.PHBInsert("Number of Extended Variable Length Records", this._dataTypes.unsignedLong, 1, !0, 243),
   NUMBER_OF_POINT_RECORDS: new LASLoader.PHBInsert("Number of Point Records", this._dataTypes.unsignedLongLong, 1, !0, 247),
   NUMBER_OF_POINTS_BY_RETURN: new LASLoader.PHBInsert("Number of Points by Return", this._dataTypes.unsignedLongLong, 15, !0, 255)
  };
 }
 get headerLength() {
  return this._headerLength;
 }
 get inserts() {
  return this._inserts;
 }
}, LASLoader.Insert = class {
 constructor(e, t, i, r, s) {
  this._item = e, this._format = t, this._size = i, this._required = r, this._offset = s, 
  this._data = null;
 }
 set item(e) {
  this._item = e;
 }
 set format(e) {
  this._format = e;
 }
 set size(e) {
  this._size = e;
 }
 set required(e) {
  this._required = e;
 }
 set offset(e) {
  this._offset = e;
 }
 set data(e) {
  this._data = e;
 }
 get item() {
  return this._item;
 }
 get format() {
  return this._format;
 }
 get size() {
  return this._size;
 }
 get required() {
  return this._required;
 }
 get offset() {
  return this._offset;
 }
 get data() {
  return this._data;
 }
 get hasData() {
  return null != this._data;
 }
 get endOffset() {
  return this._offset + this._format.byteSize * this._size;
 }
}, LASLoader.PHBInsert = class extends LASLoader.Insert {
 constructor(e, t, i, r, s) {
  super(e, t, i, r, s);
 }
}, LASLoader.VLR = class {
 constructor() {
  this._headerLength = 54, this._dataTypes = LASLoader.DataTypes, this._inserts = {
   RESERVED: new LASLoader.VLRInsert("Reserved", this._dataTypes.unsignedShort, 2, void 0, 0),
   USER_ID: new LASLoader.VLRInsert("User ID", this._dataTypes.char, 16, !0, 2),
   RECORD_ID: new LASLoader.VLRInsert("Record ID", this._dataTypes.unsignedShort, 2, !0, 18),
   RECORD_LENGTH_AFTER_HEADER: new LASLoader.VLRInsert("Record Length After Header", this._dataTypes.unsignedShort, 2, !0, 20),
   DESCRIPTION: new LASLoader.VLRInsert("Description", this._dataTypes.char, 32, void 0, 22)
  };
 }
 get headerLength() {
  return this._headerLength;
 }
 get inserts() {
  return this._inserts;
 }
}, LASLoader.VLRInsert = class extends LASLoader.Insert {
 constructor(e, t, i, r, s) {
  super(e, t, i, r, s);
 }
}, LASLoader.PDRInsert = class extends LASLoader.Insert {
 constructor(e, t, i, r, s) {
  super(e, t, i, r, s);
 }
}, LASLoader.PDRFormat0 = class {
 constructor() {
  this._minSize = 20, this._dataTypes = LASLoader.DataTypes, this._inserts = {
   X: new LASLoader.PDRInsert("X", this._dataTypes.long, 4, !0, 0),
   Y: new LASLoader.PDRInsert("Y", this._dataTypes.long, 4, !0, 4),
   Z: new LASLoader.PDRInsert("Z", this._dataTypes.long, 4, !0, 8),
   INTENSITY: new LASLoader.PDRInsert("Intensity", this._dataTypes.unsignedShort, 2, !1, 12),
   RETURN_NUMBER: new LASLoader.PDRInsert("Return Number", this._dataTypes.unsignedChar, 1, !0, 14),
   NUMBER_OR_RETURNS: new LASLoader.PDRInsert("Number of Returns (Given Pulse)", this._dataTypes.unsignedChar, 1, !0, 14),
   SCAN_DIRECTION_FLAG: new LASLoader.PDRInsert("Scan Direction Flag", this._dataTypes.unsignedChar, 1, !0, 14),
   EDGE_OF_FLIGHT_LINE: new LASLoader.PDRInsert("Edge of Flight Line", this._dataTypes.unsignedChar, 1, !0, 14),
   CLASSIFICATION: new LASLoader.PDRInsert("Classification", this._dataTypes.unsignedChar, 1, !0, 15),
   SCAN_ANGELE_RANK: new LASLoader.PDRInsert("Scan Angle Rank (-90 to +90) – Left Side", this._dataTypes.char, 1, !0, 16),
   USER_DATA: new LASLoader.PDRInsert("User Data", this._dataTypes.unsignedChar, 1, !1, 17),
   POINT_SOURCE_ID: new LASLoader.PDRInsert("Point Source ID", this._dataTypes.unsignedShort, 2, !0, 18)
  };
 }
 set minSize(e) {
  this._minSize = e;
 }
 get minSize() {
  return this._minSize;
 }
 get inserts() {
  return this._inserts;
 }
}, LASLoader.PDRFormat0.Keys = {
 X: "X",
 Y: "Y",
 Z: "Z",
 INTENSITY: "INTENSITY",
 RETURN_NUMBER: "RETURN_NUMBER",
 NUMBER_OR_RETURNS: "NUMBER_OR_RETURNS",
 SCAN_DIRECTION_FLAG: "SCAN_DIRECTION_FLAG",
 EDGE_OF_FLIGHT_LINE: "EDGE_OF_FLIGHT_LINE",
 CLASSIFICATION: "CLASSIFICATION",
 SCAN_ANGELE_RANK: "SCAN_ANGELE_RANK",
 USER_DATA: "USER_DATA",
 POINT_SOURCE_ID: "POINT_SOURCE_ID"
}, LASLoader.PDRFormat1 = class extends LASLoader.PDRFormat0 {
 constructor() {
  super(), this.minSize = 28, Object.assign(this._inserts, {
   GPS_TIME: new LASLoader.PDRInsert("GPS Time", this._dataTypes.double, 8, !0, 20)
  });
 }
}, LASLoader.PDRFormat1.Keys = Object.assign({}, LASLoader.PDRFormat0.Keys, {
 GPS_TIME: "GPS_TIME"
}), LASLoader.PDRFormat2 = class extends LASLoader.PDRFormat0 {
 constructor() {
  super(), this.minSize = 26, Object.assign(this._inserts, {
   RED: new LASLoader.PDRInsert("Red", this._dataTypes.uint8, 1, !0, 21),
   GREEN: new LASLoader.PDRInsert("Green", this._dataTypes.uint8, 1, !0, 23),
   BLUE: new LASLoader.PDRInsert("Blue", this._dataTypes.uint8, 1, !0, 25),
   NX: new LASLoader.PDRInsert("NX", this._dataTypes.uint8, 1, !0, 20),
   NY: new LASLoader.PDRInsert("NY", this._dataTypes.uint8, 1, !0, 22),
   NZ: new LASLoader.PDRInsert("NZ", this._dataTypes.uint8, 1, !0, 24)
  });
 }
}, LASLoader.PDRFormat2.Keys = Object.assign({}, LASLoader.PDRFormat0.Keys, {
 RED: "RED",
 GREEN: "GREEN",
 BLUE: "BLUE",
 NX: "NX",
 NY: "NY",
 NZ: "NZ"
}), LASLoader.PDRFormat3 = class extends LASLoader.PDRFormat1 {
 constructor() {
  super(), this.minSize = 34, Object.assign(this._inserts, {
   RED: new LASLoader.PDRInsert("Red", this._dataTypes.unsignedShort, 2, !0, 28),
   GREEN: new LASLoader.PDRInsert("Green", this._dataTypes.unsignedShort, 2, !0, 30),
   BLUE: new LASLoader.PDRInsert("Blue", this._dataTypes.unsignedShort, 2, !0, 32)
  });
 }
}, LASLoader.PDRFormat3.Keys = Object.assign({}, LASLoader.PDRFormat1.Keys, {
 RED: "RED",
 GREEN: "GREEN",
 BLUE: "BLUE"
}), LASLoader.PDRFormat4 = class extends LASLoader.PDRFormat1 {
 constructor() {
  super(), this.minSize = 57, Object.assign(this._inserts, {
   WAVE_PACKET_DESCRIPTOR_INDEX: new LASLoader.PDRInsert("Wave Packet Descriptor Index", this._dataTypes.unsignedChar, 1, !0, 28),
   BYTE_OFFSET_TO_WAVEFORM_DATA: new LASLoader.PDRInsert("Byte Offset to Waveform Data", this._dataTypes.unsignedLongLong, 8, !0, 29),
   WAVEFORM_PACKET_SIZE_IN_BYTES: new LASLoader.PDRInsert("Waveform Packet Size in Bytes", this._dataTypes.unsignedLong, 4, !0, 37),
   RETURN_POINT_WAVEFORM_LOCATION: new LASLoader.PDRInsert("Return Point Waveform Location", this._dataTypes.float, 4, !0, 41),
   PARAMETRIC_DX: new LASLoader.PDRInsert("Parametric dx", this._dataTypes.float, 4, !0, 45),
   PARAMETRIC_DY: new LASLoader.PDRInsert("Parametric dy", this._dataTypes.float, 4, !0, 49),
   PARAMETRIC_DZ: new LASLoader.PDRInsert("Parametric dz", this._dataTypes.float, 4, !0, 53)
  });
 }
}, LASLoader.PDRFormat4.Keys = Object.assign({}, LASLoader.PDRFormat1.Keys, {
 WAVE_PACKET_DESCRIPTOR_INDEX: "WAVE_PACKET_DESCRIPTOR_INDEX",
 BYTE_OFFSET_TO_WAVEFORM_DATA: "BYTE_OFFSET_TO_WAVEFORM_DATA",
 WAVEFORM_PACKET_SIZE_IN_BYTES: "WAVEFORM_PACKET_SIZE_IN_BYTES",
 RETURN_POINT_WAVEFORM_LOCATION: "RETURN_POINT_WAVEFORM_LOCATION",
 PARAMETRIC_DX: "PARAMETRIC_DX",
 PARAMETRIC_DY: "PARAMETRIC_DY",
 PARAMETRIC_DZ: "PARAMETRIC_DZ"
}), LASLoader.PDRFormat5 = class extends LASLoader.PDRFormat3 {
 constructor() {
  super(), this.minSize = 63, Object.assign(this._inserts, {
   WAVE_PACKET_DESCRIPTOR_INDEX: new LASLoader.PDRInsert("Wave Packet Descriptor Index", this._dataTypes.unsignedChar, 1, !0, 34),
   BYTE_OFFSET_TO_WAVEFORM_DATA: new LASLoader.PDRInsert("Byte Offset to Waveform Data", this._dataTypes.unsignedLongLong, 8, !0, 35),
   WAVEFORM_PACKET_SIZE_IN_BYTES: new LASLoader.PDRInsert("Waveform Packet Size in Bytes", this._dataTypes.unsignedLong, 4, !0, 43),
   RETURN_POINT_WAVEFORM_LOCATION: new LASLoader.PDRInsert("Return Point Waveform Location", this._dataTypes.float, 4, !0, 47),
   PARAMETRIC_DX: new LASLoader.PDRInsert("Parametric dx", this._dataTypes.float, 4, !0, 51),
   PARAMETRIC_DY: new LASLoader.PDRInsert("Parametric dy", this._dataTypes.float, 4, !0, 55),
   PARAMETRIC_DZ: new LASLoader.PDRInsert("Parametric dz", this._dataTypes.float, 4, !0, 59)
  });
 }
}, LASLoader.PDRFormat5.Keys = Object.assign({}, LASLoader.PDRFormat3.Keys, {
 WAVE_PACKET_DESCRIPTOR_INDEX: "WAVE_PACKET_DESCRIPTOR_INDEX",
 BYTE_OFFSET_TO_WAVEFORM_DATA: "BYTE_OFFSET_TO_WAVEFORM_DATA",
 WAVEFORM_PACKET_SIZE_IN_BYTES: "WAVEFORM_PACKET_SIZE_IN_BYTES",
 RETURN_POINT_WAVEFORM_LOCATION: "RETURN_POINT_WAVEFORM_LOCATION",
 PARAMETRIC_DX: "PARAMETRIC_DX",
 PARAMETRIC_DY: "PARAMETRIC_DY",
 PARAMETRIC_DZ: "PARAMETRIC_DZ"
}), LASLoader.PDRFormat6 = class extends LASLoader.PDRFormat0 {
 constructor() {
  super(), this.minSize = 30, this._inserts = {
   X: new LASLoader.PDRInsert("X", this._dataTypes.long, 4, !0, 0),
   Y: new LASLoader.PDRInsert("Y", this._dataTypes.long, 4, !0, 4),
   Z: new LASLoader.PDRInsert("Z", this._dataTypes.long, 4, !0, 8),
   INTENSITY: new LASLoader.PDRInsert("Intensity", this._dataTypes.unsignedShort, 2, !1, 12),
   RETURN_NUMBER: new LASLoader.PDRInsert("Return Number", this._dataTypes.unsignedChar, 1, !0, 14),
   NUMBER_OR_RETURNS: new LASLoader.PDRInsert("Number of Returns (Given Pulse)", this._dataTypes.unsignedChar, 1, !0, 14),
   CLASSIFICATION_FLAGS: new LASLoader.PDRInsert("Classification Flags", this._dataTypes.unsignedChar, 1, !1, 15),
   SCANNER_CHANNEL: new LASLoader.PDRInsert("Scanner Channel", this._dataTypes.unsignedChar, 1, !0, 15),
   SCAN_DIRECTION_FLAG: new LASLoader.PDRInsert("Scan Direction Flag", this._dataTypes.unsignedChar, 1, !0, 15),
   EDGE_OF_FLIGHT_LINE: new LASLoader.PDRInsert("Edge of Flight Line", this._dataTypes.unsignedChar, 1, !0, 15),
   CLASSIFICATION: new LASLoader.PDRInsert("Classification", this._dataTypes.unsignedChar, 1, !0, 16),
   USER_DATA: new LASLoader.PDRInsert("User Data", this._dataTypes.unsignedChar, 1, !1, 17),
   SCAN_ANGELE: new LASLoader.PDRInsert("Scan Angle", this._dataTypes.short, 2, !0, 18),
   POINT_SOURCE_ID: new LASLoader.PDRInsert("Point Source ID", this._dataTypes.unsignedShort, 2, !0, 20),
   GPS_TIME: new LASLoader.PDRInsert("GPS Time", this._dataTypes.double, 8, !0, 22)
  };
 }
}, LASLoader.PDRFormat6.Keys = Object.assign({}, LASLoader.PDRFormat0.Keys, {
 X: "X",
 Y: "Y",
 Z: "Z",
 INTENSITY: "INTENSITY",
 RETURN_NUMBER: "RETURN_NUMBER",
 NUMBER_OR_RETURNS: "NUMBER_OR_RETURNS",
 CLASSIFICATION_FLAGS: "CLASSIFICATION_FLAGS",
 SCANNER_CHANNEL: "SCANNER_CHANNEL",
 SCAN_DIRECTION_FLAG: "SCAN_DIRECTION_FLAG",
 EDGE_OF_FLIGHT_LINE: "EDGE_OF_FLIGHT_LINE",
 CLASSIFICATION: "CLASSIFICATION",
 SCAN_ANGELE_RANK: void 0,
 USER_DATA: "USER_DATA",
 SCAN_ANGELE: "SCAN_ANGELE",
 POINT_SOURCE_ID: "POINT_SOURCE_ID",
 GPS_TIME: "GPS_TIME"
}), LASLoader.PDRFormat7 = class extends LASLoader.PDRFormat6 {
 constructor() {
  super(), this.minSize = 36, Object.assign(this._inserts, {
   RED: new LASLoader.PDRInsert("Red", this._dataTypes.unsignedShort, 2, !0, 30),
   GREEN: new LASLoader.PDRInsert("Green", this._dataTypes.unsignedShort, 2, !0, 32),
   BLUE: new LASLoader.PDRInsert("Blue", this._dataTypes.unsignedShort, 2, !0, 34)
  });
 }
}, LASLoader.PDRFormat7.Keys = Object.assign({}, LASLoader.PDRFormat6.Keys, {
 RED: "RED",
 GREEN: "GREEN",
 BLUE: "BLUE"
}), LASLoader.PDRFormat8 = class extends LASLoader.PDRFormat7 {
 constructor() {
  super(), this.minSize = 38, Object.assign(this._inserts, {
   NIR: new LASLoader.PDRInsert("NIR", this._dataTypes.unsignedShort, 2, !0, 36)
  });
 }
}, LASLoader.PDRFormat8.Keys = Object.assign({}, LASLoader.PDRFormat7.Keys, {
 NIR: "NIR"
}), LASLoader.PDRFormat9 = class extends LASLoader.PDRFormat6 {
 constructor() {
  super(), this.minSize = 59, Object.assign(this._inserts, {
   WAVE_PACKET_DESCRIPTOR_INDEX: new LASLoader.PDRInsert("Wave Packet Descriptor Index", this._dataTypes.unsignedChar, 1, !0, 30),
   BYTE_OFFSET_TO_WAVEFORM_DATA: new LASLoader.PDRInsert("Byte Offset to Waveform Data", this._dataTypes.unsignedLongLong, 8, !0, 31),
   WAVEFORM_PACKET_SIZE_IN_BYTES: new LASLoader.PDRInsert("Waveform Packet Size in Bytes", this._dataTypes.unsignedLong, 4, !0, 39),
   RETURN_POINT_WAVEFORM_LOCATION: new LASLoader.PDRInsert("Return Point Waveform Location", this._dataTypes.float, 4, !0, 43),
   PARAMETRIC_DX: new LASLoader.PDRInsert("Parametric dx", this._dataTypes.float, 4, !0, 47),
   PARAMETRIC_DY: new LASLoader.PDRInsert("Parametric dy", this._dataTypes.float, 4, !0, 51),
   PARAMETRIC_DZ: new LASLoader.PDRInsert("Parametric dz", this._dataTypes.float, 4, !0, 55)
  });
 }
}, LASLoader.PDRFormat9.Keys = Object.assign({}, LASLoader.PDRFormat6.Keys, {
 WAVE_PACKET_DESCRIPTOR_INDEX: "WAVE_PACKET_DESCRIPTOR_INDEX",
 BYTE_OFFSET_TO_WAVEFORM_DATA: "BYTE_OFFSET_TO_WAVEFORM_DATA",
 WAVEFORM_PACKET_SIZE_IN_BYTES: "WAVEFORM_PACKET_SIZE_IN_BYTES",
 RETURN_POINT_WAVEFORM_LOCATION: "RETURN_POINT_WAVEFORM_LOCATION",
 PARAMETRIC_DX: "PARAMETRIC_DX",
 PARAMETRIC_DY: "PARAMETRIC_DY",
 PARAMETRIC_DZ: "PARAMETRIC_DZ"
}), LASLoader.PDRFormat10 = class extends LASLoader.PDRFormat8 {
 constructor() {
  super(), this.minSize = 67, Object.assign(this._inserts, {
   WAVE_PACKET_DESCRIPTOR_INDEX: new LASLoader.PDRInsert("Wave Packet Descriptor Index", this._dataTypes.unsignedChar, 1, !0, 38),
   BYTE_OFFSET_TO_WAVEFORM_DATA: new LASLoader.PDRInsert("Byte Offset to Waveform Data", this._dataTypes.unsignedLongLong, 8, !0, 39),
   WAVEFORM_PACKET_SIZE_IN_BYTES: new LASLoader.PDRInsert("Waveform Packet Size in Bytes", this._dataTypes.unsignedLong, 4, !0, 47),
   RETURN_POINT_WAVEFORM_LOCATION: new LASLoader.PDRInsert("Return Point Waveform Location", this._dataTypes.float, 4, !0, 51),
   PARAMETRIC_DX: new LASLoader.PDRInsert("Parametric dx", this._dataTypes.float, 4, !0, 55),
   PARAMETRIC_DY: new LASLoader.PDRInsert("Parametric dy", this._dataTypes.float, 4, !0, 59),
   PARAMETRIC_DZ: new LASLoader.PDRInsert("Parametric dz", this._dataTypes.float, 4, !0, 63)
  });
 }
}, LASLoader.PDRFormat10.Keys = Object.assign({}, LASLoader.PDRFormat8.Keys, {
 WAVE_PACKET_DESCRIPTOR_INDEX: "WAVE_PACKET_DESCRIPTOR_INDEX",
 BYTE_OFFSET_TO_WAVEFORM_DATA: "BYTE_OFFSET_TO_WAVEFORM_DATA",
 WAVEFORM_PACKET_SIZE_IN_BYTES: "WAVEFORM_PACKET_SIZE_IN_BYTES",
 RETURN_POINT_WAVEFORM_LOCATION: "RETURN_POINT_WAVEFORM_LOCATION",
 PARAMETRIC_DX: "PARAMETRIC_DX",
 PARAMETRIC_DY: "PARAMETRIC_DY",
 PARAMETRIC_DZ: "PARAMETRIC_DZ"
});

class Canvas {
 constructor(e) {
  this._canvasDOM = this.generateCanvasDOM(), this._parentDOM = void 0 !== e ? e.appendChild(this._canvasDOM).parentElement : null, 
  this._uuid = _Math.generateUUID(), this._pixelRatio = window.devicePixelRatio || 1, 
  this.updateSize();
 }
 get pixelRatio() {
  return this._pixelRatio;
 }
 set pixelRatio(e) {
  this._pixelRatio = e;
 }
 set canvasDOM(e) {
  this._canvasDOM = e;
 }
 set parentDOM(e) {
  this._parentDOM = e.appendChild(this._canvasDOM).parentElement, canvasDOM.width = e.clientWidth, 
  canvasDOM.height = e.clientHeight;
 }
 set uuid(e) {
  this._uuid = e;
 }
 set width(e) {
  this._canvasDOM.width = e;
 }
 set height(e) {
  this._canvasDOM.height = e;
 }
 get canvasDOM() {
  return this._canvasDOM;
 }
 get parentDOM() {
  return this._parentDOM;
 }
 get uuid() {
  return this._uuid;
 }
 get width() {
  return this._canvasDOM.width;
 }
 get height() {
  return this._canvasDOM.height;
 }
 generateCanvasDOM(e = "rc-canvas") {
  var t = document.createElement("canvas");
  return t.id = e, t.style.width = "100%", t.style.height = "100%", t.style.padding = "0", 
  t.style.margin = "0", t;
 }
 updateSize() {
  this._canvasDOM.width = Math.floor(this._canvasDOM.clientWidth * this.pixelRatio), 
  this._canvasDOM.height = Math.floor(this._canvasDOM.clientHeight * this.pixelRatio);
 }
}

class Cube extends Mesh {
 constructor(t, e) {
  var i = new Geometry(), r = new MeshBasicMaterial();
  r.color = e, i.vertices = Float32Attribute([ -1, -1, 1, 1, -1, 1, 1, 1, 1, -1, 1, 1, -1, -1, -1, -1, 1, -1, 1, 1, -1, 1, -1, -1, -1, 1, -1, -1, 1, 1, 1, 1, 1, 1, 1, -1, -1, -1, -1, 1, -1, -1, 1, -1, 1, -1, -1, 1, 1, -1, -1, 1, 1, -1, 1, 1, 1, 1, -1, 1, -1, -1, -1, -1, -1, 1, -1, 1, 1, -1, 1, -1 ], 3);
  for (let e = 0; e < i.vertices.array.length; e++) i.vertices.array[e] *= t;
  i.indices = Uint32Attribute([ 0, 1, 2, 0, 2, 3, 4, 5, 6, 4, 6, 7, 8, 9, 10, 8, 10, 11, 12, 13, 14, 12, 14, 15, 16, 17, 18, 16, 18, 19, 20, 21, 22, 20, 22, 23 ], 1), 
  i.computeVertexNormals(), i.uv = Float32Attribute([ 0, 0, 1, 0, 1, 1, 0, 1, 1, 0, 1, 1, 0, 1, 0, 0, 0, 0, 0, 1, 1, 1, 1, 0, 0, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 0, 1, 0, 0, 0, 0, 1, 1, 1 ], 2), 
  super(i, r), this.type = "Cube";
 }
}

class Group extends Object3D {
 constructor() {
  super(Object3D), this.type = "Group", this._frustumCulled = !1;
 }
 static fromJson(e) {
  var t = new Group();
  return super.fromJson(e, t);
 }
 fillRenderArray() {}
 project() {}
 getRequiredPrograms(e) {
  return [];
 }
 update(e, t) {}
}

class Camera extends Object3D {
 constructor() {
  super(Object3D), this.type = "Camera", this._matrixWorldInverse = new Matrix4(), 
  this._projectionMatrix = new Matrix4(), this.projectionMatrixInverse = new Matrix4(), 
  this._up = new Vector3(0, 1, 0), this._frustum = new Group(), this.add(this._frustum), 
  this._frustum.visible = !1;
 }
 get matrixWorldInverse() {
  return this._matrixWorldInverse;
 }
 set matrixWorldInverse(e) {
  this._matrixWorldInverse = e;
 }
 get projectionMatrix() {
  return this._projectionMatrix;
 }
 set projectionMatrix(e) {
  this._projectionMatrix = e;
 }
 get projectionMatrixInverse() {
  return this._projectionMatrixInverse.getInverse(this._projectionMatrix), this._projectionMatrixInverse;
 }
 set projectionMatrixInverse(e) {
  this._projectionMatrixInverse = e;
 }
 get up() {
  return this._up;
 }
 get frustumVisible() {
  return this._frustum.visible;
 }
 set frustumVisible(e) {
  this._frustum.visible = e;
 }
 fillRenderArray(e) {}
 project() {}
 getRequiredPrograms(e) {
  return [];
 }
 update(e) {}
 updateFrustum() {
  this._frustum.clear();
  var t = new Matrix4().getInverse(this._projectionMatrix), i = [], r = new Array(new Vector4(-1, -1, 1, 1), new Vector4(1, -1, 1, 1), new Vector4(1, 1, 1, 1), new Vector4(-1, 1, 1, 1), new Vector4(-1, -1, -1, 1), new Vector4(1, -1, -1, 1), new Vector4(1, 1, -1, 1), new Vector4(-1, 1, -1, 1));
  for (let e = 0; e < r.length; e++) r[e].applyMatrix4(t), r[e].multiplyScalar(1 / r[e].w), 
  i.push(r[e].x, r[e].y, r[e].z);
  var e = new Cube(1, new Color().setColorName("grey")), e = (e.frustumCulled = !1, 
  e.geometry.vertices = new Float32Attribute(i, 3), e.geometry.indices = new Uint32Attribute([ 0, 1, 2, 0, 2, 3, 4, 5, 6, 4, 6, 7, 4, 0, 3, 4, 3, 7, 1, 5, 6, 1, 6, 2, 3, 2, 6, 3, 6, 7, 4, 5, 1, 4, 1, 0 ], 1), 
  e.material.depthTest = !1, e.material.depthWrite = !1, e.material.side = FRONT_AND_BACK_SIDE, 
  e.material.transparent = !0, e.material.opacity = .25, this._frustum.add(e), new Geometry()), e = (e.vertices = new Float32Attribute([ r[0].x, r[0].y, r[0].z, r[1].x, r[1].y, r[1].z ], 3), 
  e.computeVertexNormals(), new Line(e)), e = (this._frustum.add(e), new Geometry()), e = (e.vertices = new Float32Attribute([ r[1].x, r[1].y, r[1].z, r[2].x, r[2].y, r[2].z ], 3), 
  e.computeVertexNormals(), new Line(e)), e = (this._frustum.add(e), new Geometry()), e = (e.vertices = new Float32Attribute([ r[2].x, r[2].y, r[2].z, r[3].x, r[3].y, r[3].z ], 3), 
  e.computeVertexNormals(), new Line(e)), e = (this._frustum.add(e), new Geometry()), e = (e.vertices = new Float32Attribute([ r[3].x, r[3].y, r[3].z, r[0].x, r[0].y, r[0].z ], 3), 
  e.computeVertexNormals(), new Line(e)), e = (this._frustum.add(e), new Geometry()), e = (e.vertices = new Float32Attribute([ r[4].x, r[4].y, r[4].z, r[5].x, r[5].y, r[5].z ], 3), 
  e.computeVertexNormals(), new Line(e)), e = (this._frustum.add(e), new Geometry()), e = (e.vertices = new Float32Attribute([ r[5].x, r[5].y, r[5].z, r[6].x, r[6].y, r[6].z ], 3), 
  e.computeVertexNormals(), new Line(e)), e = (this._frustum.add(e), new Geometry()), e = (e.vertices = new Float32Attribute([ r[6].x, r[6].y, r[6].z, r[7].x, r[7].y, r[7].z ], 3), 
  e.computeVertexNormals(), new Line(e)), e = (this._frustum.add(e), new Geometry()), e = (e.vertices = new Float32Attribute([ r[7].x, r[7].y, r[7].z, r[4].x, r[4].y, r[4].z ], 3), 
  e.computeVertexNormals(), new Line(e)), e = (this._frustum.add(e), new Geometry()), e = (e.vertices = new Float32Attribute([ r[0].x, r[0].y, r[0].z, r[4].x, r[4].y, r[4].z ], 3), 
  e.computeVertexNormals(), new Line(e)), e = (this._frustum.add(e), new Geometry()), e = (e.vertices = new Float32Attribute([ r[1].x, r[1].y, r[1].z, r[5].x, r[5].y, r[5].z ], 3), 
  e.computeVertexNormals(), new Line(e)), e = (this._frustum.add(e), new Geometry()), e = (e.vertices = new Float32Attribute([ r[2].x, r[2].y, r[2].z, r[6].x, r[6].y, r[6].z ], 3), 
  e.computeVertexNormals(), new Line(e)), e = (this._frustum.add(e), new Geometry()), e = (e.vertices = new Float32Attribute([ r[3].x, r[3].y, r[3].z, r[7].x, r[7].y, r[7].z ], 3), 
  e.computeVertexNormals(), new Line(e));
  this._frustum.add(e);
 }
 prePickStoreTBLR() {
  this._top_store = this._top, this._bottom_store = this._bottom, this._left_store = this._left, 
  this._right_store = this._right;
 }
 postPickRestoreTBLR() {
  this._top = this._top_store, this._bottom = this._bottom_store, this._left = this._left_store, 
  this._right = this._right_store, this.updateProjectionMatrix();
 }
}

class PerspectiveCamera extends Camera {
 constructor(e, t, i, r, s = void 0, a = void 0, n = void 0, o = void 0) {
  super(Camera), this.type = "PerspectiveCamera", this._fov = e || 50, this._aspect = t || 1, 
  this._near = i || .1, this._far = r || 1e3, this._top = n || this._near * Math.tan(Math.PI / 180 * .5 * this._fov), 
  this._bottom = o || -this._top, this._left = s || this._aspect * (2 * this._top) * -.5, 
  this._right = a || -this._left, this.updateProjectionMatrix();
 }
 updateProjectionMatrix() {
  this.projectionMatrix.makePerspective(this._left, this._right, this._top, this._bottom, this._near, this._far), 
  this.frustumVisible && this.updateFrustum();
 }
 _updateTBLR() {
  this._top = this._near * Math.tan(Math.PI / 180 * .5 * this._fov), this._bottom = -this._top, 
  this._updateLR();
 }
 _updateLR() {
  this._left = this._aspect * (2 * this._top) * -.5, this._right = -this._left;
 }
 get fov() {
  return this._fov;
 }
 get aspect() {
  return this._aspect;
 }
 get near() {
  return this._near;
 }
 get far() {
  return this._far;
 }
 get left() {
  return this._left;
 }
 get right() {
  return this._right;
 }
 get top() {
  return this._top;
 }
 get bottom() {
  return this._bottom;
 }
 set fov(e) {
  e !== this._fov && (this._fov = e, this._updateTBLR(), this.updateProjectionMatrix(), 
  this._onChangeListener) && (e = {
   uuid: this._uuid,
   changes: {
    fov: this._fov
   }
  }, this._onChangeListener.objectUpdate(e));
 }
 set aspect(e) {
  e !== this._aspect && (this._aspect = e, this._updateLR(), this.updateProjectionMatrix());
 }
 set near(e) {
  e !== this._near && (this._near = e, this._updateTBLR(), this.updateProjectionMatrix(), 
  this._onChangeListener) && (e = {
   uuid: this._uuid,
   changes: {
    near: this._near
   }
  }, this._onChangeListener.objectUpdate(e));
 }
 set far(e) {
  e !== this._far && (this._far = e, this.updateProjectionMatrix(), this._onChangeListener) && (e = {
   uuid: this._uuid,
   changes: {
    far: this._far
   }
  }, this._onChangeListener.objectUpdate(e));
 }
 set left(e) {
  e !== this._left && (this._left = e, this.updateProjectionMatrix(), this._onChangeListener) && (e = {
   uuid: this._uuid,
   changes: {
    left: this._left
   }
  }, this._onChangeListener.objectUpdate(e));
 }
 set right(e) {
  e !== this._right && (this._right = e, this.updateProjectionMatrix(), this._onChangeListener) && (e = {
   uuid: this._uuid,
   changes: {
    right: this._right
   }
  }, this._onChangeListener.objectUpdate(e));
 }
 set top(e) {
  e !== this._top && (this._top = e, this.updateProjectionMatrix(), this._onChangeListener) && (e = {
   uuid: this._uuid,
   changes: {
    top: this._top
   }
  }, this._onChangeListener.objectUpdate(e));
 }
 set bottom(e) {
  e !== this._bottom && (this._bottom = e, this.updateProjectionMatrix(), this._onChangeListener) && (e = {
   uuid: this._uuid,
   changes: {
    bottom: this._bottom
   }
  }, this._onChangeListener.objectUpdate(e));
 }
 toJson() {
  var e = super.toJson();
  return e.fov = this._fov, e.near = this._near, e.far = this._far, e;
 }
 static fromJson(e, t) {
  t = new PerspectiveCamera(e.fov, t, e.near, e.far);
  return super.fromJson(e, t);
 }
 update(e) {
  super.update(e);
  var t, i = !1;
  for (t in e) switch (t) {
  case "fov":
   this._fov = e.fov, delete e.fov, i = !0;
   break;

  case "near":
   this._near = e.near, delete e.near, i = !0;
   break;

  case "far":
   this._far = e.far, delete e.far, i = !0;
   break;

  case "left":
   this._left = e.left, delete e.left, i = !0;
   break;

  case "right":
   this._right = e.right, delete e.right, i = !0;
   break;

  case "top":
   this._top = e.top, delete e.top, i = !0;
   break;

  case "bottom":
   this._bottom = e.bottom, delete e.bottom, i = !0;
  }
  i && this.updateProjectionMatrix();
 }
 narrowProjectionForPicking(e, t, i, r, s, a) {
  this._top = (a + r / 2) / t * (this._top_store - this._bottom_store) + this._bottom_store, 
  this._bottom = (a - r / 2) / t * (this._top_store - this._bottom_store) + this._bottom_store, 
  this._left = (s - i / 2) / e * (this._right_store - this._left_store) + this._left_store, 
  this._right = (s + i / 2) / e * (this._right_store - this._left_store) + this._left_store, 
  this.updateProjectionMatrix();
 }
}

class OrthographicCamera extends Camera {
 constructor(e, t, i, r, s, a) {
  super(Camera), this.type = "OrthographicCamera", this._left = e, this._right = t, 
  this._top = i, this._bottom = r, this._near = void 0 !== s ? s : .1, this._far = void 0 !== a ? a : 2e3, 
  this._aspect = 1, this._zoom = 1, this.updateProjectionMatrix();
 }
 get left() {
  return this._left;
 }
 get right() {
  return this._right;
 }
 get top() {
  return this._top;
 }
 get bottom() {
  return this._bottom;
 }
 set left(e) {
  e !== this._left && (this._left = e, this.updateProjectionMatrix(), this._onChangeListener) && (e = {
   uuid: this._uuid,
   changes: {
    left: this._left
   }
  }, this._onChangeListener.objectUpdate(e));
 }
 set right(e) {
  e !== this._right && (this._right = e, this.updateProjectionMatrix(), this._onChangeListener) && (e = {
   uuid: this._uuid,
   changes: {
    right: this._right
   }
  }, this._onChangeListener.objectUpdate(e));
 }
 set top(e) {
  e !== this._top && (this._top = e, this.updateProjectionMatrix(), this._onChangeListener) && (e = {
   uuid: this._uuid,
   changes: {
    top: this._top
   }
  }, this._onChangeListener.objectUpdate(e));
 }
 set bottom(e) {
  e !== this._bottom && (this._bottom = e, this.updateProjectionMatrix(), this._onChangeListener) && (e = {
   uuid: this._uuid,
   changes: {
    bottom: this._bottom
   }
  }, this._onChangeListener.objectUpdate(e));
 }
 get near() {
  return this._near;
 }
 set near(e) {
  e !== this._near && (this._near = e, this.updateProjectionMatrix(), this._onChangeListener) && (e = {
   uuid: this._uuid,
   changes: {
    near: this._near
   }
  }, this._onChangeListener.objectUpdate(e));
 }
 get far() {
  return this._far;
 }
 set far(e) {
  e !== this._far && (this._far = e, this.updateProjectionMatrix(), this._onChangeListener) && (e = {
   uuid: this._uuid,
   changes: {
    far: this._far
   }
  }, this._onChangeListener.objectUpdate(e));
 }
 set aspect(e) {
  e !== this._aspect && (this._aspect = e, this._updateLR(), this.updateProjectionMatrix());
 }
 get aspect() {
  return this._aspect;
 }
 set zoom(e) {
  e !== this._zoom && (this._zoom = e, this.updateProjectionMatrix());
 }
 get zoom() {
  return this._zoom;
 }
 updateProjectionMatrix() {
  var e = (this._right - this._left) / (2 * this._zoom), t = (this._top - this._bottom) / (2 * this._zoom), i = (this._right + this._left) / 2, r = (this._top + this._bottom) / 2;
  this.projectionMatrix.makeOrthographic(i - e, i + e, r + t, r - t, this._near, this._far), 
  this.frustumVisible && this.updateFrustum();
 }
 _updateLR() {
  this._left = -this._top * this._aspect, this._right = -this._left;
 }
 toJson() {
  var e = super.toJson();
  return e.left = this._left, e.right = this._right, e.top = this._top, e.bottom = this._bottom, 
  e.near = this._near, e.far = this._far, e;
 }
 static fromJson(e) {
  var t = new OrthographicCamera(e.left, e.right, e.top, e.bottom, e.near, e.far);
  return super.fromJson(e, t);
 }
 update(e) {
  super.update(e);
  var t, i = !1;
  for (t in e) switch (t) {
  case "fov":
   this._fov = e.fov, delete e.fov, i = !0;
   break;

  case "near":
   this._near = e.near, delete e.near, i = !0;
   break;

  case "far":
   this._far = e.far, delete e.far, i = !0;
  }
  i && this.updateProjectionMatrix();
 }
 narrowProjectionForPicking(e, t, i, r, s, a) {
  var n = (this._right_store - this._left_store) / (2 * this._zoom), o = (this._top_store - this._bottom_store) / (2 * this._zoom), h = (this._right_store + this._left_store) / 2, u = (this._top_store + this._bottom_store) / 2, l = h - n, h = h + n, n = u + o, u = u - o;
  this.projectionMatrix.makeOrthographic((s - i / 2) / e * (h - l) + l, (s + i / 2) / e * (h - l) + l, (a + r / 2) / t * (n - u) + u, (a - r / 2) / t * (n - u) + u, this._near, this._far), 
  this.frustumVisible && this.updateFrustum();
 }
}

class Raycaster {
 constructor(e, t, i, r) {
  this.ray = new Ray(e, t), this.near = i || 0, this.far = r || 1 / 0;
 }
 setFromCamera(e, t) {
  t instanceof PerspectiveCamera ? (this.ray.origin.setFromMatrixPosition(t.matrixWorld), 
  this.ray.direction.set(e.x, e.y, .5).unproject(t).sub(this.ray.origin).normalize()) : t instanceof OrthographicCamera && (this.ray.origin.set(e.x, e.y, (t.near + t.far) / (t.near - t.far)).unproject(t), 
  this.ray.direction.set(0, 0, -1).transformDirection(t.matrixWorld));
 }
 static _intersectObject(e, t, i, r) {
  if (!1 !== e.visible && (e.raycast(t, i), !0 === r)) for (var s = e.children, a = 0; a < s.length; a++) Raycaster._intersectObject(s[a], t, i, !0);
 }
 intersectObject(e, t) {
  var i = [];
  return Raycaster._intersectObject(e, this, i, t), i.sort(function(e, t) {
   return e.distance - t.distance;
  }), i;
 }
 intersectObjects(e, t) {
  var i = [];
  if (!1 === Array.isArray(e)) console.warn("Raycaster: warning the given objects is not an array."); else {
   for (var r = 0; r < e.length; r++) Raycaster._intersectObject(e[r], this, i, t);
   i.sort(function(e, t) {
    return e.distance - t.distance;
   });
  }
  return i;
 }
}

class Scene extends Object3D {
 constructor() {
  super(Object3D), this.type = "Scene", this._autoUpdate = !0, this.frustumCulled = !1;
 }
 get autoUpdate() {
  return this._autoUpdate;
 }
 set autoUpdate(e) {
  e !== this._autoUpdate && (this._autoUpdate = e, this._onChangeListener) && (e = {
   uuid: this._uuid,
   changes: {
    autoUpdate: this._autoUpdate
   }
  }, this._onChangeListener.objectUpdate(e));
 }
 toJson() {
  var e = super.toJson();
  return e.autoUpdate = this._autoUpdate, e;
 }
 static fromJson(e) {
  var t = new Scene();
  return (t = super.fromJson(e, t))._autoUpdate = e.autoUpdate, t;
 }
 update(e) {
  for (var t in super.update(e), e) "autoUpdate" === t && (this._autoUpdate = e.autoUpdate);
 }
 fillRenderArray() {}
 project() {}
 getRequiredPrograms(e) {
  return [];
 }
 update(e, t) {}
}

class EventDispatcher {
 constructor() {}
 addEventListener(e, t) {
  void 0 === this._listeners && (this._listeners = {});
  var i = this._listeners;
  void 0 === i[e] && (i[e] = []), -1 === i[e].indexOf(t) && i[e].push(t);
 }
 hasEventListener(e, t) {
  var i;
  return void 0 !== this._listeners && void 0 !== (i = this._listeners)[e] && -1 !== i[e].indexOf(t);
 }
 removeEventListener(e, t) {
  var i;
  void 0 !== this._listeners && void 0 !== (e = this._listeners[e]) && -1 !== (i = e.indexOf(t)) && e.splice(i, 1);
 }
 dispatchEvent(i) {
  if (void 0 !== this._listeners) {
   var e = this._listeners[i.type];
   if (void 0 !== e) {
    i.target = this;
    var r = e.slice(0);
    for (let e = 0, t = r.length; e < t; e++) r[e].call(this, i);
   }
  }
 }
}

new Spherical(), new Vector3(), new Vector3();

class Light extends Object3D {
 constructor(e, t, i = {}) {
  super(Object3D), this.type = "Light", this._color = new Color(e), this._intensity = void 0 !== t ? t : 1, 
  this._frustumCulled = !1, this._castShadows = void 0 !== i.castShadows && i.castShadows, 
  this._hardShadows = void 0 === i.hardShadows || i.hardShadows, this._minBias = i.minBias || .005, 
  this._maxBias = i.maxBias || .05, this._shadowmap = null, this._cameraGroup = new Group(), 
  this.add(this._cameraGroup), this.frustumVisible = !1;
 }
 get color() {
  return this._color;
 }
 get intensity() {
  return this._intensity;
 }
 set color(e) {
  this._color = e, this._onChangeListener && (e = {
   uuid: this._uuid,
   changes: {
    color: this._color.getHex()
   }
  }, this._onChangeListener.objectUpdate(e));
 }
 set intensity(e) {
  this._intensity = e, this._onChangeListener && (e = {
   uuid: this._uuid,
   changes: {
    intensity: this._intensity
   }
  }, this._onChangeListener.objectUpdate(e));
 }
 get castShadows() {
  return this._castShadows;
 }
 set castShadows(e) {
  this._castShadows = e, this._onChangeListener && (e = {
   uuid: this._uuid,
   changes: {
    castShadows: this._castShadows
   }
  }, this._onChangeListener.objectUpdate(e));
 }
 get hardShadows() {
  return this._hardShadows;
 }
 set hardShadows(e) {
  this._hardShadows = e, this._onChangeListener && (e = {
   uuid: this._uuid,
   changes: {
    hardShadows: this._hardShadows
   }
  }, this._onChangeListener.objectUpdate(e));
 }
 get minBias() {
  return this._minBias;
 }
 set minBias(e) {
  this._minBias = e, this._onChangeListener && (e = {
   uuid: this._uuid,
   changes: {
    minBias: this._minBias
   }
  }, this._onChangeListener.objectUpdate(e));
 }
 get maxBias() {
  return this._maxBias;
 }
 set maxBias(e) {
  this._maxBias = e, this._onChangeListener && (e = {
   uuid: this._uuid,
   changes: {
    maxBias: this._maxBias
   }
  }, this._onChangeListener.objectUpdate(e));
 }
 get shadowmap() {
  return this._shadowmap;
 }
 set shadowmap(e) {
  this._shadowmap = e;
 }
 get cameraGroup() {
  return this._cameraGroup;
 }
 set cameraGroup(e) {
  this._cameraGroup = e, this._onChangeListener && (e = {
   uuid: this._uuid,
   changes: {
    cameraGroup: this._cameraGroup
   }
  }, this._onChangeListener.objectUpdate(e));
 }
 get frustumVisible() {
  return this._cameraGroup.visible;
 }
 set frustumVisible(t) {
  this._cameraGroup.visible = t;
  for (let e = 0; e < this._cameraGroup.children.length; e++) this._cameraGroup.children[e].frustumVisible = t;
 }
 toJson() {
  var e = super.toJson();
  return e.color = this._color.getHex(), e.intensity = this.intensity, e;
 }
 static fromJson(e, t) {
  return t = t || new Light(e.color, e.intensity), t = super.fromJson(e, t);
 }
 update(e) {
  for (var t in super.update(e), e) switch (t) {
  case "color":
   this._color.setHex(e.color), delete e.color;
   break;

  case "intensity":
   this._intensity = e.intensity, delete e.intensity;
  }
 }
 fillRenderArray(e) {
  e.lights.addlast(this);
 }
 project() {}
 getRequiredPrograms(e) {
  return [];
 }
 update(e) {}
}

class AmbientLight extends Light {
 constructor(e, t) {
  super(e, t), this.type = "AmbientLight";
 }
 static fromJson(e) {
  var t = new AmbientLight(e.color, e.intensity);
  return super.fromJson(e, t);
 }
}

class DirectionalLight extends Light {
 constructor(e, t, i = {}) {
  super(e, t, i), this.type = "DirectionalLight", this._position.set(0, 1, 0), this.updateMatrix(), 
  this._direction = i.direction || new Vector3(0, 0, -1);
  e = new OrthographicCamera(-64, 64, 64, -64, 0, 128);
  this.cameraGroup.add(e), this.shadowmap = new Texture();
 }
 get direction() {
  return this._direction;
 }
 set direction(e) {
  this._direction = e, this._onChangeListener && (e = {
   uuid: this._uuid,
   changes: {
    direction: this._direction
   }
  }, this._onChangeListener.objectUpdate(e));
 }
 get shadowNear() {
  return this.cameraGroup.children[0].near;
 }
 set shadowNear(e) {
  this.cameraGroup.children[0].near = e, this._onChangeListener && (e = {
   uuid: this._uuid,
   changes: {
    shadowNear: this.cameraGroup.children[0].near
   }
  }, this._onChangeListener.objectUpdate(e));
 }
 get shadowFar() {
  return this.cameraGroup.children[0].far;
 }
 set shadowFar(e) {
  this.cameraGroup.children[0].far = e, this._onChangeListener && (e = {
   uuid: this._uuid,
   changes: {
    shadowFar: this.cameraGroup.children[0].far
   }
  }, this._onChangeListener.objectUpdate(e));
 }
 static fromJson(e) {
  var t = new directionalLight(e.color, e.intensity);
  return super.fromJson(e, t);
 }
}

class PointLight extends Light {
 constructor(e, t, i, r, s = {}) {
  super(e, t, s), this.type = "PointLight", this._distance = void 0 !== i ? i : 0, 
  this._decay = void 0 !== r ? r : 1, this._constant = void 0 !== s.constant ? s.constant : 1, 
  this._linear = void 0 !== s.linear ? s.linear : .01, this._quadratic = void 0 !== s.quadratic ? s.quadratic : 1e-4;
  var e = new PerspectiveCamera(90, 1, 8, 128), t = new PerspectiveCamera(90, 1, 8, 128), i = new PerspectiveCamera(90, 1, 8, 128), r = new PerspectiveCamera(90, 1, 8, 128), a = new PerspectiveCamera(90, 1, 8, 128), n = new PerspectiveCamera(90, 1, 8, 128);
  e.lookAt(new Vector3(1, 0, 0), new Vector3(0, -1, 0)), t.lookAt(new Vector3(-1, 0, 0), new Vector3(0, -1, 0)), 
  i.lookAt(new Vector3(0, 1, 0), new Vector3(0, 0, 1)), r.lookAt(new Vector3(0, -1, 0), new Vector3(0, 0, -1)), 
  a.lookAt(new Vector3(0, 0, 1), new Vector3(0, -1, 0)), n.lookAt(new Vector3(0, 0, -1), new Vector3(0, -1, 0)), 
  this.cameraGroup.add(e), this.cameraGroup.add(t), this.cameraGroup.add(i), this.cameraGroup.add(r), 
  this.cameraGroup.add(a), this.cameraGroup.add(n), this.shadowmap = new CubeTexture({
   size: s.smap_size || 256
  });
 }
 set distance(e) {
  this._distance = e, this._onChangeListener && (e = {
   uuid: this._uuid,
   changes: {
    distance: this._distance
   }
  }, this._onChangeListener.objectUpdate(e));
 }
 set decay(e) {
  this._decay = e, this._onChangeListener && (e = {
   uuid: this._uuid,
   changes: {
    decay: this._decay
   }
  }, this._onChangeListener.objectUpdate(e));
 }
 get distance() {
  return this._distance;
 }
 get decay() {
  return this._decay;
 }
 get shadowNear() {
  return this.cameraGroup.children[5].near;
 }
 set shadowNear(e) {
  this.cameraGroup.children[0].near = e, this.cameraGroup.children[1].near = e, 
  this.cameraGroup.children[2].near = e, this.cameraGroup.children[3].near = e, 
  this.cameraGroup.children[4].near = e, this.cameraGroup.children[5].near = e, 
  this._onChangeListener && (e = {
   uuid: this._uuid,
   changes: {
    shadowNear: this.cameraGroup.children[5].near
   }
  }, this._onChangeListener.objectUpdate(e));
 }
 get shadowFar() {
  return this.cameraGroup.children[5].far;
 }
 set shadowFar(e) {
  this.cameraGroup.children[0].far = e, this.cameraGroup.children[1].far = e, this.cameraGroup.children[2].far = e, 
  this.cameraGroup.children[3].far = e, this.cameraGroup.children[4].far = e, this.cameraGroup.children[5].far = e, 
  this._onChangeListener && (e = {
   uuid: this._uuid,
   changes: {
    shadowFar: this.cameraGroup.children[5].far
   }
  }, this._onChangeListener.objectUpdate(e));
 }
 get constant() {
  return this._constant;
 }
 set constant(e) {
  this._constant = e, this._onChangeListener && (e = {
   uuid: this._uuid,
   changes: {
    constant: this._constant
   }
  }, this._onChangeListener.objectUpdate(e));
 }
 get linear() {
  return this._linear;
 }
 set linear(e) {
  this._linear = e, this._onChangeListener && (e = {
   uuid: this._uuid,
   changes: {
    linear: this._linear
   }
  }, this._onChangeListener.objectUpdate(e));
 }
 get quadratic() {
  return this._quadratic;
 }
 set quadratic(e) {
  this._quadratic = e, this._onChangeListener && (e = {
   uuid: this._uuid,
   changes: {
    quadratic: this._quadratic
   }
  }, this._onChangeListener.objectUpdate(e));
 }
 toJson() {
  var e = super.toJson();
  return e.distance = this._distance, e.intensity = this._decay, e;
 }
 static fromJson(e) {
  var t = new PointLight(e.color, e.intensity, e.distance, e.decay);
  return super.fromJson(e, t);
 }
 update(e) {
  for (var t in super.update(e), e) switch (t) {
  case "distance":
   this._distance.set(e.distance), delete e.distance;
   break;

  case "decay":
   this._decay = e.decay, delete e.decay;
  }
 }
}

class SpotLight extends Light {
 constructor(e = {}) {
  super(e.color, e.intensity, e), this.type = "SpotLight", this._distance = e.distance || 0, 
  this._decay = e.decay || 1, this._constant = void 0 !== e.constant ? e.constant : 1, 
  this._linear = void 0 !== e.linear ? e.linear : .01, this._quadratic = void 0 !== e.quadratic ? e.quadratic : 1e-4, 
  this._cutoff = e.cutoff || Math.PI / 4, this._outerCutoff = e.outerCutoff || 1.1 * this.cutoff, 
  this._direction = e.direction || new Vector3(0, 0, -1), this._up = e.up || new Vector3(0, 1, 0);
  e = new PerspectiveCamera(90, 1, 8, 128);
  this.cameraGroup.add(e), this.shadowmap = new Texture();
 }
 get distance() {
  return this._distance;
 }
 set distance(e) {
  this._distance = e, this._onChangeListener && (e = {
   uuid: this._uuid,
   changes: {
    distance: this._distance
   }
  }, this._onChangeListener.objectUpdate(e));
 }
 get decay() {
  return this._decay;
 }
 set decay(e) {
  this._decay = e, this._onChangeListener && (e = {
   uuid: this._uuid,
   changes: {
    decay: this._decay
   }
  }, this._onChangeListener.objectUpdate(e));
 }
 get constant() {
  return this._constant;
 }
 set constant(e) {
  this._constant = e, this._onChangeListener && (e = {
   uuid: this._uuid,
   changes: {
    constant: this._constant
   }
  }, this._onChangeListener.objectUpdate(e));
 }
 get linear() {
  return this._linear;
 }
 set linear(e) {
  this._linear = e, this._onChangeListener && (e = {
   uuid: this._uuid,
   changes: {
    linear: this._linear
   }
  }, this._onChangeListener.objectUpdate(e));
 }
 get quadratic() {
  return this._quadratic;
 }
 set quadratic(e) {
  this._quadratic = e, this._onChangeListener && (e = {
   uuid: this._uuid,
   changes: {
    quadratic: this._quadratic
   }
  }, this._onChangeListener.objectUpdate(e));
 }
 get cutoff() {
  return this._cutoff;
 }
 set cutoff(e) {
  this._cutoff = e, this._onChangeListener && (e = {
   uuid: this._uuid,
   changes: {
    cutoff: this._cutoff
   }
  }, this._onChangeListener.objectUpdate(e));
 }
 get outerCutoff() {
  return this._outerCutoff;
 }
 set outerCutoff(e) {
  this._outerCutoff = e, this._onChangeListener && (e = {
   uuid: this._uuid,
   changes: {
    outerCutoff: this._outerCutoff
   }
  }, this._onChangeListener.objectUpdate(e));
 }
 get direction() {
  return this._direction;
 }
 set direction(e) {
  this._direction = e, this._onChangeListener && (e = {
   uuid: this._uuid,
   changes: {
    direction: this._direction
   }
  }, this._onChangeListener.objectUpdate(e));
 }
 get shadowNear() {
  return this.cameraGroup.children[0].near;
 }
 set shadowNear(e) {
  this.cameraGroup.children[0].near = e, this._onChangeListener && (e = {
   uuid: this._uuid,
   changes: {
    shadowNear: this.cameraGroup.children[0].near
   }
  }, this._onChangeListener.objectUpdate(e));
 }
 get shadowFar() {
  return this.cameraGroup.children[0].far;
 }
 set shadowFar(e) {
  this.cameraGroup.children[0].far = e, this._onChangeListener && (e = {
   uuid: this._uuid,
   changes: {
    shadowFar: this.cameraGroup.children[0].far
   }
  }, this._onChangeListener.objectUpdate(e));
 }
 get fov() {
  return this.cameraGroup.children[0].fov;
 }
 set fov(e) {
  e !== this.cameraGroup.children[0].fov && (this.cameraGroup.children[0].fov = e, 
  this._onChangeListener) && (e = {
   uuid: this._uuid,
   changes: {
    fov: this.cameraGroup.children[0].fov
   }
  }, this._onChangeListener.objectUpdate(e));
 }
}

class CubeTexture extends Texture {
 static DEFAULT_IMAGES = {
  right: null,
  left: null,
  top: null,
  bottom: null,
  front: null,
  back: null
 };
 constructor(e = {}) {
  super(null, e.wrapS, e.wrapT, e.minFilter, e.magFilter, e.internalFormat, e.format, e.type, e.size, e.size), 
  this._uuid = _Math.generateUUID(), this._wrapR = void 0 !== e.wrapR ? e.wrapR : Texture.WRAPPING.ClampToEdgeWrapping, 
  this.images = void 0 !== e.images ? e.images : CubeTexture.DEFAULT_IMAGES, this.flipy = !1;
 }
 get images() {
  return this._images;
 }
 set images(e) {
  this._images = e, this._dirty = !0;
 }
 get wrapR() {
  return this._wrapR;
 }
 set wrapR(e) {
  e !== this._wrapR && (this._wrapR = e, this._dirty = !0);
 }
 applyConfig(e) {
  super.applyConfig(e), this.wrapR = e.wrapR;
 }
}

class MeshLambertMaterial extends Material {
 constructor() {
  super(Material), this.type = "MeshLambertMaterial", this._color = new Color(16777215 * Math.random()), 
  this._emissive = new Color(0 * Math.random()), this.programName = "lambert";
 }
 set color(e) {
  this._color = e, this._onChangeListener && (e = {
   uuid: this._uuid,
   changes: {
    color: this._color.getHex()
   }
  }, this._onChangeListener.materialUpdate(e));
 }
 set emissive(e) {
  this._emissive = e, this._onChangeListener && (e = {
   uuid: this._uuid,
   changes: {
    emissive: this._emissive.getHex()
   }
  }, this._onChangeListener.materialUpdate(e));
 }
 get color() {
  return this._color;
 }
 get emissive() {
  return this._emissive;
 }
 resetProgramFlagsAndValues() {
  super.resetProgramFlagsAndValues();
 }
 requiredProgram(e = void 0) {
  return null === this.requiredProgramTemplate && (this.resetProgramFlagsAndValues(), 
  this.requiredProgramTemplate = new MaterialProgramTemplate(this.programName2, this.flags, this.values, e)), 
  this.requiredProgramTemplate;
 }
 toJson() {
  var e = super.toJson();
  return e.color = this._color.getHex(), e.emissive = this._emissive.getHex(), e;
 }
 static fromJson(e) {
  var t = new MeshPhongMaterial();
  return (t = super.fromJson(e, t))._color = new Color(e.color), t._emissive = new Color(e.emissive), 
  t;
 }
 update(e) {
  for (var t in super.update(e), e) switch (t) {
  case "color":
   this._color.setHex(e.color), delete e.color;
   break;

  case "emissive":
   this._emissive.setHex(e.emissive), delete e.emissive;
  }
 }
}

class SpriteBasicMaterial extends CustomShaderMaterial {
 constructor(e = {}) {
  super(), this.type = "SpriteBasicMaterial", this.programName = "basic_sprite", 
  this.emissive = e.emissive || new Color(0 * Math.random()), this.color = e.color || new Color(16777215 * Math.random()), 
  this.drawCircles = e.drawCircles || !1, this._spriteSize = new Vector2(1, 1), 
  this.setUniform("spriteSize", e.spriteSize || [ 1, 1 ]), this.setUniform("MODE", e.mode || SPRITE_SPACE_SCREEN), 
  this.setAttribute("deltaOffset", e.baseGeometry ? SpriteBasicMaterial._setupDeltaDirections(e.baseGeometry) : null);
 }
 get spriteSize() {
  return this._spriteSize;
 }
 set spriteSize(e) {
  e.equals(this._spriteSize) || (this._spriteSize = e, this._onChangeListener && (e = {
   uuid: this._uuid,
   changes: {
    spriteSize: this._spriteSize
   }
  }, this._onChangeListener.materialUpdate(e)));
 }
 get emissive() {
  return this._emissive;
 }
 set emissive(e) {
  this._emissive = e, this._onChangeListener && (e = {
   uuid: this._uuid,
   changes: {
    emissive: this._emissive.getHex()
   }
  }, this._onChangeListener.materialUpdate(e));
 }
 get color() {
  return this._color;
 }
 set color(e) {
  this._color = e, this._onChangeListener && (e = {
   uuid: this._uuid,
   changes: {
    color: this._color.getHex()
   }
  }, this._onChangeListener.materialUpdate(e));
 }
 update(e) {
  for (var t in super.update(e), e) switch (t) {
  case "emissive":
   this._emissive = e.emissive, delete e.emissive;
   break;

  case "color":
   this._color = e.color, delete e.color;
   break;

  case "spriteSize":
   this._spriteSize = e.spriteSize, delete e.spriteSize;
  }
 }
 static _setupDeltaDirections(e) {
  if (e.indices) {
   var t = e.indices, i = new Array(2 * t.count() * 4);
   for (let e = 0; e < t.count(); e++) i[8 * e + 0] = -1, i[8 * e + 1] = 1, i[8 * e + 2] = -1, 
   i[8 * e + 3] = -1, i[8 * e + 4] = 1, i[8 * e + 5] = 1, i[8 * e + 6] = 1, i[8 * e + 7] = -1;
   return new Float32Attribute(i, 2);
  }
  var r = e.vertices, s = new Array(2 * r.count() * 4);
  for (let e = 0; e < r.count(); e++) s[8 * e + 0] = -1, s[8 * e + 1] = 1, s[8 * e + 2] = -1, 
  s[8 * e + 3] = -1, s[8 * e + 4] = 1, s[8 * e + 5] = 1, s[8 * e + 6] = 1, s[8 * e + 7] = -1;
  return new Float32Attribute(s, 2);
 }
}

class StripeBasicMaterial extends CustomShaderMaterial {
 constructor() {
  super(), this.type = "StripeBasicMaterial", this.programName = "basic_stripe", 
  this._color = new Color(16777215 * Math.random()), this._emissive = new Color(0 * Math.random()), 
  this._lineWidth = 1;
 }
 get lineWidth() {
  return this._lineWidth;
 }
 set lineWidth(e) {
  e !== this._lineWidth && (this._lineWidth = e, this._onChangeListener) && (e = {
   uuid: this._uuid,
   changes: {
    lineWidth: this._lineWidth
   }
  }, this._onChangeListener.materialUpdate(e));
 }
 get color() {
  return this._color;
 }
 set color(e) {
  this._color = e, this._onChangeListener && (e = {
   uuid: this._uuid,
   changes: {
    color: this._color.getHex()
   }
  }, this._onChangeListener.materialUpdate(e));
 }
 get emissive() {
  return this._emissive;
 }
 set emissive(e) {
  e.equals(this._emissive) || (this._emissive = e, this._onChangeListener && (e = {
   uuid: this._uuid,
   changes: {
    emissive: this._emissive.getHex()
   }
  }, this._onChangeListener.materialUpdate(e)));
 }
 update(e) {
  for (var t in super.update(e), e) switch (t) {
  case "color":
   this._color = e.color, delete e.color;
   break;

  case "emissive":
   this._emissive = e.emissive, delete e.emissive;
   break;

  case "lineWidth":
   this._lineWidth = e.lineWidth, delete e.lineWidth;
  }
 }
}

class StripesBasicMaterial extends StripeBasicMaterial {
 constructor(e = {}) {
  super(), this.type = "StripesBasicMaterial", this.programName = "basic_stripes", 
  this.color = e.color || new Color(16777215 * Math.random()), this.emissive = e.emissive || new Color(16777215 * Math.random()), 
  this.lineWidth = void 0 !== e.lineWidth ? e.lineWidth : 1, this.mode = void 0 !== e.mode ? e.mode : STRIPE_SPACE_SCREEN, 
  this.prevVertex = void 0 !== e.baseGeometry ? StripesBasicMaterial._setupPrevVertices(e.baseGeometry) : null, 
  this.nextVertex = void 0 !== e.baseGeometry ? StripesBasicMaterial._setupNextVertices(e.baseGeometry) : null, 
  this.deltaOffset = void 0 !== e.baseGeometry ? StripesBasicMaterial._setupDeltaDirections(e.baseGeometry) : null;
 }
 get lineWidth() {
  return this._lineWidth;
 }
 set lineWidth(e) {
  this._lineWidth = e, this.setUniform("halfLineWidth", e / 2);
 }
 get mode() {
  return this._mode;
 }
 set mode(e) {
  this._mode = e, this.setUniform("MODE", e);
 }
 get prevVertex() {
  return this._prevVertex;
 }
 set prevVertex(e) {
  this._prevVertex = e, this.setAttribute("prevVertex", e);
 }
 get nextVertex() {
  return this._nextVertex;
 }
 set nextVertex(e) {
  this._nextVertex = e, this.setAttribute("nextVertex", e);
 }
 get deltaOffset() {
  return this._deltaOffset;
 }
 set deltaOffset(e) {
  this._deltaOffset = e, this.setAttribute("deltaOffset", e);
 }
 static _setupPrevVertices(e) {
  if (e.indices) {
   var t = e.vertices, i = e.indices, r = new Array(2 * i.count() * 3);
   for (let e = 0; e < i.count(); e++) e % 2 == 0 ? (r[3 * e * 2 + 0] = t.array[3 * i.array[+e] + 0], 
   r[3 * e * 2 + 1] = t.array[3 * i.array[+e] + 1], r[3 * e * 2 + 2] = t.array[3 * i.array[+e] + 2], 
   r[3 * e * 2 + 3] = t.array[3 * i.array[+e] + 0], r[3 * e * 2 + 4] = t.array[3 * i.array[+e] + 1], 
   r[3 * e * 2 + 5] = t.array[3 * i.array[+e] + 2]) : (r[3 * e * 2 + 0] = t.array[3 * i.array[e - 1] + 0], 
   r[3 * e * 2 + 1] = t.array[3 * i.array[e - 1] + 1], r[3 * e * 2 + 2] = t.array[3 * i.array[e - 1] + 2], 
   r[3 * e * 2 + 3] = t.array[3 * i.array[e - 1] + 0], r[3 * e * 2 + 4] = t.array[3 * i.array[e - 1] + 1], 
   r[3 * e * 2 + 5] = t.array[3 * i.array[e - 1] + 2]);
   return new Float32Attribute(r, 3);
  }
  var s = e.vertices, a = new Array(2 * s.count() * 3);
  for (let e = 0; e < s.count(); e++) e % 2 == 0 ? (a[3 * e * 2 + 0] = s.array[3 * +e + 0], 
  a[3 * e * 2 + 1] = s.array[3 * +e + 1], a[3 * e * 2 + 2] = s.array[3 * +e + 2], 
  a[3 * e * 2 + 3] = s.array[3 * +e + 0], a[3 * e * 2 + 4] = s.array[3 * +e + 1], 
  a[3 * e * 2 + 5] = s.array[3 * +e + 2]) : (a[3 * e * 2 + 0] = s.array[3 * (e - 1) + 0], 
  a[3 * e * 2 + 1] = s.array[3 * (e - 1) + 1], a[3 * e * 2 + 2] = s.array[3 * (e - 1) + 2], 
  a[3 * e * 2 + 3] = s.array[3 * (e - 1) + 0], a[3 * e * 2 + 4] = s.array[3 * (e - 1) + 1], 
  a[3 * e * 2 + 5] = s.array[3 * (e - 1) + 2]);
  return new Float32Attribute(a, 3);
 }
 static _setupNextVertices(e) {
  if (e.indices) {
   var t = e.vertices, i = e.indices, r = new Array(2 * i.count() * 3);
   for (let e = 0; e < i.count(); e++) e % 2 == 0 ? (r[3 * e * 2 + 0] = t.array[3 * i.array[e + 1] + 0], 
   r[3 * e * 2 + 1] = t.array[3 * i.array[e + 1] + 1], r[3 * e * 2 + 2] = t.array[3 * i.array[e + 1] + 2], 
   r[3 * e * 2 + 3] = t.array[3 * i.array[e + 1] + 0], r[3 * e * 2 + 4] = t.array[3 * i.array[e + 1] + 1], 
   r[3 * e * 2 + 5] = t.array[3 * i.array[e + 1] + 2]) : (r[3 * e * 2 + 0] = t.array[3 * i.array[e + 0] + 0], 
   r[3 * e * 2 + 1] = t.array[3 * i.array[e + 0] + 1], r[3 * e * 2 + 2] = t.array[3 * i.array[e + 0] + 2], 
   r[3 * e * 2 + 3] = t.array[3 * i.array[e + 0] + 0], r[3 * e * 2 + 4] = t.array[3 * i.array[e + 0] + 1], 
   r[3 * e * 2 + 5] = t.array[3 * i.array[e + 0] + 2]);
   return new Float32Attribute(r, 3);
  }
  var s = e.vertices, a = new Array(2 * s.count() * 3);
  for (let e = 0; e < s.count(); e += 1) e % 2 == 0 ? (a[3 * e * 2 + 0] = s.array[3 * (e + 1) + 0], 
  a[3 * e * 2 + 1] = s.array[3 * (e + 1) + 1], a[3 * e * 2 + 2] = s.array[3 * (e + 1) + 2], 
  a[3 * e * 2 + 3] = s.array[3 * (e + 1) + 0], a[3 * e * 2 + 4] = s.array[3 * (e + 1) + 1], 
  a[3 * e * 2 + 5] = s.array[3 * (e + 1) + 2]) : (a[3 * e * 2 + 0] = s.array[3 * (e + 0) + 0], 
  a[3 * e * 2 + 1] = s.array[3 * (e + 0) + 1], a[3 * e * 2 + 2] = s.array[3 * (e + 0) + 2], 
  a[3 * e * 2 + 3] = s.array[3 * (e + 0) + 0], a[3 * e * 2 + 4] = s.array[3 * (e + 0) + 1], 
  a[3 * e * 2 + 5] = s.array[3 * (e + 0) + 2]);
  return new Float32Attribute(a, 3);
 }
 static _setupDeltaDirections(e) {
  if (e.indices) {
   var t = e.indices, i = new Array(2 * t.count() * 2);
   for (let e = 0; e < t.count(); e++) i[4 * e + 0] = e % 2 == 0 ? -1 : 1, i[4 * e + 1] = 1, 
   i[4 * e + 2] = e % 2 == 0 ? -1 : 1, i[4 * e + 3] = -1;
   return new Float32Attribute(i, 2);
  }
  var r = e.vertices, s = new Array(2 * r.count() * 2);
  for (let e = 0; e < r.count(); e++) s[4 * e + 0] = e % 2 == 0 ? -1 : 1, s[4 * e + 1] = 1, 
  s[4 * e + 2] = e % 2 == 0 ? -1 : 1, s[4 * e + 3] = -1;
  return new Float32Attribute(s, 2);
 }
}

class PointBasicMaterial extends MeshBasicMaterial {
 constructor(e = {}) {
  super(e), this.type = "PointBasicMaterial", this.usePoints = e.usePoints || !0, 
  this.pointSize = e.pointSize || 1, this.drawCircles = e.drawCircles || !1;
 }
}

class Text2DMaterial extends CustomShaderMaterial {
 constructor(e = "text2D", t = {}, i = {}, r = {}) {
  super(e, t, i), this.type = "Text2DMaterial", this.color = r.color || new Color(0, 0, 0);
 }
 get color() {
  return this._color;
 }
 set color(e) {
  this._color = e, this._onChangeListener && (e = {
   uuid: this._uuid,
   changes: {
    color: this._color.getHex()
   }
  }, this._onChangeListener.materialUpdate(e));
 }
}

class Circle extends Mesh {
 constructor(e, t, i, r) {
  var s = e || 1, a = t && 10 < t ? t : 10;
  if (void 0 === r) {
   for (var n = 2 * Math.PI / a, o = [], h = [], u = 0; u < a; u++) o.push(Math.cos(u * n) * s), 
   o.push(Math.sin(u * n) * s), o.push(0), h.push(u, (u + 1) % a, a);
   o.push(0, 0, 0), (r = new Geometry()).vertices = Float32Attribute(o, 3), r.indices = Uint32Attribute(h, 1), 
   r.computeVertexNormals();
  }
  super(r, i), this._n = a, this._radius = s, this.type = "Circle";
 }
 setVerticesColors(e, t, i, r) {
  var s = [];
  void 0 === i && (i = 1), void 0 === r && (r = 1);
  for (var a = 0; a < this._n; a++) s.push(t.r, t.g, t.b, r);
  s.push(e.r, e.g, e.b, i), this._geometry.vertColor = Float32Attribute(s, 4);
 }
 toJson() {
  var e = super.toJson();
  return e.n = this._n, e.radius = this._radius, e;
 }
 static fromJson(e, t, i) {
  i = new Circle(e.n, e.radius, i, t);
  return super.fromJson(e, void 0, void 0, i);
 }
}

class Quad extends Mesh {
 constructor(e, t, i, r, s = !1) {
  super(r = void 0 === r ? Quad.makeGeometry(e, t, s) : r, i), this._xy0 = e, this._xy1 = t, 
  this.type = "Quad";
 }
 static makeGeometry(e, t, i, r = !0, s = !0) {
  var a = new Geometry();
  return i ? (a.vertices = Float32Attribute([ e.x, e.y, 0, t.x, e.y, 0, t.x, t.y, 0, e.x, t.y, 0 ], 3), 
  a.indices = Uint32Attribute([ 0, 1, 2, 0, 2, 3 ], 1), a.uv = Float32Attribute([ 0, 0, 1, 0, 1, 1, 0, 1 ], 2)) : (a.vertices = Float32Attribute([ e.x, t.y, 0, t.x, e.y, 0, e.x, e.y, 0, t.x, t.y, 0 ], 3), 
  a.indices = Uint32Attribute([ 0, 1, 2, 0, 3, 1 ], 1), a.uv = Float32Attribute([ 0, 0, 1, 1, 0, 1, 1, 0 ], 2)), 
  s && (a.vertColor = Float32Attribute([ 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1 ], 4)), 
  r && a.computeVertexNormals(), a;
 }
 toJson() {
  var e = super.toJson();
  return e.xy0 = this._xy0, e.xy1 = this._xy1, e;
 }
 static fromJson(e, t, i) {
  i = new Quad(e.xy0, e.xy1, i, t);
  return super.fromJson(e, void 0, void 0, i);
 }
}

class Sprite extends Quad {
 constructor(e = {}) {
  super(null, null, e.material, e.geometry), this.type = "Sprite";
 }
}

class SpriteGeometry extends Geometry {
 constructor(e = {}) {
  super(), this.type = "SpriteGeometry", e.baseGeometry.normals || e.baseGeometry.computeVertexNormals(), 
  this.vertices = SpriteGeometry._setupVertices(e.baseGeometry), this.indices = SpriteGeometry._setupIndices(e.baseGeometry), 
  this.normals = SpriteGeometry._setupNormals(e.baseGeometry);
 }
 static _setupVertices(e) {
  if (e.indices) {
   var t = e.vertices, i = e.indices, r = new Array(i.count() * t.itemSize * 4);
   for (let e = 0; e < i.count(); e++) r[12 * e + 0] = t.array[3 * i.array[e] + 0], 
   r[12 * e + 1] = t.array[3 * i.array[e] + 1], r[12 * e + 2] = t.array[3 * i.array[e] + 2], 
   r[12 * e + 3] = t.array[3 * i.array[e] + 0], r[12 * e + 4] = t.array[3 * i.array[e] + 1], 
   r[12 * e + 5] = t.array[3 * i.array[e] + 2], r[12 * e + 6] = t.array[3 * i.array[e] + 0], 
   r[12 * e + 7] = t.array[3 * i.array[e] + 1], r[12 * e + 8] = t.array[3 * i.array[e] + 2], 
   r[12 * e + 9] = t.array[3 * i.array[e] + 0], r[12 * e + 10] = t.array[3 * i.array[e] + 1], 
   r[12 * e + 11] = t.array[3 * i.array[e] + 2];
   return new Float32Attribute(r, t.itemSize);
  }
  var s = e.vertices, a = new Array(s.count() * s.itemSize * 4);
  for (let e = 0; e < s.count(); e++) a[12 * e + 0] = s.array[3 * e + 0], a[12 * e + 1] = s.array[3 * e + 1], 
  a[12 * e + 2] = s.array[3 * e + 2], a[12 * e + 3] = s.array[3 * e + 0], a[12 * e + 4] = s.array[3 * e + 1], 
  a[12 * e + 5] = s.array[3 * e + 2], a[12 * e + 6] = s.array[3 * e + 0], a[12 * e + 7] = s.array[3 * e + 1], 
  a[12 * e + 8] = s.array[3 * e + 2], a[12 * e + 9] = s.array[3 * e + 0], a[12 * e + 10] = s.array[3 * e + 1], 
  a[12 * e + 11] = s.array[3 * e + 2];
  return new Float32Attribute(a, s.itemSize);
 }
 static _setupIndices(e) {
  if (e.indices) {
   var t = e.indices, i = new Array(6 * t.count());
   for (let e = 0; e < t.count(); e++) i[6 * e + 0] = 2 * (2 * e + 0) + 0, i[6 * e + 1] = 2 * (2 * e + 0) + 1, 
   i[6 * e + 2] = 2 * (2 * e + 1) + 0, i[6 * e + 3] = 2 * (2 * e + 1) + 1, i[6 * e + 4] = 2 * (2 * e + 1) + 0, 
   i[6 * e + 5] = 2 * (2 * e + 0) + 1;
   return new Uint32Attribute(i, 1);
  }
  var r = e.vertices, s = new Array(6 * r.count());
  for (let e = 0; e < r.count(); e++) s[6 * e + 0] = 2 * (2 * e + 0) + 0, s[6 * e + 1] = 2 * (2 * e + 0) + 1, 
  s[6 * e + 2] = 2 * (2 * e + 1) + 0, s[6 * e + 3] = 2 * (2 * e + 1) + 1, s[6 * e + 4] = 2 * (2 * e + 1) + 0, 
  s[6 * e + 5] = 2 * (2 * e + 0) + 1;
  return new Uint32Attribute(s, 1);
 }
 static _setupNormals(e) {
  if (e.indices) {
   var t = e.indices, i = e.normals, r = new Array(t.count() * i.itemSize * 4);
   for (let e = 0; e < t.count(); e++) r[12 * e + 0] = i.array[3 * t.array[e] + 0], 
   r[12 * e + 1] = i.array[3 * t.array[e] + 1], r[12 * e + 2] = i.array[3 * t.array[e] + 2], 
   r[12 * e + 3] = i.array[3 * t.array[e] + 0], r[12 * e + 4] = i.array[3 * t.array[e] + 1], 
   r[12 * e + 5] = i.array[3 * t.array[e] + 2], r[12 * e + 6] = i.array[3 * t.array[e] + 0], 
   r[12 * e + 7] = i.array[3 * t.array[e] + 1], r[12 * e + 8] = i.array[3 * t.array[e] + 2], 
   r[12 * e + 9] = i.array[3 * t.array[e] + 0], r[12 * e + 10] = i.array[3 * t.array[e] + 1], 
   r[12 * e + 11] = i.array[3 * t.array[e] + 2];
   return new Float32Attribute(r, t.itemSize);
  }
  var s = e.vertices, a = e.normals, n = new Array(s.count() * a.itemSize * 4);
  for (let e = 0; e < s.count(); e++) n[12 * e + 0] = a.array[3 * e + 0], n[12 * e + 1] = a.array[3 * e + 1], 
  n[12 * e + 2] = a.array[3 * e + 2], n[12 * e + 3] = a.array[3 * e + 0], n[12 * e + 4] = a.array[3 * e + 1], 
  n[12 * e + 5] = a.array[3 * e + 2], n[12 * e + 6] = a.array[3 * e + 0], n[12 * e + 7] = a.array[3 * e + 1], 
  n[12 * e + 8] = a.array[3 * e + 2], n[12 * e + 9] = a.array[3 * e + 0], n[12 * e + 10] = a.array[3 * e + 1], 
  n[12 * e + 11] = a.array[3 * e + 2];
  return new Float32Attribute(n, a.itemSize);
 }
 static _setupCenters(e) {
  if (e.indices) {
   var t = e.vertices, i = e.indices, r = new Array(i.count() * t.itemSize * 4);
   for (let e = 0; e < i.count(); e++) r[12 * e + 0] = t.array[3 * i.array[e] + 0], 
   r[12 * e + 1] = t.array[3 * i.array[e] + 1], r[12 * e + 2] = t.array[3 * i.array[e] + 2], 
   r[12 * e + 3] = t.array[3 * i.array[e] + 0], r[12 * e + 4] = t.array[3 * i.array[e] + 1], 
   r[12 * e + 5] = t.array[3 * i.array[e] + 2], r[12 * e + 6] = t.array[3 * i.array[e] + 0], 
   r[12 * e + 7] = t.array[3 * i.array[e] + 1], r[12 * e + 8] = t.array[3 * i.array[e] + 2], 
   r[12 * e + 9] = t.array[3 * i.array[e] + 0], r[12 * e + 10] = t.array[3 * i.array[e] + 1], 
   r[12 * e + 11] = t.array[3 * i.array[e] + 2];
   return new Float32Attribute(r, t.itemSize);
  }
  var s = e.vertices, a = new Array(s.count() * s.itemSize * 4);
  for (let e = 0; e < s.count(); e++) a[12 * e + 0] = s.array[3 * e + 0], a[12 * e + 1] = s.array[3 * e + 1], 
  a[12 * e + 2] = s.array[3 * e + 2], a[12 * e + 3] = s.array[3 * e + 0], a[12 * e + 4] = s.array[3 * e + 1], 
  a[12 * e + 5] = s.array[3 * e + 2], a[12 * e + 6] = s.array[3 * e + 0], a[12 * e + 7] = s.array[3 * e + 1], 
  a[12 * e + 8] = s.array[3 * e + 2], a[12 * e + 9] = s.array[3 * e + 0], a[12 * e + 10] = s.array[3 * e + 1], 
  a[12 * e + 11] = s.array[3 * e + 2];
  return new Float32Attribute(a, s.itemSize);
 }
}

class Stripe extends Mesh {
 constructor(e, t = new StripeBasicMaterial(), i = new PickingShaderMaterial("stripe"), r = !1, s = 8) {
  Array.isArray(e) && (e = new Float32Attribute(e, 3)), r && (e = _perp(e, s));
  var r = new Geometry(), s = _setupIndex(e), a = _setupVertex(e);
  r.indices = new Uint32Attribute(s, 1), r.vertices = new Float32Attribute(a.stripePositions, e.itemSize), 
  t.setAttribute("prevPosition", new Float32Attribute(a.stripePrevPosition, e.itemSize)), 
  t.setAttribute("nextPosition", new Float32Attribute(a.stripeNextPosition, e.itemSize)), 
  t.setAttribute("normalDirection", new Float32Attribute(a.stripeNormalDirection, 1)), 
  t.setUniform("lineWidth", 1), super(r, t, i), this.type = "Stripe", this._dashed = !1;
 }
 set dashed(e) {
  this._dashed = e;
 }
 get dashed() {
  return this._dashed;
 }
}

function _setupIndex(t) {
 var i = [];
 for (let e = 0; e < 2 * t.count() - 2; e++) e % 2 == 0 ? (i.push(e + 0), i.push(e + 1), 
 i.push(e + 2)) : (i.push(e + 0), i.push(e + 2), i.push(e + 1));
 return i;
}

function _setupVertex(t) {
 var i = new Array(t.count() * t.itemSize * 2), r = new Array(t.count() * t.itemSize * 2), s = new Array(t.count() * t.itemSize * 2), a = new Array(2 * t.count());
 for (let e = 0; e < t.count(); e++) i[e * t.itemSize * 2 + 0] = t.array[e * t.itemSize + 0], 
 i[e * t.itemSize * 2 + 1] = t.array[e * t.itemSize + 1], i[e * t.itemSize * 2 + 2] = t.array[e * t.itemSize + 2], 
 i[e * t.itemSize * 2 + 3] = t.array[e * t.itemSize + 0], i[e * t.itemSize * 2 + 4] = t.array[e * t.itemSize + 1], 
 i[e * t.itemSize * 2 + 5] = t.array[e * t.itemSize + 2], 0 === e ? (r[e * t.itemSize * 2 + 0] = t.array[e * t.itemSize + 0], 
 r[e * t.itemSize * 2 + 1] = t.array[e * t.itemSize + 1], r[e * t.itemSize * 2 + 2] = t.array[e * t.itemSize + 2], 
 r[e * t.itemSize * 2 + 3] = t.array[e * t.itemSize + 0], r[e * t.itemSize * 2 + 4] = t.array[e * t.itemSize + 1], 
 r[e * t.itemSize * 2 + 5] = t.array[e * t.itemSize + 2], s[e * t.itemSize * 2 + 0] = t.array[e * t.itemSize + t.itemSize + 0], 
 s[e * t.itemSize * 2 + 1] = t.array[e * t.itemSize + t.itemSize + 1], s[e * t.itemSize * 2 + 2] = t.array[e * t.itemSize + t.itemSize + 2], 
 s[e * t.itemSize * 2 + 3] = t.array[e * t.itemSize + t.itemSize + 0], s[e * t.itemSize * 2 + 4] = t.array[e * t.itemSize + t.itemSize + 1], 
 s[e * t.itemSize * 2 + 5] = t.array[e * t.itemSize + t.itemSize + 2]) : 1 <= e && e <= t.count() - 2 ? (r[e * t.itemSize * 2 + 0] = t.array[e * t.itemSize - t.itemSize + 0], 
 r[e * t.itemSize * 2 + 1] = t.array[e * t.itemSize - t.itemSize + 1], r[e * t.itemSize * 2 + 2] = t.array[e * t.itemSize - t.itemSize + 2], 
 r[e * t.itemSize * 2 + 3] = t.array[e * t.itemSize - t.itemSize + 0], r[e * t.itemSize * 2 + 4] = t.array[e * t.itemSize - t.itemSize + 1], 
 r[e * t.itemSize * 2 + 5] = t.array[e * t.itemSize - t.itemSize + 2], s[e * t.itemSize * 2 + 0] = t.array[e * t.itemSize + t.itemSize + 0], 
 s[e * t.itemSize * 2 + 1] = t.array[e * t.itemSize + t.itemSize + 1], s[e * t.itemSize * 2 + 2] = t.array[e * t.itemSize + t.itemSize + 2], 
 s[e * t.itemSize * 2 + 3] = t.array[e * t.itemSize + t.itemSize + 0], s[e * t.itemSize * 2 + 4] = t.array[e * t.itemSize + t.itemSize + 1], 
 s[e * t.itemSize * 2 + 5] = t.array[e * t.itemSize + t.itemSize + 2]) : e === t.count() - 1 && (r[e * t.itemSize * 2 + 0] = t.array[e * t.itemSize - t.itemSize + 0], 
 r[e * t.itemSize * 2 + 1] = t.array[e * t.itemSize - t.itemSize + 1], r[e * t.itemSize * 2 + 2] = t.array[e * t.itemSize - t.itemSize + 2], 
 r[e * t.itemSize * 2 + 3] = t.array[e * t.itemSize - t.itemSize + 0], r[e * t.itemSize * 2 + 4] = t.array[e * t.itemSize - t.itemSize + 1], 
 r[e * t.itemSize * 2 + 5] = t.array[e * t.itemSize - t.itemSize + 2], s[e * t.itemSize * 2 + 0] = t.array[e * t.itemSize + 0], 
 s[e * t.itemSize * 2 + 1] = t.array[e * t.itemSize + 0 + 1], s[e * t.itemSize * 2 + 2] = t.array[e * t.itemSize + 0 + 2], 
 s[e * t.itemSize * 2 + 3] = t.array[e * t.itemSize + 0], s[e * t.itemSize * 2 + 4] = t.array[e * t.itemSize + 0 + 1], 
 s[e * t.itemSize * 2 + 5] = t.array[e * t.itemSize + 0 + 2]), a[2 * e + 0] = 1, 
 a[2 * e + 1] = -1;
 return {
  stripePositions: i,
  stripePrevPosition: r,
  stripeNextPosition: s,
  stripeNormalDirection: a
 };
}

function _perp(a, e) {
 var n = [];
 for (let s = 0; s <= 1; s += 1 / e) {
  let t = 0, i = 0, r = 0;
  for (let e = 0; e < a.count(); e++) {
   var o = _bint(e, a.count() - 1, s);
   t += a.array[e * a.itemSize + 0] * o, i += a.array[e * a.itemSize + 1] * o, r += a.array[e * a.itemSize + 2] * o;
  }
  n.push(t, i, r);
 }
 return a.array = n, a;
}

function _bint(e, t, i) {
 return _binomial(t, e) * Math.pow(i, e) * Math.pow(1 - i, t - e);
}

function _binomial(e, t) {
 if ("number" != typeof e || "number" != typeof t) return !1;
 for (var i = 1, r = e - t + 1; r <= e; r++) i *= r;
 for (r = 1; r <= t; r++) i /= r;
 return i;
}

class Stripes extends Mesh {
 constructor(e = {}) {
  super(e.geometry, e.material, e.pickingMaterial), this.type = "Stripes", this.GBufferMaterial = void 0 !== e.GBufferMaterial ? e.GBufferMaterial : Stripes.assembleGBufferMaterial({
   baseMaterial: this.material
  }), this._dashed = !1;
 }
 get material() {
  return super.material;
 }
 set material(e) {
  super.material = e, this.GBufferMaterial.setUniform("halfLineWidth", this.material.lineWidth / 2), 
  this.GBufferMaterial.setUniform("MODE", this.material.mode), this.GBufferMaterial.setAttribute("prevVertex", this.material.prevVertex), 
  this.GBufferMaterial.setAttribute("nextVertex", this.material.nextVertex), this.GBufferMaterial.setAttribute("deltaOffset", this.material.deltaOffset);
 }
 get GBufferMaterial() {
  return super.GBufferMaterial;
 }
 set GBufferMaterial(e) {
  super.GBufferMaterial = e;
 }
 set dashed(e) {
  this._dashed = e;
 }
 get dashed() {
  return this._dashed;
 }
 static assembleGBufferMaterial(e) {
  return new CustomShaderMaterial("GBuffer_stripes", {
   halfLineWidth: e.baseMaterial.lineWidth / 2,
   MODE: e.baseMaterial.mode
  }, {
   prevVertex: e.baseMaterial.prevVertex,
   nextVertex: e.baseMaterial.nextVertex,
   deltaOffset: e.baseMaterial.deltaOffset
  });
 }
}

class StripesGeometry extends Geometry {
 constructor(e = {}) {
  super(), this.type = "StripesGeometry", this.vertices = StripesGeometry._setupVertices(e.baseGeometry), 
  this.indices = StripesGeometry._setupIndices(e.baseGeometry);
 }
 static _setupVertices(e) {
  if (e.indices) {
   var t = e.vertices, i = e.indices, r = new Array(2 * i.count() * 3);
   for (let e = 0; e < i.count(); e++) r[3 * e * 2 + 0] = t.array[3 * i.array[e] + 0], 
   r[3 * e * 2 + 1] = t.array[3 * i.array[e] + 1], r[3 * e * 2 + 2] = t.array[3 * i.array[e] + 2], 
   r[3 * e * 2 + 3] = t.array[3 * i.array[e] + 0], r[3 * e * 2 + 4] = t.array[3 * i.array[e] + 1], 
   r[3 * e * 2 + 5] = t.array[3 * i.array[e] + 2];
   return new Float32Attribute(r, 3);
  }
  var s = e.vertices, a = new Array(2 * s.count() * 3);
  for (let e = 0; e < s.count(); e++) a[3 * e * 2 + 0] = s.array[3 * e + 0], a[3 * e * 2 + 1] = s.array[3 * e + 1], 
  a[3 * e * 2 + 2] = s.array[3 * e + 2], a[3 * e * 2 + 3] = s.array[3 * e + 0], 
  a[3 * e * 2 + 4] = s.array[3 * e + 1], a[3 * e * 2 + 5] = s.array[3 * e + 2];
  return new Float32Attribute(a, 3);
 }
 static _setupIndices(e) {
  if (e.indices) {
   var t = e.indices, i = new Array(3 * t.count());
   for (let e = 0; e < t.count(); e += 2) i[3 * e + 0] = 2 * (e + 0) + 0, i[3 * e + 1] = 2 * (e + 0) + 1, 
   i[3 * e + 2] = 2 * (e + 1) + 0, i[3 * e + 3] = 2 * (e + 1) + 1, i[3 * e + 4] = 2 * (e + 1) + 0, 
   i[3 * e + 5] = 2 * (e + 0) + 1;
   return new Uint32Attribute(i, 1);
  }
  var r = e.vertices, s = new Array(3 * r.count());
  for (let e = 0; e < r.count(); e += 2) s[3 * e + 0] = 2 * (e + 0) + 0, s[3 * e + 1] = 2 * (e + 0) + 1, 
  s[3 * e + 2] = 2 * (e + 1) + 0, s[3 * e + 3] = 2 * (e + 1) + 1, s[3 * e + 4] = 2 * (e + 1) + 0, 
  s[3 * e + 5] = 2 * (e + 0) + 1;
  return new Uint32Attribute(s, 1);
 }
}

class Text2D extends Mesh {
 constructor(e = {}) {
  super(), this.type = "Text2D", this.frustumCulled = !1, this.pickable = !1, this._text = void 0 !== e.text ? e.text : "New text", 
  this._fontTexture = void 0 !== e.fontTexture ? e.fontTexture : null, this._xPos = void 0 !== e.xPos ? e.xPos : 0, 
  this._yPos = void 0 !== e.yPos ? e.yPos : 0, this._fontSize = void 0 !== e.fontSize ? e.fontSize : 32, 
  this._cellAspect = void 0 !== e.cellAspect ? e.cellAspect : 1, this._mode = void 0 !== e.mode ? e.mode : TEXT2D_SPACE_SCREEN, 
  this._mode === TEXT2D_SPACE_SCREEN ? (this.geometry = this.setText2D(this._text, this._xPos, this._yPos, this._fontSize), 
  this.material = new Text2DMaterial(), this.material.setAttribute("deltaOffset", new Float32Attribute([])), 
  this.material.setUniform("MODE", TEXT2D_SPACE_SCREEN), this.material.addMap(this._fontTexture)) : this._mode === TEXT2D_SPACE_WORLD ? (this.geometry = Text2D._assembleGeometry({
   text: this._text
  }), this.material = Text2D._assembleMaterial({
   text: this._text,
   fontSize: this._fontSize,
   cellAspect: this._cellAspect,
   offset: new Vector2(this._xPos, this._yPos),
   mode: this._mode
  }), this.material.addMap(this._fontTexture)) : console.error("[" + this.type + "]: Unknow mode [" + e.mode + "]"), 
  this.material.transparent = !0;
 }
 set text(e) {
  this._text = e, this.geometry = this.setText2D(this._text, this._xPos, this._yPos, this._fontSize);
 }
 get text() {
  return this._text;
 }
 set fontTexture(e) {
  this._fontTexture = e, this.material.clearMaps(), this.material.addMap(this._fontTexture);
 }
 get fontTexture() {
  return this._fontTexture;
 }
 set xPos(e) {
  this._xPos = e;
 }
 get xPos() {
  return this._xPos;
 }
 set yPos(e) {
  this._yPos = e;
 }
 get yPos() {
  return this._yPos;
 }
 set fontSize(e) {
  this._fontSize = e;
 }
 get fontSize() {
  return this._fontSize;
 }
 static _assembleGeometry(e) {
  var t = new Geometry();
  return t.vertices = Text2D._setupVertices(e.text), t.indices = Text2D._setupIndices(e.text), 
  t.uv = Text2D._setupUVs(e.text), t;
 }
 static _setupVertices(t) {
  var i = new Array(4 * t.length * 2);
  for (let e = 0; e < t.length; e++) i[4 * e * 2 + 0] = 0, i[4 * e * 2 + 1] = 0, 
  i[4 * e * 2 + 2] = 0, i[4 * e * 2 + 3] = 0, i[4 * e * 2 + 4] = 0, i[4 * e * 2 + 5] = 0, 
  i[4 * e * 2 + 6] = 0, i[4 * e * 2 + 7] = 0;
  return new Float32Attribute(i, 2);
 }
 static _setupIndices(t) {
  var i = new Array(6 * t.length);
  for (let e = 0; e < t.length; e++) i[6 * e + 0] = 2 * (2 * e + 0) + 0, i[6 * e + 1] = 2 * (2 * e + 0) + 1, 
  i[6 * e + 2] = 2 * (2 * e + 1) + 0, i[6 * e + 3] = 2 * (2 * e + 1) + 1, i[6 * e + 4] = 2 * (2 * e + 1) + 0, 
  i[6 * e + 5] = 2 * (2 * e + 0) + 1;
  return new Uint32Attribute(i, 1);
 }
 static _setupUVs(t) {
  var i = new Array(4 * t.length * 2);
  for (let e = 0; e < t.length; e++) {
   var r = t.charAt(e), s = r.charCodeAt() % 16 / 16, r = Math.floor(r.charCodeAt() / 16) / 16, a = new Vector2(s, 1 - r), n = new Vector2(s, 1 - (r + 1 / 16)), o = new Vector2(s + 1 / 16, 1 - r), s = new Vector2(s + 1 / 16, 1 - (r + 1 / 16));
   i[4 * e * 2 + 0] = a.x, i[4 * e * 2 + 1] = a.y, i[4 * e * 2 + 2] = n.x, i[4 * e * 2 + 3] = n.y, 
   i[4 * e * 2 + 4] = o.x, i[4 * e * 2 + 5] = o.y, i[4 * e * 2 + 6] = s.x, i[4 * e * 2 + 7] = s.y;
  }
  return new Float32Attribute(i, 2);
 }
 static _assembleMaterial(e) {
  var t = new Text2DMaterial();
  return t.setAttribute("deltaOffset", Text2D._setupDeltaDirections(e.text, e.fontSize, e.cellAspect, e.offset)), 
  t.setUniform("MODE", e.mode), t;
 }
 static _setupCenterOffsets(t) {
  var i = new Array(4 * t.length * 2);
  for (let e = 0; e < t.length; e++) i[4 * e * 2 + 0] = e, i[4 * e * 2 + 1] = 0, 
  i[4 * e * 2 + 2] = e, i[4 * e * 2 + 3] = 0, i[4 * e * 2 + 4] = e, i[4 * e * 2 + 5] = 0, 
  i[4 * e * 2 + 6] = e, i[4 * e * 2 + 7] = 0;
  return new Float32Attribute(i, 2);
 }
 static _setupPositionIdentifiers(t) {
  var i = new Array(4 * t.length * 2);
  for (let e = 0; e < t.length; e++) i[4 * e * 2 + 0] = -1, i[4 * e * 2 + 1] = 1, 
  i[4 * e * 2 + 2] = -1, i[4 * e * 2 + 3] = -1, i[4 * e * 2 + 4] = 1, i[4 * e * 2 + 5] = 1, 
  i[4 * e * 2 + 6] = 1, i[4 * e * 2 + 7] = -1;
  return new Float32Attribute(i, 2);
 }
 static _setupDeltaDirections(t, i, r, s) {
  var a = new Array(4 * t.length * 2);
  for (let e = 0; e < t.length; e++) a[4 * e * 2 + 0] = -1 * i / 2 * r + e * i * r + s.x, 
  a[4 * e * 2 + 1] = +i / 2 + 0 * i + s.y, a[4 * e * 2 + 2] = -1 * i / 2 * r + e * i * r + s.x, 
  a[4 * e * 2 + 3] = -1 * i / 2 + 0 * i + s.y, a[4 * e * 2 + 4] = +i / 2 * r + e * i * r + s.x, 
  a[4 * e * 2 + 5] = +i / 2 + 0 * i + s.y, a[4 * e * 2 + 6] = +i / 2 * r + e * i * r + s.x, 
  a[4 * e * 2 + 7] = -1 * i / 2 + 0 * i + s.y;
  return new Float32Attribute(a, 2);
 }
 setText2D(t, i, r, s) {
  var a = new Array(), n = new Array();
  for (let e = 0; e < t.length; e++) {
   var o = new Vector2(i + e * s, r + s), h = new Vector2(i + e * s + s, r + s), u = new Vector2(i + e * s, r), l = new Vector2(i + e * s + s, r), o = (a.push(o.x, o.y), 
   a.push(u.x, u.y), a.push(h.x, h.y), a.push(h.x, h.y), a.push(u.x, u.y), a.push(l.x, l.y), 
   t.charAt(e)), h = o.charCodeAt() % 16 / 16, u = Math.floor(o.charCodeAt() / 16) / 16, l = new Vector2(h, 1 - u), o = new Vector2(h + 1 / 16, 1 - u), _ = new Vector2(h, 1 - (u + 1 / 16)), h = new Vector2(h + 1 / 16, 1 - (u + 1 / 16));
   n.push(l.x, l.y), n.push(_.x, _.y), n.push(o.x, o.y), n.push(o.x, o.y), n.push(_.x, _.y), 
   n.push(h.x, h.y);
  }
  var e = new Geometry();
  return e.vertices = new Float32Attribute(a, 2), e.uv = new Float32Attribute(n, 2), 
  e;
 }
}

class Grid extends Mesh {
 constructor(e, t, i = 1, r = 10, s = 128, a) {
  super(e, t), this.type = "Grid", this.pickable = !1, this.frustumCulled = !1, 
  this._plane = new Plane(new Vector3(0, 1, 0), 0), this._n = s * (1 / i), this.geometry = new Geometry(), 
  this.geometry.vertices = new Float32Attribute(this._generateLinePositionsAttribute().concat(this._generateLinePositionsAttribute()), 3), 
  this.material = new CustomShaderMaterial("grid", {
   "plane.normal": this._plane.normal.toArray(),
   "plane.constant": this._plane.constant,
   unitSize: i,
   orderOfMagnitude: r,
   LColor: [ .5, .5, .5 ],
   UColor: [ .5, .5, .5 ],
   lineBase: this._n
  }, {
   VIDLU: new Float32Attribute(this._generateLineIDsAttribute(0).concat(this._generateLineIDsAttribute(1)), 1),
   offset: new Float32Attribute(this._generateLineOffsetAttribute(1).concat(this._generateLineOffsetAttribute(1)), 3)
  }), this.material.transparent = !0, this.material.lights = !1, this.renderingPrimitive = LINES;
 }
 _generateLines() {
  var t = [], i = 2048;
  t.push(-i, 0, 0, i, 0, 0);
  for (let e = -1; -64 <= e; e--) t.push(-i, 0, 9 * e, i, 0, 9 * e);
  for (let e = 1; e <= 64; e++) t.push(-i, 0, 9 * e, i, 0, 9 * e);
  t.push(0, 0, -i, 0, 0, i);
  for (let e = -1; -64 <= e; e--) t.push(9 * e, 0, -i, 9 * e, 0, i);
  for (let e = 1; e <= 64; e++) t.push(9 * e, 0, -i, 9 * e, 0, i);
  return t;
 }
 _generateLineIDsAttribute(t) {
  var i = new Array(), r = this._n;
  i.push(t, t);
  for (let e = -1; e >= -r; e--) i.push(t, t);
  for (let e = 1; e <= r; e++) i.push(t, t);
  i.push(t, t);
  for (let e = -1; e >= -r; e--) i.push(t, t);
  for (let e = 1; e <= r; e++) i.push(t, t);
  return i;
 }
 _generateLinePositionsAttribute() {
  var t = new Array(), i = this._n;
  t.push(-1, 0, 0, 1, 0, 0);
  for (let e = -1; e >= -i; e--) t.push(-1, 0, 0, 1, 0, 0);
  for (let e = 1; e <= i; e++) t.push(-1, 0, 0, 1, 0, 0);
  t.push(0, 0, -1, 0, 0, 1);
  for (let e = -1; e >= -i; e--) t.push(0, 0, -1, 0, 0, 1);
  for (let e = 1; e <= i; e++) t.push(0, 0, -1, 0, 0, 1);
  return t;
 }
 _generateLineOffsetAttribute(t = 1) {
  var i = new Array(), r = this._n;
  i.push(0, 0, 0, 0, 0, 0);
  for (let e = -1; e >= -r; e--) i.push(0, 0, e * t, 0, 0, e * t);
  for (let e = 1; e <= r; e++) i.push(0, 0, e * t, 0, 0, e * t);
  i.push(0, 0, 0, 0, 0, 0);
  for (let e = -1; e >= -r; e--) i.push(e * t, 0, 0, e * t, 0, 0);
  for (let e = 1; e <= r; e++) i.push(e * t, 0, 0, e * t, 0, 0);
  return i;
 }
}

class ZSpriteBasicMaterial extends CustomShaderMaterial {
 constructor(e = {}) {
  super(), this.type = "ZSpriteBasicMaterial", this.programName = "basic_zsprite", 
  this.setUniform("SpriteMode", "SpriteMode" in e ? e.SpriteMode : SPRITE_SPACE_SCREEN), 
  this.setUniform("SpriteSize", "SpriteSize" in e ? e.SpriteSize : [ 1, 1 ]), this.color = e.color || new Color(16777215 * Math.random()), 
  this.emissive = e.emissive || new Color(0 * Math.random()), this.diffuse = e.diffuse || new Color(16777215 * Math.random());
 }
 clone_for_picking() {
  var e = new ZSpriteBasicMaterial({
   SpriteMode: this.getUniform("SpriteMode"),
   SpriteSize: this.getUniform("SpriteSize"),
   color: this.color,
   emissive: this.emissive,
   diffuse: this.diffuse
  });
  for (const t of this.maps) e.addMap(t);
  return e._instanceData = this._instanceData, e.addSBFlag("PICK_MODE_UINT"), e.setUniform("u_PickInstance", !1), 
  e;
 }
 clone_for_outline() {
  var e = new ZSpriteBasicMaterial({
   SpriteMode: this.getUniform("SpriteMode"),
   SpriteSize: this.getUniform("SpriteSize"),
   color: this.color,
   emissive: this.emissive,
   diffuse: this.diffuse
  });
  for (const t of this.maps) e.addMap(t);
  return e._instanceData = this._instanceData, e.addSBFlag("OUTLINE"), e.setUniform("u_OutlineGivenInstances", !1), 
  e.setAttribute("a_OutlineInstances", Int32Attribute([ 0 ], 1, 2147483647)), e;
 }
 get color() {
  return this._color;
 }
 set color(e) {
  this._color = e, this._onChangeListener && (e = {
   uuid: this._uuid,
   changes: {
    color: this._color.getHex()
   }
  }, this._onChangeListener.materialUpdate(e));
 }
 get emissive() {
  return this._emissive;
 }
 set emissive(e) {
  this._emissive = e, this._onChangeListener && (e = {
   uuid: this._uuid,
   changes: {
    emissive: this._emissive.getHex()
   }
  }, this._onChangeListener.materialUpdate(e));
 }
 get diffuse() {
  return this._diffuse;
 }
 set diffuse(e) {
  this._diffuse = e, this._onChangeListener && (e = {
   uuid: this._uuid,
   changes: {
    diffuse: this._diffuse.getHex()
   }
  }, this._onChangeListener.materialUpdate(e));
 }
 outline_instances_setup(e) {
  this.setUniform("u_OutlineGivenInstances", !0);
  var t = this.getAttribute("a_OutlineInstances");
  t.array = new Int32Array(e), t.divisor = 1;
 }
 outline_instances_reset() {
  this.setUniform("u_OutlineGivenInstances", !1);
  var e = this.getAttribute("a_OutlineInstances");
  e.array = new Int32Array([ 0 ]), e.divisor = 2147483647;
 }
 update(e) {
  for (var t in super.update(e), e) switch (t) {
  case "color":
   this._color = e.color, delete e.color;
   break;

  case "emissive":
   this._emissive = e.emissive, delete e.emissive;
   break;

  case "diffuse":
   this._diffuse = e.diffuse, delete e.diffuse;
  }
 }
}

class ZSprite extends Mesh {
 constructor(e = null, t = null) {
  null === e && (i = new Vector2(-.5, .5), r = new Vector2(.5, -.5), e = Quad.makeGeometry(i, r, !1, !1, !1));
  var i = (t = null === t ? new ZSpriteBasicMaterial() : t).clone_for_picking(), r = t.clone_for_outline();
  super(e, t, i, r), this.type = "ZSprite";
 }
}

class ZShapeBasicMaterial extends CustomShaderMaterial {
 constructor(e = {}) {
  super(), this.type = "ZShapeBasicMaterial", this.programName = "basic_zshape", 
  this.setUniform("ShapeSize", "ShapeSize" in e ? e.ShapeSize : [ 1, 1, 1 ]), this.color = e.color || new Color(16777215 * Math.random()), 
  this.emissive = e.emissive || new Color(16777215 * Math.random()), this.diffuse = e.diffuse || new Color(16777215 * Math.random()), 
  this.side = e.side || FRONT_AND_BACK_SIDE, this._specular = new Color(8388607.5), 
  this._shininess = 64;
 }
 set specular(e) {
  this._specular = e, this._onChangeListener && (e = {
   uuid: this._uuid,
   changes: {
    specular: this._specular.getHex()
   }
  }, this._onChangeListener.materialUpdate(e));
 }
 set shininess(e) {
  this._shininess = e, this._onChangeListener && (e = {
   uuid: this._uuid,
   changes: {
    shininess: this._shininess
   }
  }, this._onChangeListener.materialUpdate(e));
 }
 get specular() {
  return this._specular;
 }
 get shininess() {
  return this._shininess;
 }
 clone_for_picking() {
  var e = new ZShapeBasicMaterial({
   ShapeSize: this.getUniform("ShapeSize"),
   color: this.color,
   emissive: this.emissive,
   diffuse: this.diffuse,
   side: this.side
  });
  this.hasSBFlag("SCALE_PER_INSTANCE") && e.addSBFlag("SCALE_PER_INSTANCE"), this.hasSBFlag("MAT4_PER_INSTANCE") && e.addSBFlag("MAT4_PER_INSTANCE");
  for (const t of this.maps) e.addMap(t);
  return e._instanceData = this._instanceData, e.addSBFlag("PICK_MODE_UINT"), e.setUniform("u_PickInstance", !1), 
  e;
 }
 clone_for_outline() {
  var e = new ZShapeBasicMaterial({
   ShapeSize: this.getUniform("ShapeSize"),
   color: this.color,
   emissive: this.emissive,
   diffuse: this.diffuse,
   side: this.side
  });
  this.hasSBFlag("SCALE_PER_INSTANCE") && e.addSBFlag("SCALE_PER_INSTANCE"), this.hasSBFlag("MAT4_PER_INSTANCE") && e.addSBFlag("MAT4_PER_INSTANCE");
  for (const t of this.maps) e.addMap(t);
  return e._instanceData = this._instanceData, e.addSBFlag("OUTLINE"), e.setUniform("u_OutlineGivenInstances", !1), 
  e.setAttribute("a_OutlineInstances", Int32Attribute([ 0 ], 1, 2147483647)), e;
 }
 get color() {
  return this._color;
 }
 set color(e) {
  this._color = e, this._onChangeListener && (e = {
   uuid: this._uuid,
   changes: {
    color: this._color.getHex()
   }
  }, this._onChangeListener.materialUpdate(e));
 }
 get emissive() {
  return this._emissive;
 }
 set emissive(e) {
  this._emissive = e, this._onChangeListener && (e = {
   uuid: this._uuid,
   changes: {
    emissive: this._emissive.getHex()
   }
  }, this._onChangeListener.materialUpdate(e));
 }
 get diffuse() {
  return this._diffuse;
 }
 set diffuse(e) {
  this._diffuse = e, this._onChangeListener && (e = {
   uuid: this._uuid,
   changes: {
    diffuse: this._diffuse.getHex()
   }
  }, this._onChangeListener.materialUpdate(e));
 }
 outline_instances_setup(e) {
  this.setUniform("u_OutlineGivenInstances", !0);
  var t = this.getAttribute("a_OutlineInstances");
  t.array = new Int32Array(e), t.divisor = 1;
 }
 outline_instances_reset() {
  this.setUniform("u_OutlineGivenInstances", !1);
  var e = this.getAttribute("a_OutlineInstances");
  e.array = new Int32Array([ 0 ]), e.divisor = 2147483647;
 }
 update(e) {
  for (var t in super.update(e), e) switch (t) {
  case "color":
   this._color = e.color, delete e.color;
   break;

  case "emissive":
   this._emissive = e.emissive, delete e.emissive;
   break;

  case "diffuse":
   this._diffuse = e.diffuse, delete e.diffuse;
   break;

  case "specular":
   this._specular.setHex(e.specular), delete e.specular;
   break;

  case "shininess":
   this._shininess = e.shininess, delete e.shininess;
  }
 }
}

class ZShape extends Mesh {
 constructor(e = null, t = null) {
  null === e && (e = ZShape.makeCubeGeometry(), console.log("zshape cube geometry ", e));
  var i = (t = null === t ? new ZShapeBasicMaterial() : t).clone_for_picking(), r = t.clone_for_outline();
  super(e, t, i, r), this.type = "ZShape";
 }
 static makeCubeGeometry() {
  var e = new Geometry();
  return e.vertices = Float32Attribute([ -1, -1, 1, 1, -1, 1, 1, 1, 1, -1, 1, 1, -1, -1, -1, -1, 1, -1, 1, 1, -1, 1, -1, -1, -1, 1, -1, -1, 1, 1, 1, 1, 1, 1, 1, -1, -1, -1, -1, 1, -1, -1, 1, -1, 1, -1, -1, 1, 1, -1, -1, 1, 1, -1, 1, 1, 1, 1, -1, 1, -1, -1, -1, -1, -1, 1, -1, 1, 1, -1, 1, -1 ], 3), 
  e.indices = Uint32Attribute([ 0, 1, 2, 0, 2, 3, 4, 5, 6, 4, 6, 7, 8, 9, 10, 8, 10, 11, 12, 13, 14, 12, 14, 15, 16, 17, 18, 16, 18, 19, 20, 21, 22, 20, 22, 23 ], 1), 
  e.computeVertexNormals(), e.uv = Float32Attribute([ 0, 0, 1, 0, 1, 1, 0, 1, 1, 0, 1, 1, 0, 1, 0, 0, 0, 0, 0, 1, 1, 1, 1, 0, 0, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 0, 1, 0, 0, 0, 0, 1, 1, 1 ], 2), 
  e.type = "Cube", e;
 }
 static makeHexagonGeometry() {
  var t = new Float32Array(114), i = Math.PI / 3;
  let r = 3;
  for (let e = t[0] = t[1] = t[2] = 0; e < 6; ++e) {
   var s = e * i, a = +Math.cos(s), s = +Math.sin(s);
   t[r] = a, t[r + 1] = s, t[r + 2] = 0, r += 3;
  }
  let n = 0;
  for (let e = 0; e < 7; ++e) t[n + 21] = t[n], t[n + 22] = t[n + 1], t[n + 23] = t[n + 2] + 1, 
  n += 3;
  r = 42;
  for (let e = 0; e < 6; ++e) {
   var o = e * i, h = +Math.cos(o), u = +Math.sin(o), h = (t[r] = h, t[r + 1] = u, 
   t[r + 2] = 0, t[r + 3] = h, t[r + 4] = u, t[r + 5] = 1, +Math.cos(o + i)), u = +Math.sin(o + i);
   t[r + 6] = h, t[r + 7] = u, t[r + 8] = 1, t[r + 9] = h, t[r + 10] = u, t[r + 11] = 0, 
   r += 12;
  }
  var l = new Uint32Array(72), _ = [ 0, 1, 2, 0, 2, 3, 0, 3, 4, 0, 4, 5, 0, 5, 6, 0, 6, 1 ];
  let c = 0;
  for (let e = 0; e < _.length; e++) l[c++] = _[e];
  for (let e = 0; e < _.length; e++) l[c++] = _[e] + 7;
  var d = [ 0, 1, 2, 2, 3, 0 ];
  for (let t = 0; t < 6; ++t) for (let e = 0; e < d.length; e++) l[c++] = 14 + 4 * t + d[e];
  var e = new Geometry();
  return e.vertices = Float32Attribute(t, 3), e.indices = Uint32Attribute(l, 1), 
  e.computeVertexNormals(), e.type = "Hexagon", e;
 }
 static makeConeGeometry(e) {
  var t = new Float32Array(222), i = (t[0] = t[1] = t[2] = 0, 2 * Math.PI / 36);
  let r = 3;
  for (let e = 0; e < 36; ++e) {
   var s = e * i, a = +Math.cos(s), s = +Math.sin(s);
   t[r] = a, t[r + 1] = s, t[r + 2] = 1, r += 3;
  }
  t[r] = 0, t[r + 1] = 0, t[r + 2] = 1, r += 3;
  for (let e = 0; e < 36; ++e) {
   var n = e * i, o = +Math.cos(n), n = +Math.sin(n);
   t[r] = o, t[r + 1] = n, t[r + 2] = 1, r += 3;
  }
  let h = 108;
  e && (h *= 2);
  var u = new Uint32Array(h);
  let l = 0;
  for (let e = 0; e < 36; ++e) u[l++] = 0, u[l++] = e + 1, 107 == l ? u[l++] = 1 : u[l++] = e + 2;
  if (e) for (let e = 0; e < 36; ++e) u[l++] = 37, u[l++] = 37 + e + 1, l == h - 1 ? u[l++] = 38 : u[l++] = 37 + e + 2;
  console.log("Idx budd ", u);
  e = new Geometry();
  return e.vertices = Float32Attribute(t, 3), e.indices = Uint32Attribute(u, 1), 
  e.computeVertexNormals(), e.type = "Cone", e;
 }
}

class ShaderBuilder {
 constructor() {
  this._LOGTAG = "ShaderBuilder: ", this._templatesCache = {}, this._multiLineCommentRegex = /\/\*[^*]*(?:\*+[^*\/][^*]*)*\*\//g, 
  this._singleLineCommentRegex = /\/\/.*/g, this._lineReduceRegex = /[^\r\n]+/g, 
  this._prefixSuffixSpaceTrimRegex = /(^\s+|\s+$)/g, this._multipleSpaceMatch = /\s+/g;
 }
 _generateShaderName(e, t) {
  for (var i = e.sort(), r = Object.keys(t).sort(), s = "", a = 0; a < i.length; a++) s += i[a].toLowerCase();
  for (a = 0; a < r.length; a++) s += r[a] + t[r[a]];
  return s;
 }
 hasTemplate(e) {
  return void 0 !== this._templatesCache[e];
 }
 buildTemplateTree(e, t) {
  if (!this.hasTemplate(e)) {
   for (var i = (t = t.replace(this._multiLineCommentRegex, "")).match(this._lineReduceRegex), r = new ShaderBuilder.RootNode(), s = 0; s < i.length; s++) {
    var a = i[s].replace(this._prefixSuffixSpaceTrimRegex, "").replace(this._multipleSpaceMatch, " ").replace(this._singleLineCommentRegex, "");
    if (0 !== a.length) try {
     r.parseLine(a);
    } catch (e) {
     return console.error(this._LOGTAG + "Exception occurred while building the template tree (" + e + ")\nProblematic line: " + i[s].replace(this._prefixSuffixSpaceTrimRegex, "")), 
     !1;
    }
   }
   return r.validate() ? (this._templatesCache[e] = {
    cachedShaders: {},
    tree: r
   }, !0) : (console.error(this._LOGTAG + "Warning the commands are not properly closed!"), 
   !1);
  }
  console.log(this._LOGTAG + "Warning. Overwriting the template tree!", e);
 }
 fetchShader(e, t, i) {
  var e = this._templatesCache[e], r = this._generateShaderName(t, i);
  if (void 0 !== e) {
   var s = e.cachedShaders, a = s[r];
   if (void 0 !== a) return a;
   try {
    var n = e.tree.build(t, i);
    return s[r] = n;
   } catch (e) {
    console.error(this._LOGTAG + "Exception occurred while building the shader (" + e + ")");
   }
  } else console.log(this._LOGTAG + "Could not find the shader template!");
 }
}

ShaderBuilder.STATE_OPENED = 0, ShaderBuilder.STATE_CLOSED = 1, ShaderBuilder.commandRegex = /#for.*|#end.*|#if.*|#else.*|#fi.*/i, 
ShaderBuilder.nodeStartRegex = /#for.*|#if.*/i, ShaderBuilder.forLoopStartRegex = /#for\s+[a-zA-Z0-9_]*\s+in\s+[a-zA-Z0-9_]*\s+to\s+[a-zA-Z0-9_]*/i, 
ShaderBuilder.forLoopVariableRegex = /#for\s+([a-zA-Z0-9_]+)\s+in\s+([a-zA-Z0-9_]+)\s+to\s+([a-zA-Z0-9_]+)/i, 
ShaderBuilder.endforRegex = /^#end$/i, ShaderBuilder.prefixSuffixSpaceRegex = /(^\s+|\s+$)/g, 
ShaderBuilder.ifRegex = /#if.*/i, ShaderBuilder.elseIfRegex = /#else\s+if.*/i, ShaderBuilder.elseRegex = /^#else$/i, 
ShaderBuilder.fiRegex = /^#fi$/i, ShaderBuilder.validConditionShellRegex = /\((?:[a-zA-Z0-9!()\s_]+|&&|\|\|)+\)/i, 
ShaderBuilder.logicalOperatorsRegex = /\&\&|[|]{2}/g, ShaderBuilder.everythingButBracketsRegex = /[^()!]+/g, 
ShaderBuilder.isPosInt = /0|[1-9][0-9]*/, ShaderBuilder.Node = class {
 constructor() {
  this._state = ShaderBuilder.STATE_OPENED;
 }
 get state() {
  return this._state;
 }
 set state(e) {
  this._state = e;
 }
 parseLine(e) {}
 _createNewSubNode(e) {
  if (ShaderBuilder.commandRegex.test(e)) {
   if (ShaderBuilder.ifRegex.test(e)) {
    var t = e.substring(3).replace(ShaderBuilder.prefixSuffixSpaceRegex, "");
    if (ShaderBuilder.validConditionShellRegex.test(t)) return ShaderBuilder.ConditionNode.evaluateCondition(t, []), 
    new ShaderBuilder.ConditionNode(t);
    throw "Badly formed condition";
   }
   if (ShaderBuilder.forLoopStartRegex.test(e)) {
    t = ShaderBuilder.forLoopVariableRegex.exec(e);
    if (4 != t.length) throw "Badly formed command";
    return new ShaderBuilder.LoopNode(t[1], t[2], t[3]);
   }
   throw "Badly formed command";
  }
  return new ShaderBuilder.CodeNode(e);
 }
 build(e, t) {
  return "";
 }
 validate() {
  return !1;
 }
}, ShaderBuilder.RootNode = class extends ShaderBuilder.Node {
 constructor() {
  super(), this._subNodes = [];
 }
 parseLine(e) {
  if (0 < this._subNodes.length) {
   var t = this._subNodes[this._subNodes.length - 1];
   if (t instanceof ShaderBuilder.CodeNode) if (ShaderBuilder.commandRegex.test(e)) {
    if (!ShaderBuilder.nodeStartRegex.test(e)) throw "Unexpected Command";
    this._subNodes.push(this._createNewSubNode(e));
   } else t.parseLine(e); else t.state === ShaderBuilder.STATE_OPENED ? t.parseLine(e) : this._subNodes.push(this._createNewSubNode(e));
  } else this._subNodes.push(this._createNewSubNode(e));
 }
 build(e, t) {
  for (var i, r, s = "", a = 0; a < this._subNodes.length; a++) s += this._subNodes[a].build(e, t);
  for (i in "\n" === s.substring(s.length - 1) && (s = s.slice(0, -1)), t) t.hasOwnProperty(i) && (r = new RegExp("##" + i, "g"), 
  s = s.replace(r, t[i]));
  return s;
 }
 validate() {
  for (var e = 0; e < this._subNodes.length; e++) if (!this._subNodes[e].validate()) return !1;
  return !0;
 }
}, ShaderBuilder.CodeNode = class extends ShaderBuilder.Node {
 constructor(e) {
  super(), this._code = e + "\n", this._state = ShaderBuilder.STATE_CLOSED;
 }
 parseLine(e) {
  this._code += e + "\n";
 }
 build(e, t) {
  return this._code;
 }
 validate() {
  return !0;
 }
}, ShaderBuilder.ConditionNode = class extends ShaderBuilder.Node {
 constructor(e) {
  super(), this._if_condition = e, this._if_subNodes = [], this._elseif_conditions = [], 
  this._elseif_subNodesList = [], this._else_subNodes = null;
 }
 static evaluateCondition(condition, flags) {
  if (condition = condition.replace(/\s/g, ""), 0 < flags.length) {
   for (var trueFlagsStr = "", falseFlagsStr = "", i = 0; i < flags.length; i++) trueFlagsStr += flags[i], 
   falseFlagsStr += "!" + flags[i], i !== flags.length - 1 && (trueFlagsStr += "|", 
   falseFlagsStr += "|");
   condition = condition.replace(new RegExp(falseFlagsStr, "gi"), "false"), condition = condition.replace(new RegExp(trueFlagsStr, "gi"), "true");
  }
  var condValues = condition.split(ShaderBuilder.logicalOperatorsRegex), condOperators = condition.match(ShaderBuilder.logicalOperatorsRegex);
  if (null == condOperators && (condOperators = []), 0 === condValues.length || condOperators.length !== condValues.length - 1) throw "BadlyFormedCondition";
  for (var i = 0; i < condValues.length; i++) {
   var value = condValues[i].match(ShaderBuilder.everythingButBracketsRegex)[0].replace(ShaderBuilder.prefixSuffixSpaceRegex, "");
   "true" !== value && (condValues[i] = condValues[i].replace(ShaderBuilder.everythingButBracketsRegex, "false"));
  }
  condition = condValues[0];
  for (var i = 0; i < condOperators.length; i++) condition += condOperators[i] + condValues[i + 1];
  try {
   return eval(condition);
  } catch (e) {
   throw "BadlyFormedCondition";
  }
 }
 _fetchSubNodes() {
  return null !== this._else_subNodes ? this._else_subNodes : 0 !== this._elseif_conditions.length ? this._elseif_subNodesList[this._elseif_subNodesList.length - 1] : this._if_subNodes;
 }
 parseLine(e) {
  var t = this._fetchSubNodes();
  if (0 < t.length) {
   var i = t[t.length - 1];
   if (i.state === ShaderBuilder.STATE_OPENED) i.parseLine(e); else if (ShaderBuilder.commandRegex.test(e)) if (ShaderBuilder.nodeStartRegex.test(e)) t.push(this._createNewSubNode(e)); else if (ShaderBuilder.elseIfRegex.test(e)) {
    if (null !== this._else_subNodes) throw "UnexpectedElseIfCondition";
    var r = e.substring(8).replace(ShaderBuilder.prefixSuffixSpaceRegex, "");
    if (!ShaderBuilder.validConditionShellRegex.test(r)) throw "BadlyFormedCondition";
    ShaderBuilder.ConditionNode.evaluateCondition(r, []), this._elseif_conditions.push(r), 
    this._elseif_subNodesList.push([]);
   } else if (ShaderBuilder.elseRegex.test(e)) this._else_subNodes = []; else {
    if (!ShaderBuilder.fiRegex.test(e) || i._state !== ShaderBuilder.STATE_CLOSED) throw "UnexpectedBlockClosure";
    this._state = ShaderBuilder.STATE_CLOSED;
   } else i instanceof ShaderBuilder.CodeNode ? i.parseLine(e) : t.push(this._createNewSubNode(e));
  } else ShaderBuilder.fiRegex.test(e) ? this._state = ShaderBuilder.STATE_CLOSED : t.push(this._createNewSubNode(e));
 }
 build(e, t) {
  var i = null, r = "";
  if (ShaderBuilder.ConditionNode.evaluateCondition(this._if_condition, e)) i = this._if_subNodes; else {
   for (var s = 0; s < this._elseif_conditions.length; s++) if (ShaderBuilder.ConditionNode.evaluateCondition(this._elseif_conditions[s], e)) {
    i = this._elseif_subNodesList[s];
    break;
   }
   if (null === (i = null === i && null !== this._else_subNodes ? this._else_subNodes : i)) return "";
  }
  for (s = 0; s < i.length; s++) r += i[s].build(e, t);
  return r;
 }
 validate() {
  if (this._state !== ShaderBuilder.STATE_CLOSED) return !1;
  for (var e = 0; e < this._if_subNodes.length; e++) if (!this._if_subNodes[e].validate()) return !1;
  for (e = 0; e < this._elseif_subNodesList.length; e++) for (var t = this._elseif_subNodesList[e], i = 0; i < t.length; i++) if (!t[i].validate()) return !1;
  if (null !== this._else_subNodes) for (e = 0; e < this._else_subNodes.length; e++) if (!this._else_subNodes[e].validate()) return !1;
  return !0;
 }
}, ShaderBuilder.LoopNode = class extends ShaderBuilder.Node {
 constructor(e, t, i) {
  super(), this._macro = e, this._from = t, this._to = i, this._subNodes = [];
 }
 parseLine(e) {
  if (0 < this._subNodes.length) {
   var t = this._subNodes[this._subNodes.length - 1];
   if (t instanceof ShaderBuilder.CodeNode) if (ShaderBuilder.commandRegex.test(e)) if (ShaderBuilder.nodeStartRegex.test(e)) this._subNodes.push(this._createNewSubNode(e)); else {
    if (!ShaderBuilder.endforRegex.test(e)) throw "Unexpected Command";
    this._state = ShaderBuilder.STATE_CLOSED;
   } else t.parseLine(e); else t.state === ShaderBuilder.STATE_OPENED ? t.parseLine(e) : ShaderBuilder.endforRegex.test(e) ? this._state = ShaderBuilder.STATE_CLOSED : this._subNodes.push(this._createNewSubNode(e));
  } else ShaderBuilder.endforRegex.test(e) ? this._state = ShaderBuilder.STATE_CLOSED : this._subNodes.push(this._createNewSubNode(e));
 }
 build(e, t) {
  var i, r;
  if (ShaderBuilder.isPosInt.test(this._from)) i = parseInt(this._from, 10); else {
   if (void 0 === t[this._from]) throw "For loop parameter [" + this._from + "] not specified.";
   i = t[this._from];
  }
  if (ShaderBuilder.isPosInt.test(this._to)) r = parseInt(this._to, 10); else {
   if (void 0 === t[this._to]) throw "For loop parameter [" + this._to + "] not specified.";
   r = t[this._to];
  }
  if (!Number.isInteger(i) || !Number.isInteger(r) || i < 0 || r < 0) throw "Invalid for loop parameters.";
  for (var s = "", a = 0; a < this._subNodes.length; a++) s += this._subNodes[a].build(e, t);
  var n = "", o = new RegExp("##" + this._macro, "g");
  if (i < r) for (a = i; a < r; a++) n += s.replace(o, a); else for (a = i; r < a; a--) n += s.replace(o, a);
  return n;
 }
 validate() {
  if (this._state !== ShaderBuilder.STATE_CLOSED) return !1;
  for (var e = 0; e < this._subNodes.length; e++) if (!this._subNodes[e].validate()) return !1;
  return !0;
 }
};

class GLProgram {
 constructor(e) {
  this._gl = e, this._program = this._gl.createProgram(), this._initialized = !1, 
  this._attributeSetter = null, this._uniformSetter = null;
 }
 attachShader(e) {
  this._gl.attachShader(this._program, e);
 }
 get glProgram() {
  return this._program;
 }
 get initialized() {
  return this._initialized;
 }
 get attributeSetter() {
  return this._attributeSetter;
 }
 get uniformSetter() {
  return this._uniformSetter;
 }
 set initialized(e) {
  this._initialized = e;
 }
 set uniformSetter(e) {
  this._uniformSetter = e;
 }
 set attributeSetter(e) {
  this._attributeSetter = e;
 }
 use() {
  this._gl.useProgram(this._program);
 }
}

class GLProgramManager {
 constructor(e) {
  this._glManager = e, this._gl = e.context, this._shaderBuilder = new ShaderBuilder(), 
  this._compiledPrograms = {};
 }
 isTemplateDownloaded(e) {
  return this._shaderBuilder.hasTemplate(e + VERTEX_SHADER) && this._shaderBuilder.hasTemplate(e + FRAGMENT_SHADER);
 }
 addTemplate(e) {
  var t = e.id, i = e.sources, r = Object.keys(i);
  for (let e = 0; e < r.length; e++) this._shaderBuilder.buildTemplateTree(t + r[e], i[r[e]]);
 }
 fetchProgram(e, t, i, r) {
  var s = e.programID + "NUM_DLIGHTS" + t + "NUM_PLIGHTS" + i + "NUM_SLIGHTS" + r, a = this._compiledPrograms[s];
  if (void 0 !== a) return a;
  a = new GLProgram(this._gl), e.values.NUM_DLIGHTS = t, e.values.NUM_PLIGHTS = i, 
  e.values.NUM_SLIGHTS = r, t + i === 0 && e.flags.push("NO_LIGHTS"), 0 < t && e.flags.push("DLIGHTS"), 
  0 < i && e.flags.push("PLIGHTS"), 0 < r && e.flags.push("SLIGHTS");
  var n, t = this._shaderBuilder.fetchShader(e.name + VERTEX_SHADER, e.flags, e.values), i = this._shaderBuilder.fetchShader(e.name + FRAGMENT_SHADER, e.flags, e.values);
  if (void 0 !== t && void 0 !== i) return r = this._compileShader(t, this._gl.VERTEX_SHADER), 
  e = this._compileShader(i, this._gl.FRAGMENT_SHADER), a.attachShader(r), a.attachShader(e), 
  this._gl.linkProgram(a.glProgram), this._gl.getProgramParameter(a.glProgram, this._gl.LINK_STATUS) || (n = this._gl.getProgramInfoLog(a.glProgram), 
  console.error("Could not compile WebGL program. \n\n" + n), console.log("VERTEX SHADER:\n" + t + "\n\n\n"), 
  console.log("FRAGMENT SHADER:\n" + i)), this._gl.deleteShader(r), this._gl.deleteShader(e), 
  a.attributeSetter = this._initAttributeSetter(a.glProgram), a.uniformSetter = this._initUniformSetter(a.glProgram), 
  a.initialized = !0, this._compiledPrograms[s] = a;
  console.error("FAILED TO BUILD SHADER PROGRAM!");
 }
 _initAttributeSetter(e) {
  for (var t = {}, h = this, i = this._gl.getProgramParameter(e, this._gl.ACTIVE_ATTRIBUTES), r = 0; r < i; r++) {
   var s = this._gl.getActiveAttrib(e, r);
   const u = h._gl.getAttribLocation(e, s.name);
   var a = this._gl, n = s.type;
   let o;
   o = n == a.INT || n == a.INT_VEC2 || n == a.INT_VEC3 || n == a.GL_INT_VEC4 ? a.INT : (a.UNSIGNED_INT, 
   n == a.UNSIGNED_INT_VEC2 || n == a.UNSIGNED_INT_VEC3 || n == a.UNSIGNED_INT_VEC4 ? a.UNSIGNED_INT : a.FLOAT), 
   t[s.name] = {}, t[s.name].set = function(t, i, r = !1, s = 0, a = 0, n = !1) {
    var e = h._glManager.getGLBuffer(t);
    if (0 == a && (a = o), i <= 4) t.locations.push(u), h._gl.enableVertexAttribArray(u), 
    h._gl.bindBuffer(h._gl.ARRAY_BUFFER, e), o == h._gl.FLOAT ? h._gl.vertexAttribPointer(u, i, a, n, 0, 0) : h._gl.vertexAttribIPointer(u, i, a, 0, 0), 
    r ? h._gl.vertexAttribDivisor(u, s) : h._gl.vertexAttribDivisor(u, 0); else {
     h._gl.bindBuffer(h._gl.ARRAY_BUFFER, e);
     for (let e = 0; e < i / 4; e++) t.locations.push(u + e), h._gl.enableVertexAttribArray(u + e), 
     o == h._gl.FLOAT ? h._gl.vertexAttribPointer(u + e, 4, a, n, 64, 16 * e) : h._gl.vertexAttribIPointer(u + e, 4, a, 64, 16 * e), 
     r ? h._gl.vertexAttribDivisor(u + e, s) : h._gl.vertexAttribDivisor(u + e, 0);
    }
   }, t[s.name].free = function() {
    h._gl.disableVertexAttribArray(u);
   };
  }
  return t;
 }
 _initUniformSetter(t) {
  var i = {}, r = this, s = this._gl.getProgramParameter(t, this._gl.ACTIVE_UNIFORMS);
  i.__validation = {
   uniforms: {},
   reset() {
    for (var e in this.uniforms) this.uniforms.hasOwnProperty(e) && (this.uniforms[e] = !1);
   },
   validate() {
    var e, t = [];
    for (e in this.uniforms) this.uniforms.hasOwnProperty(e) && !this.uniforms[e] && t.push(e);
    return t;
   }
  };
  for (let e = 0; e < s; e++) {
   const a = r._gl.getActiveUniform(t, e), n = r._gl.getUniformLocation(t, a.name);
   if (n) switch (i[a.name] = {}, i.__validation.uniforms[a.name] = !1, a.type) {
   case r._gl.FLOAT:
    1 < a.size ? i[a.name].set = function(e) {
     r._gl.uniform1fv(n, e), i.__validation.uniforms[a.name] = !0;
    } : i[a.name].set = function(e) {
     r._gl.uniform1f(n, e), i.__validation.uniforms[a.name] = !0;
    };
    break;

   case r._gl.FLOAT_VEC2:
    1 < a.size ? i[a.name].set = function(e) {
     r._gl.uniform2fv(n, e), i.__validation.uniforms[a.name] = !0;
    } : i[a.name].set = function(e) {
     r._gl.uniform2f(n, e[0], e[1]), i.__validation.uniforms[a.name] = !0;
    };
    break;

   case r._gl.FLOAT_VEC3:
    1 < a.size ? i[a.name].set = function(e) {
     r._gl.uniform3fv(n, e), i.__validation.uniforms[a.name] = !0;
    } : i[a.name].set = function(e) {
     r._gl.uniform3f(n, e[0], e[1], e[2]), i.__validation.uniforms[a.name] = !0;
    };
    break;

   case r._gl.FLOAT_VEC4:
    1 < a.size ? i[a.name].set = function(e) {
     r._gl.uniform4fv(n, e), i.__validation.uniforms[a.name] = !0;
    } : i[a.name].set = function(e) {
     r._gl.uniform4f(n, e[0], e[1], e[2], e[3]), i.__validation.uniforms[a.name] = !0;
    };
    break;

   case r._gl.FLOAT_MAT3:
    i[a.name].set = function(e) {
     r._gl.uniformMatrix3fv(n, !1, e), i.__validation.uniforms[a.name] = !0;
    };
    break;

   case r._gl.FLOAT_MAT4:
    i[a.name].set = function(e) {
     r._gl.uniformMatrix4fv(n, !1, e), i.__validation.uniforms[a.name] = !0;
    };
    break;

   case r._gl.INT:
    1 < a.size ? i[a.name].set = function(e) {
     r._gl.uniform1iv(n, e), i.__validation.uniforms[a.name] = !0;
    } : i[a.name].set = function(e) {
     r._gl.uniform1i(n, e), i.__validation.uniforms[a.name] = !0;
    };
    break;

   case r._gl.UNSIGNED_INT:
    1 < a.size ? i[a.name].set = function(e) {
     r._gl.uniform1uiv(n, e), i.__validation.uniforms[a.name] = !0;
    } : i[a.name].set = function(e) {
     r._gl.uniform1ui(n, e), i.__validation.uniforms[a.name] = !0;
    };
    break;

   case r._gl.INT_VEC2:
    1 < a.size ? i[a.name].set = function(e) {
     r._gl.uniform2iv(n, e), i.__validation.uniforms[a.name] = !0;
    } : i[a.name].set = function(e) {
     r._gl.uniform2i(n, e[0], e[1]), i.__validation.uniforms[a.name] = !0;
    };
    break;

   case r._gl.INT_VEC3:
    1 < a.size ? i[a.name].set = function(e) {
     r._gl.uniform3iv(n, e), i.__validation.uniforms[a.name] = !0;
    } : i[a.name].set = function(e) {
     r._gl.uniform3i(n, e[0], e[1], e[2]), i.__validation.uniforms[a.name] = !0;
    };
    break;

   case r._gl.INT_VEC4:
    1 < a.size ? i[a.name].set = function(e) {
     r._gl.uniform4iv(n, e), i.__validation.uniforms[a.name] = !0;
    } : i[a.name].set = function(e) {
     r._gl.uniform4i(n, e[0], e[1], e[2], e[3]), i.__validation.uniforms[a.name] = !0;
    };
    break;

   case r._gl.BOOL:
    i[a.name].set = function(e) {
     r._gl.uniform1f(n, e), i.__validation.uniforms[a.name] = !0;
    };
    break;

   case r._gl.SAMPLER_2D:
   case r._gl.INT_SAMPLER_2D:
   case r._gl.UNSIGNED_INT_SAMPLER_2D:
    i[a.name].set = function(e, t) {
     r._gl.activeTexture(r._gl.TEXTURE0 + t), r._gl.bindTexture(r._gl.TEXTURE_2D, e), 
     r._gl.uniform1i(n, t), i.__validation.uniforms[a.name] = !0;
    };
    break;

   case r._gl.SAMPLER_CUBE:
    i[a.name].set = function(e, t) {
     r._gl.activeTexture(r._gl.TEXTURE0 + t), r._gl.bindTexture(r._gl.TEXTURE_CUBE_MAP, e), 
     r._gl.uniform1i(n, t), i.__validation.uniforms[a.name] = !0;
    };
    break;

   default:
    console.error("UNKNOWN");
   }
  }
  return i;
 }
 _compileShader(e, t) {
  var i = this._gl.createShader(t);
  return this._gl.shaderSource(i, e), this._gl.compileShader(i), this._gl.getShaderParameter(i, this._gl.COMPILE_STATUS) || console.error(this._gl.getShaderInfoLog(i)), 
  "" !== this._gl.getShaderInfoLog(i) && console.warn("WebGLShader: _gl.getShaderInfoLog()", t === this._gl.VERTEX_SHADER ? "vertex" : "fragment", this._gl.getShaderInfoLog(i)), 
  i;
 }
 _getCachedProgram(e) {
  var t = this._compiledPrograms[e];
  return void 0 === t && (t = new GLProgram(this._gl), this._compiledPrograms[e] = t), 
  t;
 }
}

class Renderer {
 constructor(e, t, i) {
  this._glManager = new GLManager(e, t, i), this._canvas = e, this._gl = this._glManager.context, 
  this._glProgramManager = new GLProgramManager(this._glManager), this._shaderLoader = new ShaderLoader(), 
  this._requiredPrograms = new Map(), this._loadingPrograms = new Map(), this._compiledPrograms = new Map(), 
  this._currentRenderTarget = null, this._autoClear = !0, this._selectedRenderer = null, 
  this._uuid = _Math.generateUUID(), this._materialIDMap = new Map(), this._materialID = 0, 
  this._takeScreenshot = !1, this._screenshotInProgress = !1, this._segmentedScreenshot = !1, 
  this._screenshotSizeMultiplier = 1, this._renderQueue = void 0, this._screenshotTextureReference = void 0, 
  this._screenshotData = new Uint8ClampedArray(), this._viewport = {
   xOffset: 0,
   yOffset: 0,
   width: this._canvas.width,
   height: this._canvas.height
  }, this._logLevel = 2;
 }
 render(e, t, i, r = !1, s = 0) {
  t instanceof Camera == !1 ? console.error(LOGTAG + "Given camera is not an instance of Camera") : (null === t.parent && t.updateMatrixWorld(), 
  t.matrixWorldInverse.getInverse(t.matrixWorld), void 0 !== i && this._initRenderTarget(i, r, s), 
  this._glManager.autoClear && this._glManager.clear(!0, !0, !0), this._selectedRenderer(e, t), 
  this._takeScreenshot && (this._takeScreenshot = !1, this._screenshotInProgress = !0, 
  console.log("Taking screenshot..."), r = this._segmentedScreenshot ? this._takeSegmentedScreenshot(e, t, i, this._renderQueue, this._screenshotTextureReference) : this._takeFullScreenshot(this._screenshotTextureReference), 
  this._glManager.openImageInNewTab(r), this._screenshotInProgress = !1), this._currentRenderTarget && (this._cleanupRenderTarget(), 
  this._currentRenderTarget = null));
 }
 _takeFullScreenshot(e = void 0) {
  var t = (e || this.getViewport()).width, i = (e || this.getViewport()).height, r = (this._screenshotData.length !== t * i * 4 && (this._screenshotData = new Uint8ClampedArray(t * i * 4)), 
  e && (r = this._gl.createFramebuffer(), this._gl.bindFramebuffer(this._gl.FRAMEBUFFER, r), 
  r = this._glManager._textureManager.getGLTexture(e), this._gl.framebufferTexture2D(this._gl.FRAMEBUFFER, this._gl.COLOR_ATTACHMENT0, this._gl.TEXTURE_2D, r, 0)), 
  this._gl.readPixels(0, 0, t, i, this._gl.RGBA, this._gl.UNSIGNED_BYTE, this._screenshotData), 
  e && this._gl.bindFramebuffer(this._gl.FRAMEBUFFER, null), this._glManager.flipImage(this._screenshotData, t, i), 
  new ImageData(this._screenshotData, t, i));
  return r;
 }
 _takeSegmentedScreenshot(t, r, s, a = void 0, n = void 0) {
  var o = (n || this.getViewport()).width, h = (n || this.getViewport()).height, u = r.left, l = r.right, i = r.top, _ = r.bottom, c = this._screenshotSizeMultiplier, e = this._screenshotSizeMultiplier, d = (-u + l) / c, m = (i - _) / e, g = new Uint8ClampedArray(o * c * 4 * h * e);
  let p = 0;
  for (let e = i; e > _; e -= m) {
   r.top = e, r.bottom = e - m;
   let i = 0;
   for (let e = u; e < l; e += d) {
    r.left = e, r.right = e + d, a ? a.render() : this.render(t, r, s), console.log("Taking screenshot block...");
    var f = this._takeFullScreenshot(n);
    for (let t = 0; t < h; t++) for (let e = 0; e < 4 * o; e++) g[p * o * c * h * 4 + t * o * c * 4 + i * o * 4 + e] = f.data[t * o * 4 + e];
    i++;
   }
   p++;
  }
  return r.left = u, r.right = l, r.top = i, r.bottom = _, a ? a.render() : this.render(t, r, s), 
  new ImageData(g, o * c, h * e);
 }
 _downloadProgram(t) {
  let i = this;
  const r = t.name;
  this._loadingPrograms.has(t.name) || (2 <= this._logLevel && console.log("(Down)loading: " + t.programID + ": " + r + "."), 
  this._loadingPrograms.set(t.name, t), this._shaderLoader.loadProgramSources(r, function(e) {
   2 <= i._logLevel && console.log("(Down)loaded: " + t.programID + ": " + r + "."), 
   i._glProgramManager.addTemplate(e), i._loadingPrograms.delete(t.name);
  }, void 0, function(e) {
   console.error("Failed to load program: " + t.programID + ": " + r + "."), i._loadingPrograms.delete(t.name);
  }));
 }
 downloadTexture(e, t) {
  return this._glManager.downloadTexture(e, t);
 }
 _loadRequiredPrograms() {
  let e = !0;
  for (var [ t, i ] of this._requiredPrograms) this._glProgramManager.isTemplateDownloaded(i.name) ? (this._compileProgram(i), 
  this._requiredPrograms.delete(t)) : (e = !1, this._downloadProgram(i));
  return e;
 }
 _compileProgram(e) {
  let t = 0, i = 0, r = 0;
  this._lightsCombined && (t = this._lightsCombined.directional.length, i = this._lightsCombined.point.length, 
  r = this._lightsCombined.spot.length);
  var s = this._glProgramManager.fetchProgram(e, t, i, r);
  this._compiledPrograms.set(e.programID, s);
 }
 preDownloadPrograms(t) {
  for (let e = 0; e < t.length; e++) this._glProgramManager.isTemplateDownloaded(t[e]) || this._downloadProgram(t[e]);
 }
 _initRenderTarget(e, t, i) {
  var r = (this._currentRenderTarget = e)._viewport;
  this.updateViewport(r.z, r.w, r.x, r.y), t ? this._glManager.initRenderTargetCube(e, i) : this._glManager.initRenderTarget(e);
 }
 _cleanupRenderTarget() {
  this._currentRenderTarget = null, this.updateViewport(this._canvas.width, this._canvas.height), 
  this._glManager.cleanupRenderTarget();
 }
 dispose() {
  this._glManager.deleteAttributeBuffers(), this._glManager.deleteFrameBuffers(), 
  this._glManager.deleteTextures();
 }
 addShaderLoaderUrls(...e) {
  this._shaderLoader.addUrls(e);
 }
 set autoClear(e) {
  this._autoClear = e;
 }
 get autoClear() {
  return this._autoClear;
 }
 get clearColor() {
  return this._glManager.clearColor;
 }
 set clearColor(e) {
  e = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(e);
  e && this._glManager.setClearColor(parseInt(e[1], 16) / 255, parseInt(e[2], 16) / 255, parseInt(e[3], 16) / 255, parseInt(e[4], 16) / 255);
 }
 updateViewport(e, t, i = 0, r = 0) {
  this._viewport = {
   xOffset: i,
   yOffset: r,
   width: e,
   height: t
  }, this._gl.viewport(i, r, e, t);
 }
 getViewport() {
  return this._viewport;
 }
 get glManager() {
  return this._glManager;
 }
 get gl() {
  return this._glManager.gl;
 }
 get glContextAttributes() {
  return this._glManager.contextAttributes;
 }
 generateMaterialID(e = void 0) {
  var t;
  return void 0 !== e ? this._materialIDMap.has(e) ? this._materialIDMap.get(e) : (t = this._materialID, 
  this._materialIDMap.set(e, t), this._materialID++, t) : this._materialID++;
 }
 takeScreenshot(e = void 0, t = 1, i = !1, r = void 0) {
  this._takeScreenshot = !0, this._segmentedScreenshot = i, this._screenshotSizeMultiplier = t, 
  this._renderQueue = r, this._screenshotTextureReference = e;
 }
 pickRGB(e = void 0, t, i, r) {
  (e || this.getViewport()).width;
  var s, a = (e || this.getViewport()).height, n = new Uint8Array(4);
  return e && (s = this._gl.createFramebuffer(), this._gl.bindFramebuffer(this._gl.FRAMEBUFFER, s), 
  s = this._glManager._textureManager.getGLTexture(e), this._gl.framebufferTexture2D(this._gl.FRAMEBUFFER, this._gl.COLOR_ATTACHMENT0, this._gl.TEXTURE_2D, s, 0)), 
  this._gl.readPixels(t, a - i, 1, 1, this._gl.RGBA, this._gl.UNSIGNED_BYTE, n), 
  e && this._gl.bindFramebuffer(this._gl.FRAMEBUFFER, null), n;
 }
 pickUINT(e = void 0, t, i, r) {
  (e || this.getViewport()).width;
  var s, a = (e || this.getViewport()).height, n = new Uint32Array(4);
  return e && (s = this._gl.createFramebuffer(), this._gl.bindFramebuffer(this._gl.FRAMEBUFFER, s), 
  s = this._glManager._textureManager.getGLTexture(e), this._gl.framebufferTexture2D(this._gl.FRAMEBUFFER, this._gl.COLOR_ATTACHMENT0, this._gl.TEXTURE_2D, s, 0)), 
  this._gl.readPixels(t, a - i, 1, 1, this._gl.RGBA_INTEGER, this._gl.UNSIGNED_INT, n), 
  e && this._gl.bindFramebuffer(this._gl.FRAMEBUFFER, null), n;
 }
}

class RenderTarget {
 constructor(e, t) {
  this._uuid = _Math.generateUUID(), this.type = "RenderTarget", this._width = void 0 !== e ? e : 800, 
  this._height = void 0 !== t ? t : 600, this._viewport = new Vector4(0, 0, e, t), 
  this._drawBuffers = [], this._depthTexture = null;
 }
 get width() {
  return this._width;
 }
 get height() {
  return this._height;
 }
 get depthTexture() {
  return this._depthTexture;
 }
 set width(e) {
  this._width = e, this._viewport = new Vector4(0, 0, this._width, this._height);
 }
 set height(e) {
  this._height = e, this._viewport = new Vector4(0, 0, this._width, this._height);
 }
 set depthTexture(e) {
  this._depthTexture = e;
 }
 addDepthTexture(e = !1) {
  this._depthTexture = e ? new CubeTexture({
   textures: void 0,
   wrapS: Texture.WRAPPING.ClampToEdgeWrapping,
   wrapT: Texture.WRAPPING.ClampToEdgeWrapping,
   wrapR: Texture.WRAPPING.ClampToEdgeWrapping,
   minFilter: Texture.FILTER.NearestFilter,
   magFilter: Texture.FILTER.NearestFilter,
   internalFormat: Texture.FORMAT.DEPTH_COMPONENT32F,
   format: Texture.FORMAT.DEPTH_COMPONENT,
   type: Texture.TYPE.FLOAT,
   size: Math.min(this._width, this._height)
  }) : new Texture(void 0, Texture.WRAPPING.ClampToEdgeWrapping, Texture.WRAPPING.ClampToEdgeWrapping, Texture.FILTER.NearestFilter, Texture.FILTER.NearestFilter, Texture.FORMAT.DEPTH_COMPONENT32F, Texture.FORMAT.DEPTH_COMPONENT, Texture.TYPE.FLOAT, this._width, this._height);
 }
 rmDepthTexture() {
  this._depthTexture = null;
 }
 addDrawBuffer(e) {
  this._drawBuffers.push(e);
 }
 rmDrawBuffer(e) {
  return this._drawBuffers.splice(e, 1);
 }
 getDrawBuffer(e) {
  return this._drawBuffers[e];
 }
 sizeDrawBuffers() {
  return this._drawBuffers.length;
 }
 clearDrawBuffers() {
  this._drawBuffers = [];
 }
}

class RenderPass {
 constructor(e, t, i, r, s, a, n = null, o = [], h = 0) {
  this._type = e, this._isInitialized = !1, this._initialize = t, this._preprocess = i, 
  this._postprocess = r, this._target = s, this._viewport = a, this._outDepthID = n, 
  this._outTextures = o, this._side = h;
 }
 get type() {
  return this._type;
 }
 get initialize() {
  return this._initialize;
 }
 get preprocess() {
  return this._preprocess;
 }
 get postprocess() {
  return this._postprocess;
 }
 get target() {
  return this._target;
 }
 get viewport() {
  return this._viewport;
 }
 get outDepthID() {
  return this._outDepthID;
 }
 get outTextures() {
  return this._outTextures;
 }
 get side() {
  return this._side;
 }
 set type(e) {
  this._type = e;
 }
 set initialize(e) {
  this._initialize = e;
 }
 set preprocess(e) {
  this._preprocess = e;
 }
 set postprocess(e) {
  this._postprocess = e;
 }
 set target(e) {
  this._target = e;
 }
 set viewport(e) {
  this._viewport = e;
 }
 set outDepthID(e) {
  this._type === RenderPass.SCREEN && console.warn("Warning: Setting output depth texture to RenderPass that renders to screen!"), 
  this._outDepthID = e;
 }
 set outTextures(e) {
  this._type === RenderPass.SCREEN && console.warn("Warning: Setting output color textures to RenderPass that renders to screen!"), 
  this._outTextures = e;
 }
 set side(e) {
  this._side = e;
 }
}

RenderPass.BASIC = 0, RenderPass.TEXTURE_MERGE = 1, RenderPass.POSTPROCESS = 2, 
RenderPass.TEXTURE = 3, RenderPass.TEXTURE_CUBE_MAP = 3.2, RenderPass.SCREEN = 4, 
RenderPass.DEFAULT_R8_TEXTURE_CONFIG = {
 wrapS: Texture.WRAPPING.ClampToEdgeWrapping,
 wrapT: Texture.WRAPPING.ClampToEdgeWrapping,
 minFilter: Texture.FILTER.LinearFilter,
 magFilter: Texture.FILTER.LinearFilter,
 internalFormat: Texture.FORMAT.R8,
 format: Texture.FORMAT.RED,
 type: Texture.TYPE.UNSIGNED_BYTE,
 clearFunction: 3
}, RenderPass.DEFAULT_R32I_TEXTURE_CONFIG = {
 wrapS: Texture.WRAPPING.ClampToEdgeWrapping,
 wrapT: Texture.WRAPPING.ClampToEdgeWrapping,
 minFilter: Texture.FILTER.LinearFilter,
 magFilter: Texture.FILTER.LinearFilter,
 internalFormat: Texture.FORMAT.R32I,
 format: Texture.FORMAT.RED_INTEGER,
 type: Texture.TYPE.INT,
 clearFunction: 2
}, RenderPass.DEFAULT_R32UI_TEXTURE_CONFIG = {
 wrapS: Texture.WRAPPING.ClampToEdgeWrapping,
 wrapT: Texture.WRAPPING.ClampToEdgeWrapping,
 minFilter: Texture.FILTER.LinearFilter,
 magFilter: Texture.FILTER.LinearFilter,
 internalFormat: Texture.FORMAT.R32UI,
 format: Texture.FORMAT.RED_INTEGER,
 type: Texture.TYPE.UNSIGNED_INT,
 clearFunction: 1
}, RenderPass.DEFAULT_RGB_TEXTURE_CONFIG = {
 wrapS: Texture.WRAPPING.ClampToEdgeWrapping,
 wrapT: Texture.WRAPPING.ClampToEdgeWrapping,
 minFilter: Texture.FILTER.LinearFilter,
 magFilter: Texture.FILTER.LinearFilter,
 internalFormat: Texture.FORMAT.RGB,
 format: Texture.FORMAT.RGB,
 type: Texture.TYPE.UNSIGNED_BYTE,
 clearFunction: 3
}, RenderPass.DEFAULT_RGBA_TEXTURE_CONFIG = {
 wrapS: Texture.WRAPPING.ClampToEdgeWrapping,
 wrapT: Texture.WRAPPING.ClampToEdgeWrapping,
 minFilter: Texture.FILTER.LinearFilter,
 magFilter: Texture.FILTER.LinearFilter,
 internalFormat: Texture.FORMAT.RGBA,
 format: Texture.FORMAT.RGBA,
 type: Texture.TYPE.UNSIGNED_BYTE,
 clearFunction: 3
}, RenderPass.DEFAULT_RGBA_NEAREST_TEXTURE_CONFIG = {
 wrapS: Texture.WRAPPING.ClampToEdgeWrapping,
 wrapT: Texture.WRAPPING.ClampToEdgeWrapping,
 minFilter: Texture.FILTER.NearestFilter,
 magFilter: Texture.FILTER.NearestFilter,
 internalFormat: Texture.FORMAT.RGBA,
 format: Texture.FORMAT.RGBA,
 type: Texture.TYPE.UNSIGNED_BYTE,
 clearFunction: 3
}, RenderPass.DEFAULT_R16F_TEXTURE_CONFIG = {
 wrapS: Texture.WRAPPING.ClampToEdgeWrapping,
 wrapT: Texture.WRAPPING.ClampToEdgeWrapping,
 minFilter: Texture.FILTER.LinearFilter,
 magFilter: Texture.FILTER.LinearFilter,
 internalFormat: Texture.FORMAT.R16F,
 format: Texture.FORMAT.RED,
 type: Texture.TYPE.HALF_FLOAT,
 clearFunction: 3
}, RenderPass.NEAREST_R16F_TEXTURE_CONFIG = {
 wrapS: Texture.WRAPPING.ClampToEdgeWrapping,
 wrapT: Texture.WRAPPING.ClampToEdgeWrapping,
 minFilter: Texture.FILTER.NearestFilter,
 magFilter: Texture.FILTER.NearestFilter,
 internalFormat: Texture.FORMAT.R16F,
 format: Texture.FORMAT.RED,
 type: Texture.TYPE.HALF_FLOAT,
 clearFunction: 3
}, RenderPass.DEFAULT_R16F_TEXTURE_CUBE_MAP_CONFIG = {
 wrapS: Texture.WRAPPING.ClampToEdgeWrapping,
 wrapT: Texture.WRAPPING.ClampToEdgeWrapping,
 wrapR: Texture.WRAPPING.ClampToEdgeWrapping,
 minFilter: Texture.FILTER.LinearFilter,
 magFilter: Texture.FILTER.LinearFilter,
 internalFormat: Texture.FORMAT.R16F,
 format: Texture.FORMAT.RED,
 type: Texture.TYPE.HALF_FLOAT,
 clearFunction: 3
}, RenderPass.NEAREST_R16F_TEXTURE_CUBE_MAP_CONFIG = {
 wrapS: Texture.WRAPPING.ClampToEdgeWrapping,
 wrapT: Texture.WRAPPING.ClampToEdgeWrapping,
 wrapR: Texture.WRAPPING.ClampToEdgeWrapping,
 minFilter: Texture.FILTER.NearestFilter,
 magFilter: Texture.FILTER.NearestFilter,
 internalFormat: Texture.FORMAT.R16F,
 format: Texture.FORMAT.RED,
 type: Texture.TYPE.HALF_FLOAT,
 clearFunction: 3
}, RenderPass.DEFAULT_RGB16F_TEXTURE_CONFIG = {
 wrapS: Texture.WRAPPING.ClampToEdgeWrapping,
 wrapT: Texture.WRAPPING.ClampToEdgeWrapping,
 minFilter: Texture.FILTER.LinearFilter,
 magFilter: Texture.FILTER.LinearFilter,
 internalFormat: Texture.FORMAT.RGB16F,
 format: Texture.FORMAT.RGBA,
 type: Texture.TYPE.HALF_FLOAT,
 clearFunction: 3
}, RenderPass.DEFAULT_RGBA16F_TEXTURE_CONFIG = {
 wrapS: Texture.WRAPPING.ClampToEdgeWrapping,
 wrapT: Texture.WRAPPING.ClampToEdgeWrapping,
 minFilter: Texture.FILTER.LinearFilter,
 magFilter: Texture.FILTER.LinearFilter,
 internalFormat: Texture.FORMAT.RGBA16F,
 format: Texture.FORMAT.RGBA,
 type: Texture.TYPE.HALF_FLOAT,
 clearFunction: 3
}, RenderPass.NEAREST_RGBA16F_TEXTURE_CONFIG = {
 wrapS: Texture.WRAPPING.ClampToEdgeWrapping,
 wrapT: Texture.WRAPPING.ClampToEdgeWrapping,
 minFilter: Texture.FILTER.NearestFilter,
 magFilter: Texture.FILTER.NearestFilter,
 internalFormat: Texture.FORMAT.RGBA16F,
 format: Texture.FORMAT.RGBA,
 type: Texture.TYPE.HALF_FLOAT,
 clearFunction: 3
}, RenderPass.FLOAT_RGB_TEXTURE_CONFIG = {
 wrapS: Texture.WRAPPING.ClampToEdgeWrapping,
 wrapT: Texture.WRAPPING.ClampToEdgeWrapping,
 minFilter: Texture.FILTER.LinearFilter,
 magFilter: Texture.FILTER.LinearFilter,
 internalFormat: Texture.FORMAT.RGBA16F,
 format: Texture.FORMAT.RGBA,
 type: Texture.TYPE.HALF_FLOAT,
 clearFunction: 3
}, RenderPass.FULL_FLOAT_RGB_TEXTURE_CONFIG = {
 wrapS: Texture.WRAPPING.ClampToEdgeWrapping,
 wrapT: Texture.WRAPPING.ClampToEdgeWrapping,
 minFilter: Texture.FILTER.LinearFilter,
 magFilter: Texture.FILTER.LinearFilter,
 internalFormat: Texture.FORMAT.RGBA16F,
 format: Texture.FORMAT.RGBA,
 type: Texture.TYPE.FLOAT,
 clearFunction: 3
}, RenderPass.FULL_FLOAT_RGB_NEAREST_TEXTURE_CONFIG = {
 wrapS: Texture.WRAPPING.ClampToEdgeWrapping,
 wrapT: Texture.WRAPPING.ClampToEdgeWrapping,
 minFilter: Texture.FILTER.NearestFilter,
 magFilter: Texture.FILTER.NearestFilter,
 internalFormat: Texture.FORMAT.RGBA16F,
 format: Texture.FORMAT.RGBA,
 type: Texture.TYPE.FLOAT,
 clearFunction: 3
}, RenderPass.FULL_FLOAT_R32F_TEXTURE_CONFIG = {
 wrapS: Texture.WRAPPING.ClampToEdgeWrapping,
 wrapT: Texture.WRAPPING.ClampToEdgeWrapping,
 minFilter: Texture.FILTER.LinearFilter,
 magFilter: Texture.FILTER.LinearFilter,
 internalFormat: Texture.FORMAT.R32F,
 format: Texture.FORMAT.RED,
 type: Texture.TYPE.FLOAT,
 clearFunction: 3
};

class RenderQueue {
 constructor(e) {
  this._renderer = e, this._storedRenderQueues = {}, this._renderQueue = [], this._textureMap = {}, 
  this._forwardedAdditionalData = {}, this._textureMergeScene = new Scene(), this._textureMergeQuad = new Quad(new Vector2(-1, 1), new Vector2(1, -1), new MeshBasicMaterial()), 
  this._textureMergeQuad.frustumCulled = !1, this._textureMergeCamera = new OrthographicCamera(-1, 1, 1, -1, 1, 2), 
  this._textureMergeScene.add(this._textureMergeQuad), this._renderTarget = new RenderTarget(e.width, e.height), 
  this._uuid = _Math.generateUUID();
 }
 _setupRenderTarget(i) {
  var e, r = i.viewport;
  this._renderTarget.clearDrawBuffers(), this._renderTarget.width = r.width, this._renderTarget.height = r.height, 
  null !== i.outDepthID ? void 0 !== (e = this._textureMap[i.outDepthID]) ? (this._renderTarget.depthTexture = e, 
  this._renderTarget.depthTexture.width = r.width, this._renderTarget.depthTexture.height = r.height) : (i.target === RenderPass.TEXTURE_CUBE_MAP ? this._renderTarget.addDepthTexture(!0) : this._renderTarget.addDepthTexture(), 
  this._textureMap[i.outDepthID] = this._renderTarget.depthTexture) : this._renderTarget.depthTexture = null;
  for (let e = 0; e < i.outTextures.length; e++) {
   var s = i.outTextures[e], a = s.id, n = s.textureConfig;
   let t = this._textureMap[a];
   if (void 0 !== t) t.applyConfig(n), t.width = r.width, t.height = r.height, this._renderTarget.addDrawBuffer(t); else {
    let e;
    (e = i.target === RenderPass.TEXTURE_CUBE_MAP ? new CubeTexture({
     textures: void 0,
     wrapS: n.wrapS,
     wrapT: n.wrapT,
     wrapR: n.wrapR,
     minFilter: n.minFilter,
     magFilter: n.magFilter,
     internalFormat: n.internalFormat,
     format: n.format,
     type: n.type,
     size: Math.min(r.width, r.height)
    }) : new Texture(void 0, n.wrapS, n.wrapT, n.minFilter, n.magFilter, n.internalFormat, n.format, n.type, r.width, r.height)).clearFunction = n.clearFunction, 
    this._renderTarget.addDrawBuffer(e), this._textureMap[a] = e, t = e;
   }
   void 0 !== s.clearColorArray ? t.clearColorArray = s.clearColorArray : delete t.clearColorArray;
  }
 }
 render_begin(e = !1) {
  this._saved_vp ? console.error("RenderQueue.render_begin called without an intervening end.") : (this._saved_vp = this._renderer.getViewport(), 
  this.used_check = e, this.used_last = !0, this.used_fail_count = 0);
 }
 render_pass_idx(e) {
  this.render_pass(this._renderQueue[e], e);
 }
 render_pass(e, t) {
  e._isInitialized || (e._initialize(this._textureMap, this._forwardedAdditionalData), 
  e._isInitialized = !0);
  var i = e.viewport, r = e.preprocess(this._textureMap, this._forwardedAdditionalData);
  if (null !== r) {
   if (e.type === RenderPass.BASIC) {
    if (!(void 0 !== r.scene && r.scene instanceof Scene && void 0 !== r.camera && r.camera instanceof Camera)) return void console.error("Render pass " + t + " has invalid preprocess output!");
    if (e.target === RenderPass.SCREEN) this._renderer.updateViewport(i.width, i.height, i.xOffset, i.yOffset), 
    this._renderer.render(r.scene, r.camera); else if (e.target === RenderPass.TEXTURE) this._setupRenderTarget(e), 
    this._renderer.render(r.scene, r.camera, this._renderTarget); else {
     if (e.target !== RenderPass.TEXTURE_CUBE_MAP) return void console.error("Unknown render pass " + t + " target.");
     this._setupRenderTarget(e), this._renderer.render(r.scene, r.camera, this._renderTarget, !0, e.side);
    }
   } else {
    if (e.type === RenderPass.TEXTURE_MERGE) {
     if (!(void 0 !== r.material && r.material instanceof CustomShaderMaterial && void 0 !== r.textures && Array.isArray(r.textures))) return void console.error("Render pass " + t + " has invalid preprocess output!");
     r.material.clearMaps();
     for (let e = 0; e < r.textures.length; e++) r.material.addMap(r.textures[e]);
    } else {
     if (e.type !== RenderPass.POSTPROCESS) return void console.error("Render queue contains RenderPass of unsupported type!");
     if (!(void 0 !== r.material && r.material instanceof CustomShaderMaterial && void 0 !== r.textures && Array.isArray(r.textures))) return void console.error("Render pass " + t + " has invalid preprocess output!");
     r.material.clearMaps();
     for (let e = 0; e < r.textures.length; e++) r.material.addMap(r.textures[e]);
    }
    if (this._textureMergeQuad.material = r.material, e.target === RenderPass.SCREEN) this._renderer.updateViewport(i.width, i.height, i.xOffset, i.yOffset), 
    this._renderer.render(this._textureMergeScene, this._textureMergeCamera); else {
     if (e.target !== RenderPass.TEXTURE) return void console.error("Unknown render pass " + t + " target.");
     this._setupRenderTarget(e), this._renderer.render(this._textureMergeScene, this._textureMergeCamera, this._renderTarget);
    }
   }
   e.postprocess(this._textureMap, this._forwardedAdditionalData), this.used_check && (this._renderer.used ? this.used_last = !0 : (this.used_last = !1, 
   ++this.used_fail_count));
  }
 }
 render_end() {
  return this._renderer.updateViewport(this._saved_vp.width, this._saved_vp.height, this._saved_vp.xOffset, this._saved_vp.yOffset), 
  delete this._saved_vp, {
   textures: this._textureMap,
   additionalData: this._forwardedAdditionalData
  };
 }
 render() {
  this.render_begin();
  for (let e = 0; e < this._renderQueue.length; e++) this.render_pass(this._renderQueue[e], e);
  return this.render_end();
 }
 addTexture(e, t) {
  this._textureMap[e] = t;
 }
 setDataValue(e, t) {
  this._forwardedAdditionalData[e] = t;
 }
 setRenderQueue(t) {
  for (let e = 0; e < t.length; e++) if (!(t[e] instanceof RenderPass)) return void console.error("Given render queue contains invalid elements!");
  this._renderQueue = t;
 }
 takeScreenshot(e, t = 1, i = !1) {
  e = this._textureMap[e];
  this._renderer.takeScreenshot(e, t, i, this);
 }
 pickRGB(e, t, i) {
  e = this._textureMap[e];
  return this._renderer.pickRGB(e, t, i, this);
 }
 pickUINT(e, t, i) {
  e = this._textureMap[e];
  return this._renderer.pickUINT(e, t, i, this);
 }
 downloadTexture(e) {
  var t = this._textureMap[e];
  return this._renderer.downloadTexture(t, e);
 }
 downloadAllTextures() {
  for (var e = Object.keys(this._textureMap), t = 0; t < e.length; t++) this.downloadTexture(e[t]);
 }
 clearRenderQueue() {
  this._renderQueue = [];
 }
 pushRenderPass(e) {
  e instanceof RenderPass ? this._renderQueue.push(e) : console.error("Given argument is not a RenderPass!");
 }
 removeRenderPass(e) {
  e = this._renderQueue.indexOf(e);
  -1 < e && this._renderQueue.splice(e, 1);
 }
 addRenderPass(e, t) {
  this._renderQueue.splice(t, 0, e);
 }
 popRenderPass() {
  return this._renderQueue.pop();
 }
 storeRenderQueue(e) {
  this._storedRenderQueues[e] = this._renderQueue;
 }
 loadRenderQueue(e) {
  e = this._storedRenderQueues[e];
  void 0 === e ? console.error("Error: Could not find the requested queue.") : this._renderQueue = e;
 }
 pushRenderQueue(e) {
  if (e instanceof RenderQueue) {
   var t = e._renderQueue;
   for (let e = 0; e < t.length; e++) this.pushRenderPass(t[e]);
  } else console.error("Given argument is not a RenderQueue!");
 }
}

class RenderArray {
 constructor() {
  this._uuid = _Math.generateUUID(), this._renderArray = [], this._renderArrayLength = this._renderArray.length;
 }
 get uuid() {
  return this._uuid;
 }
 get renderArray() {
  return this._renderArray;
 }
 get length() {
  return this._renderArray.length;
 }
 push(e) {
  return this._renderArray.push(e);
 }
 pop() {
  return this._renderArray.pop();
 }
 add(e, t) {
  this.addlast(e);
 }
 addlast(e) {
  return this._renderArray.push(e);
 }
 remove(e, t) {
  this.removeLast(e);
 }
 removeLast() {
  return this._renderArray.pop();
 }
 clear() {
  this._renderArray = new Array();
 }
 get(e) {
  return this._renderArray[e];
 }
 sort(e) {
  this._renderArray.sort(e);
 }
}

class RenderArrayManager {
 constructor() {
  this._uuid = _Math.generateUUID(), this._renderArrays = new Map(), this._skyboxes = new RenderArray(), 
  this._opaqueObjects = new RenderArray(), this._transparentObjects = new RenderArray(), 
  this._lights = new RenderArray();
 }
 get uuid() {
  return this._uuid;
 }
 get renderArrays() {
  return this._renderArrays;
 }
 get skyboxes() {
  return this._skyboxes;
 }
 get opaqueObjects() {
  return this._opaqueObjects;
 }
 get transparentObjects() {
  return this._transparentObjects;
 }
 get lights() {
  return this._lights;
 }
 clearAll() {
  for (var [ e, t ] of this._renderArrays) t.clear();
  this._skyboxes.clear(), this._opaqueObjects.clear(), this._transparentObjects.clear(), 
  this._lights.clear();
 }
}

class MeshRenderer extends Renderer {
 static MODE = {
  COLOR: 0,
  SHADOW: 1,
  P_SHADOW: 2,
  GEOMETRY: 3,
  PICK: 4
 };
 constructor(e, t, i) {
  super(e, t, i), this._projScreenMatrix = new Matrix4(), this._sphere = new Sphere(), 
  this._frustum = new Frustum(), this._renderArrayManager = new RenderArrayManager(), 
  this._lightsCombined = {
   ambient: [ 0, 0, 0 ],
   directional: [],
   point: [],
   spot: []
  }, this._zVector = new Vector3(), this._gl.enable(this._gl.DEPTH_TEST), this._gl.frontFace(this._gl.CCW), 
  this._selectedRenderer = this._meshRender, this.notinit = !0, this._wasReset = !0, 
  this._pickEnabled = !1, this._pickSecondaryEnabled = !1, this._pickObject3D = !1, 
  this._pickCoordinateX = 0, this._pickCoordinateY = 0, this._pickedID = 0, this._pickedObject3D = null, 
  this._pickCallback = null, this._outlineEnabled = !1, this._outlineArray = null, 
  this.used = !1;
 }
 set selectedRenderer(e) {
  this._selectedRenderer = e;
 }
 set pickObject3D(e) {
  this._pickObject3D = e;
 }
 get pickedID() {
  return this._pickedID;
 }
 get pickedObject3D() {
  return this._pickedObject3D;
 }
 _meshRender(e, t) {
  !0 === e.autoUpdate && e.updateMatrixWorld(), this._projScreenMatrix.multiplyMatrices(t.projectionMatrix, t.matrixWorldInverse), 
  this._frustum.setFromMatrix(this._projScreenMatrix), this._renderArrayManager.clearAll(), 
  this._updateObjects(e, t), 0 < this._renderArrayManager.lights.length && this._setupLights(this._renderArrayManager.lights, t), 
  this._loadRequiredPrograms() ? (this.used || (2 <= this._logLevel && (console.log("-----------------POST------------------"), 
  console.log("REQUIRED: " + this._requiredPrograms + " length: " + this._requiredPrograms.size), 
  console.log(this._requiredPrograms), console.log("--------------------------------------"), 
  console.log("LOADING: " + this._loadingPrograms + " length: " + this._loadingPrograms.size), 
  console.log(this._loadingPrograms), console.log("--------------------------------------"), 
  console.log("COMPILED: " + this._compiledPrograms + " length: " + this._compiledPrograms.size), 
  console.log(this._compiledPrograms), console.log("--------------------------------------")), 
  this.used = !0), this._outlineEnabled ? (this._outlineEnabled = !1, this._renderOutline(this._outlineArray, t)) : this._pickEnabled ? (this._pickEnabled = !1, 
  this._renderPickingObjects(this._renderArrayManager.opaqueObjects, this._renderArrayManager.transparentObjects, t)) : this._pickSecondaryEnabled ? (this._pickSecondaryEnabled = !1, 
  this._pickedObject3D && this.pick_instance(this._pickedObject3D, t)) : (this._renderOpaqueObjects(this._renderArrayManager.opaqueObjects, t), 
  this._renderTransparentObjects(this._renderArrayManager.transparentObjects, t), 
  this._renderOpaqueObjects(this._renderArrayManager.skyboxes, t))) : (1 <= this._logLevel && console.warn("Required programs not loaded!"), 
  2 <= this._logLevel && (console.log("-----------------PRE-----------------"), 
  console.log("REQUIRED: " + this._requiredPrograms + " length: " + this._requiredPrograms.size), 
  console.log(this._requiredPrograms), console.log("--------------------------------------"), 
  console.log("LOADING: " + this._loadingPrograms + " length: " + this._loadingPrograms.size), 
  console.log(this._loadingPrograms), console.log("--------------------------------------"), 
  console.log("COMPILED: " + this._compiledPrograms + " length: " + this._compiledPrograms.size), 
  console.log(this._compiledPrograms), console.log("--------------------------------------")), 
  this.used = !1);
 }
 _renderPickingObjects(e, t, i) {
  this._gl.clearBufferuiv(this._gl.COLOR, 0, new Uint32Array([ 4294967295, 0, 0, 0 ])), 
  this._gl.clearBufferfi(this._gl.DEPTH_STENCIL, 0, 1, 0), this._pickObject3D && (this._pickLUA = []), 
  this._renderPickableObjects(e, i), this._renderPickableObjects(t, i);
  e = new Uint32Array(4);
  this._gl.readBuffer(this._gl.COLOR_ATTACHMENT0), this._gl.readPixels(this._pickCoordinateX, this._pickCoordinateY, 1, 1, this._gl.RGBA_INTEGER, this._gl.UNSIGNED_INT, e), 
  this._pickedID = 4294967295 != e[0] ? e[0] : null, this._pickObject3D ? (this._pickedObject3D = null !== this._pickedID ? this._pickLUA[this._pickedID] : null, 
  delete this._pickLUA, this._pickCallback && this._pickCallback(this._pickedObject3D)) : this._pickCallback && this._pickCallback(this._pickedID);
 }
 _renderOpaqueObjects(e, t) {
  0 < e.length && (e.sort(function(e, t) {
   return e.renderOrder - t.renderOrder;
  }), this._renderObjects(e, t));
 }
 _renderTransparentObjects(e, t) {
  0 < e.length && (e.sort(function(e, t) {
   var i = e.renderOrder - t.renderOrder;
   return 0 == i ? t._zVector.z - e._zVector.z : i;
  }), this._gl.enable(this._gl.BLEND), this._gl.blendEquation(this._gl.FUNC_ADD), 
  this._gl.blendFuncSeparate(this._gl.SRC_ALPHA, this._gl.ONE_MINUS_SRC_ALPHA, this._gl.ONE, this._gl.ONE_MINUS_SRC_ALPHA), 
  this._renderObjects(e, t), this._gl.disable(this._gl.BLEND));
 }
 requestProgram(e) {
  var t;
  return null === e || (t = e.programID, !!this._compiledPrograms.has(t)) || (this._loadingPrograms.has(t) && this._requiredPrograms.has(t) ? void 0 : (this._requiredPrograms.set(t, e), 
  !1));
 }
 _renderObjects(i, r) {
  for (let e = 0; e < i.length; e++) {
   var s = i.get(e), a = s.getRequiredPrograms(this);
   let t = !0;
   for (let e = 0; e < a.length; e++) t = t && this.requestProgram(a[e]);
   if (t) {
    let e;
    (e = this._renderMode === MeshRenderer.MODE.COLOR ? s.material : this._renderMode === MeshRenderer.MODE.SHADOW ? s._DSM : this._renderMode === MeshRenderer.MODE.P_SHADOW ? s._PSM : this._renderMode == MeshRenderer.MODE.GEOMETRY ? s.GBufferMaterial : this._renderMode == MeshRenderer.MODE.PICK ? s._PM : s.material).side = s.material.side, 
    e.isStatic = s.material.isStatic, e.instanced = s.material.instanced, e.normalFlat = s.material.normalFlat;
    var n = e.requiredProgram(this).programID;
    if (void 0 === this._compiledPrograms.get(n)) return void console.warn("NO PROGRAM LOADED");
    this._setupProgram(s, r, e), this._setup_material_settings(e), this._drawObject(s);
   }
  }
 }
 _renderPickableObjects(t, i) {
  for (let e = 0; e < t.length; e++) {
   var r, s = t.get(e);
   s.pickable && (this._pickObject3D && (s.UINT_ID = this._pickLUA.length, this._pickLUA.push(s)), 
   r = s.pickingMaterial, this._setupProgram(s, i, r), this._setup_material_side(r.side), 
   this._setup_material_depth(!0, r.depthFunc, !0), this._drawObject(s));
  }
 }
 _renderOutline(i, r) {
  for (let t = 0; t < i.length; t++) {
   var s = i[t], a = s.outlineMaterial || (s.material.normalFlat ? this._defaultOutlineMatFlat : this._defaultOutlineMat);
   this._setupProgram(s, r, a), this._setup_material_side(a.side), this._setup_material_depth(!0, a.depthFunc, !0);
   let e = 0;
   a.getUniform("u_OutlineGivenInstances") && (e = a.getAttribute("a_OutlineInstances").count()), 
   this._drawObject(s, e);
  }
 }
 _setupProgram(e, t, i) {
  var r = i.requiredProgram(this).programID, r = this._compiledPrograms.get(r);
  r.use(), this._setup_uniforms(r, e, t, i), this._setup_attributes(r, e, i);
 }
 _drawObject(e, t = 0) {
  "function" != typeof e.draw && console.warn("Object " + e.type + " has no draw function"), 
  e.draw(this._gl, this._glManager, t);
 }
 _setup_attributes(i, r, e) {
  var s, a = i.attributeSetter, n = Object.getOwnPropertyNames(a), o = e._attributes;
  for (let t = 0; t < n.length; t++) switch (n[t]) {
  case "VPos":
   var h = r.geometry.vertices;
   h ? a.VPos.set(h, h.itemSize, r.instanced, h.divisor) : console.error("[" + r.type + "]: vertices not found in geometry!");
   break;

  case "VNorm":
   h = r.geometry.normals;
   h ? a.VNorm.set(h, 3, r.instanced, h.divisor) : console.error("[" + r.type + "]: normals not found in geometry!");
   break;

  case "a_Tangent":
   var u = r.geometry.tangents;
   u ? a.a_Tangent.set(u, 3, r.instanced, u.divisor) : console.error("[" + r.type + "]: tangents not found in geometry!");
   break;

  case "a_Bitangent":
   u = r.geometry.bitangents;
   u ? a.a_Bitangent.set(u, 3, r.instanced, u.divisor) : console.error("[" + r.type + "]: bitangents not found in geometry!");
   break;

  case "VColor":
   var l = r.geometry.vertColor;
   l ? a.VColor.set(l, 4, r.instanced, l.divisor) : console.error("[" + r.type + "]: vertColor not found in geometry!");
   break;

  case "uv":
   l = r.geometry.uv;
   l ? a.uv.set(l, 2, r.instanced, l.divisor) : console.error("[" + r.type + "]: uv not found in geometry!");
   break;

  case "MMat":
   var _ = r.geometry.MMat;
   _ ? a.MMat.set(_, 16, r.instanced, _.divisor) : console.error("[" + r.type + "]: MMat not found in geometry!");
   break;

  case "a_Translation":
   _ = r.geometry.translation;
   _ ? a.a_Translation.set(_, 4, r.instanced, _.divisor) : console.error("[" + r.type + "]: Translation not found in geometry!");
   break;

  case "gl_InstanceID":
  case "gl_VertexID":
   break;

  default:
   let e = !1;
   void 0 !== o && void 0 !== (s = o[n[t]]) && (e = !0, a[n[t]].set(s, s.itemSize, r.instanced, s.divisor)), 
   e || (console.error("----------------------------------------"), console.error("Attribute (" + n[t] + ") not set!"), 
   console.error(r), console.error(i), console.error(a), console.error("----------------------------------------"));
  }
 }
 _setup_uniforms(e, i, t, r, s = void 0) {
  var a, n = e.uniformSetter, o = (n.__validation.reset(), void 0 !== n.PMat && n.PMat.set(t.projectionMatrix.elements), 
  void 0 !== n.u_PMatInv && n.u_PMatInv.set(t.projectionMatrixInverse.elements), 
  void 0 !== n.MVMat && n.MVMat.set(i.modelViewMatrix.elements), void 0 !== n.NMat && n.NMat.set(i.normalMatrix.elements), 
  void 0 !== n.u_MMat && n.u_MMat.set(i.matrixWorld.elements), void 0 !== n.VMat && n.VMat.set(t.matrixWorldInverse.elements), 
  void 0 !== n.MVPMat && (i.modelViewProjectionMatrix.multiplyMatrices(t.projectionMatrix, i.modelViewMatrix), 
  n.MVPMat.set(i.modelViewProjectionMatrix.elements)), void 0 !== n.cameraPosition && (a = new Vector3().setFromMatrixPosition(t.matrixWorld), 
  n.cameraPosition.set(a.toArray())), void 0 !== n.lightPosition_worldspace && (a = new Vector3().setFromMatrixPosition(t.matrixWorld), 
  n.lightPosition_worldspace.set(a.toArray())), void 0 !== s && void 0 !== n.globalClippingPlanes && n.globalClippingPlanes.set(s.elements), 
  void 0 !== n.u_RGB_ID && n.u_RGB_ID.set(i.RGB_ID.toArray()), void 0 !== n.u_UINT_ID && n.u_UINT_ID.set(i.UINT_ID >>> 0), 
  void 0 !== n.aspect && n.aspect.set(this._viewport.width / this._viewport.height), 
  void 0 !== n.viewport && n.viewport.set([ this._viewport.width, this._viewport.height ]), 
  void 0 !== n.time && n.time.set(new Date().getMilliseconds()), void 0 !== n.u_clearColor && n.u_clearColor.set(this.clearColor.toArray()), 
  this._setup_light_uniforms(n), this._setup_material_uniforms(r, n, i), n.__validation.validate());
  if (0 < o.length) {
   let t = o[0];
   for (let e = 1; e < o.length; e++) t += ", " + o[e];
   console.error("----------------------------------------"), console.error("Uniforms (" + t + ") not set!"), 
   console.error(i), console.error(e), console.error(n), console.error("----------------------------------------");
  }
 }
 _setup_material_uniforms(t, i, e) {
  var r, s, a = t._uniforms;
  for (r in a) a.hasOwnProperty(r) && void 0 !== i[r] && ((s = a[r]) instanceof Function ? i[r].set(s()) : i[r].set(s));
  void 0 !== i["material.emissive"] && i["material.emissive"].set(t.emissive.toArray()), 
  void 0 !== i["material.diffuse"] && i["material.diffuse"].set(t.color.toArray()), 
  void 0 !== i["material.specular"] && i["material.specular"].set(t.specular.toArray()), 
  void 0 !== i["material.shininess"] && i["material.shininess"].set(t.shininess), 
  void 0 !== i["material.heightScale"] && i["material.heightScale"].set(t.heightScale), 
  void 0 !== i["material.blinn"] && i["material.blinn"].set(t.blinn), void 0 !== i["material.receiveShadows"] && i["material.receiveShadows"].set(t.receiveShadows);
  var n = t.diffuseMap, o = (n && void 0 !== i[o = "material.diffuseMap"] && i[o].set(this._glManager.getGLTexture(n), 0), 
  t.specularMap), n = (o && void 0 !== i[n = "material.specularMap"] && i[n].set(this._glManager.getGLTexture(o), 1), 
  t.normalMap), o = (n && void 0 !== i[o = "material.normalMap"] && i[o].set(this._glManager.getGLTexture(n), 2), 
  t.heightMap), h = (o && void 0 !== i[n = "material.heightMap"] && i[n].set(this._glManager.getGLTexture(o), 3), 
  t.instanceData);
  for (let e = 0; e < h.length; e++) {
   var u = "material.instanceData" + e;
   void 0 !== i[u] && i[u].set(this._glManager.getGLTexture(h[e]), 10 + e);
  }
  var l = t.maps;
  for (let e = 0; e < l.length; e++) {
   var _ = "material.texture" + e;
   void 0 !== i[_] && i[_].set(this._glManager.getGLTexture(l[e]), 15 + e);
  }
  var c, d = t.cubemaps;
  for (let e = 0; e < d.length; e++) {
   var m = "material.cubeTexture" + e;
   void 0 !== i[m] && i[m].set(this._glManager.getGLCubeTexture(d[e]), 20 + e);
  }
  if (!0 === t.usePoints && void 0 !== i.pointSize && i.pointSize.set(t.pointSize), 
  void 0 !== i.lineWidth && i.lineWidth.set(t.lineWidth), !0 === t.useClippingPlanes) for (let e = 0; e < t.clippingPlanes.length; e++) void 0 !== i[(c = "clippingPlanes[" + e + "]") + ".normal"] && i[c + ".normal"].set(t.clippingPlanes[e].normal.toArray()), 
  void 0 !== i[c + ".constant"] && i[c + ".constant"].set(t.clippingPlanes[e].constant);
  !0 === t.transparent ? (void 0 !== i.alpha && i.alpha.set(t.opacity), void 0 !== i["material.alpha"] && i["material.alpha"].set(t.opacity)) : (void 0 !== i.alpha && i.alpha.set(1), 
  void 0 !== i["material.alpha"] && i["material.alpha"].set(1));
 }
 _setup_material_settings(e) {
  this._setup_material_side(e.side), this._setup_material_depth(e.depthTest, e.depthFunc, e.depthWrite);
 }
 _setup_material_side(e) {
  e === FRONT_AND_BACK_SIDE ? this._gl.disable(this._gl.CULL_FACE) : e === FRONT_SIDE ? (this._gl.enable(this._gl.CULL_FACE), 
  this._gl.cullFace(this._gl.BACK)) : e === BACK_SIDE && (this._gl.enable(this._gl.CULL_FACE), 
  this._gl.cullFace(this._gl.FRONT));
 }
 _setup_material_depth(e, t, i) {
  if (e) switch (this._gl.enable(this._gl.DEPTH_TEST), t) {
  case FUNC_LEQUAL:
   this._gl.depthFunc(this._gl.LEQUAL);
   break;

  case FUNC_LESS:
   this._gl.depthFunc(this._gl.LESS);
   break;

  case FUNC_GEQUAL:
   this._gl.depthFunc(this._gl.GEQUAL);
   break;

  case FUNC_GREATER:
   this._gl.depthFunc(this._gl.GREATER);
   break;

  case FUNC_EQUAL:
   this._gl.depthFunc(this._gl.EQUAL);
   break;

  case FUNC_NOTEQUAL:
   this._gl.depthFunc(this._gl.NOTEQUAL);
   break;

  case FUNC_NEVER:
   this._gl.depthFunc(this._gl.NEVER);
   break;

  case FUNC_ALWAYS:
   this._gl.depthFunc(this._gl.ALWAYS);
  } else this._gl.disable(this._gl.DEPTH_TEST);
  this._gl.depthMask(i);
 }
 _setup_light_uniforms(t) {
  void 0 !== t.ambient && t.ambient.set(this._lightsCombined.ambient);
  for (let e = 0; e < this._lightsCombined.directional.length; e++) {
   var i, r = "dLights[" + e + "]", s = this._lightsCombined.directional[e], a = (t[r + ".position"] && t[r + ".position"].set(s.direction.toArray()), 
   t[r + ".direction"] && t[r + ".direction"].set(s.direction.toArray()), t[r + ".color"] && t[r + ".color"].set(s.color.toArray()), 
   void 0 !== t[r + ".VPMat"] && t[r + ".VPMat"].set(s.VPMat.elements), s.shadowmap);
   a && void 0 !== t[i = r + ".shadowmap"] && t[i].set(this._glManager.getGLTexture(a), 8 + e), 
   t[r + ".castShadows"] && t[r + ".castShadows"].set(s.castShadows), t[r + ".hardShadows"] && t[r + ".hardShadows"].set(s.hardShadows), 
   t[r + ".minBias"] && t[r + ".minBias"].set(s.minBias), t[r + ".maxBias"] && t[r + ".maxBias"].set(s.maxBias);
  }
  for (let e = 0; e < this._lightsCombined.point.length; e++) {
   var n, o = "pLights[" + e + "]", h = this._lightsCombined.point[e], u = (t[o + ".position"] && t[o + ".position"].set(h.position.toArray()), 
   t[o + ".position_worldspace"] && t[o + ".position_worldspace"].set(h.position_worldspace.toArray()), 
   t[o + ".position_screenspace"] && t[o + ".position_screenspace"].set(h.position_screenspace.toArray()), 
   t[o + ".color"] && t[o + ".color"].set(h.color.toArray()), t[o + ".distance"] && t[o + ".distance"].set(h.distance), 
   t[o + ".decay"] && t[o + ".decay"].set(h.decay), void 0 !== t[o + ".VPMat"] && t[o + ".VPMat"].set(h.VPMat.elements), 
   h.shadowmap);
   u && void 0 !== t[n = o + ".shadowmap"] && t[n].set(this._glManager.getGLCubeTexture(u), 10 + e), 
   t[o + ".castShadows"] && t[o + ".castShadows"].set(h.castShadows), t[o + ".hardShadows"] && t[o + ".hardShadows"].set(h.hardShadows), 
   t[o + ".minBias"] && t[o + ".minBias"].set(h.minBias), t[o + ".maxBias"] && t[o + ".maxBias"].set(h.maxBias), 
   t[o + ".shadowFar"] && t[o + ".shadowFar"].set(h.shadowFar), t[o + ".constant"] && t[o + ".constant"].set(h.constant), 
   t[o + ".linear"] && t[o + ".linear"].set(h.linear), t[o + ".quadratic"] && t[o + ".quadratic"].set(h.quadratic);
  }
  for (let e = 0; e < this._lightsCombined.spot.length; e++) {
   var l, _ = "sLights[" + e + "]", c = this._lightsCombined.spot[e], d = (t[_ + ".position"] && t[_ + ".position"].set(c.position.toArray()), 
   t[_ + ".position_screenspace"] && t[_ + ".position_screenspace"].set(c.position_screenspace.toArray()), 
   t[_ + ".color"] && t[_ + ".color"].set(c.color.toArray()), t[_ + ".distance"] && t[_ + ".distance"].set(c.distance), 
   t[_ + ".decay"] && t[_ + ".decay"].set(c.decay), t[_ + ".cutoff"] && t[_ + ".cutoff"].set(c.cutoff), 
   t[_ + ".outerCutoff"] && t[_ + ".outerCutoff"].set(c.outerCutoff), t[_ + ".direction"] && t[_ + ".direction"].set(c.direction.toArray()), 
   t[_ + ".direction_screenspace"] && t[_ + ".direction_screenspace"].set(c.direction_screenspace.toArray()), 
   void 0 !== t[_ + ".VPMat"] && t[_ + ".VPMat"].set(c.VPMat.elements), c.shadowmap);
   d && void 0 !== t[l = _ + ".shadowmap"] && t[l].set(this._glManager.getGLTexture(d), 12 + e), 
   t[_ + ".castShadows"] && t[_ + ".castShadows"].set(c.castShadows), t[_ + ".hardShadows"] && t[_ + ".hardShadows"].set(c.hardShadows), 
   t[_ + ".minBias"] && t[_ + ".minBias"].set(c.minBias), t[_ + ".maxBias"] && t[_ + ".maxBias"].set(c.maxBias), 
   t[_ + ".constant"] && t[_ + ".constant"].set(c.constant), t[_ + ".linear"] && t[_ + ".linear"].set(c.linear), 
   t[_ + ".quadratic"] && t[_ + ".quadratic"].set(c.quadratic);
  }
 }
 _updateObjects(t, i) {
  if (t.visible && (this._objectInFrustum(t) || this._screenshotInProgress)) {
   t.fillRenderArray(this._renderArrayManager), t.project(this._projScreenMatrix);
   var r = t.getRequiredPrograms(this);
   for (let e = 0; e < r.length; e++) this._fillRequiredPrograms(r[e]);
   t.update(this._glManager, i);
   for (let e = 0; e < t.children.length; e++) this._updateObjects(t.children[e], i);
  }
 }
 _fillRequiredPrograms(e) {
  null === e || this._requiredPrograms.has(e.programID) || this._requiredPrograms.set(e.programID, e);
 }
 _setupLights(t, i) {
  this._lightsCombined.ambient = [ 0, 0, 0 ], this._lightsCombined.directional.length = 0, 
  this._lightsCombined.point.length = 0;
  let r = this._lightsCombined.spot.length = 0, s = 0, a = 0;
  for (let e = 0; e < t.length; e++) {
   var n, o, h, u, l = (u = t.get(e)).color, _ = u.intensity;
   u instanceof AmbientLight ? (r += l.r * _, s += l.g * _, a += l.b * _, this._lightsCombined.ambient[0] += u.color.r * u.intensity, 
   this._lightsCombined.ambient[1] += u.color.g * u.intensity, this._lightsCombined.ambient[2] += u.color.b * u.intensity) : u instanceof DirectionalLight ? ((l = {
    color: new Color(),
    direction: new Vector4(),
    ref: u,
    VPMat: new Matrix4(),
    shadowmap: null,
    castShadows: void 0,
    hardShadows: !0,
    minBias: .005,
    maxBias: .05
   }).color.copy(u.color).multiplyScalar(u.intensity), l.direction.set(u.direction.x, u.direction.y, u.direction.z, 0), 
   l.direction.applyMatrix4(u.matrixWorld), l.direction.applyMatrix4(i.matrixWorldInverse), 
   _ = new Matrix4().getInverse(u.cameraGroup.children[0].matrixWorld), n = u.cameraGroup.children[0].projectionMatrix, 
   n = new Matrix4().multiplyMatrices(n, _), l.VPMat = n, l.shadowmap = u.shadowmap, 
   l.castShadows = u.castShadows, l.hardShadows = u.hardShadows, l.minBias = u.minBias, 
   l.maxBias = u.maxBias, this._lightsCombined.directional.push(l)) : u instanceof PointLight ? ((_ = {
    color: new Color(),
    position: new Vector3(),
    position_worldspace: new Vector3(),
    position_screenspace: new Vector3(),
    distance: u.distance,
    decay: u.decay,
    ref: u,
    VPMat: new Matrix4(),
    shadowmap: null,
    castShadows: void 0,
    hardShadows: !0,
    minBias: .005,
    maxBias: .05,
    shadowFar: 128,
    constant: u.constant,
    linear: u.linear,
    quadratic: u.quadratic
   }).position_worldspace.setFromMatrixPosition(u.matrixWorld), _.position.setFromMatrixPosition(u.matrixWorld), 
   _.position.applyMatrix4(i.matrixWorldInverse), _.position_screenspace.setFromMatrixPosition(u.matrixWorld), 
   _.position_screenspace.applyMatrix4(i.matrixWorldInverse), n = _.position_screenspace.z, 
   _.position_screenspace.applyMatrix4(i.projectionMatrix), 0 < n && _.position_screenspace.multiplyScalar(-1), 
   _.position_screenspace.multiplyScalar(.5), _.position_screenspace.addScalar(.5), 
   l = new Matrix4().getInverse(u.cameraGroup.children[0].matrixWorld), o = u.cameraGroup.children[0].projectionMatrix, 
   o = new Matrix4().multiplyMatrices(o, l), _.VPMat = o, _.shadowmap = u.shadowmap, 
   _.castShadows = u.castShadows, _.hardShadows = u.hardShadows, _.minBias = u.minBias, 
   _.maxBias = u.maxBias, _.shadowFar = u.shadowFar, _.color.copy(u.color).multiplyScalar(u.intensity), 
   this._lightsCombined.point.push(_)) : u instanceof SpotLight && ((l = {
    color: new Color(),
    position: new Vector3(),
    position_screenspace: new Vector3(),
    distance: u.distance,
    decay: u.decay,
    cutoff: Math.cos(u.cutoff),
    outerCutoff: Math.cos(u.outerCutoff),
    direction: new Vector4(),
    direction_screenspace: new Vector4(),
    ref: u,
    VPMat: new Matrix4(),
    shadowmap: null,
    castShadows: void 0,
    hardShadows: !0,
    minBias: .005,
    maxBias: .05,
    constant: u.constant,
    linear: u.linear,
    quadratic: u.quadratic
   }).position.setFromMatrixPosition(u.matrixWorld), l.position.applyMatrix4(i.matrixWorldInverse), 
   l.position_screenspace.setFromMatrixPosition(u.matrixWorld), l.position_screenspace.applyMatrix4(i.matrixWorldInverse), 
   l.position_screenspace.z, l.position_screenspace.applyMatrix4(i.projectionMatrix), 
   l.position_screenspace.multiplyScalar(.5), l.position_screenspace.addScalar(.5), 
   l.color.copy(u.color).multiplyScalar(u.intensity), l.direction.set(u.direction.x, u.direction.y, u.direction.z, 0), 
   l.direction.applyMatrix4(u.matrixWorld), l.direction.applyMatrix4(i.matrixWorldInverse), 
   l.direction_screenspace.set(u.direction.x, u.direction.y, u.direction.z, 0), 
   l.direction_screenspace.applyMatrix4(u.matrixWorld), l.direction_screenspace.applyMatrix4(i.matrixWorldInverse), 
   o = l.direction_screenspace.z, l.direction_screenspace.applyMatrix4(i.projectionMatrix), 
   l.direction_screenspace.multiplyScalar(1 / l.direction_screenspace.w), 0 < o && l.direction_screenspace.multiplyScalar(-1), 
   _ = new Matrix4().getInverse(u.cameraGroup.children[0].matrixWorld), h = u.cameraGroup.children[0].projectionMatrix, 
   h = new Matrix4().multiplyMatrices(h, _), l.VPMat = h, l.shadowmap = u.shadowmap, 
   l.castShadows = u.castShadows, l.hardShadows = u.hardShadows, l.minBias = u.minBias, 
   l.maxBias = u.maxBias, this._lightsCombined.spot.push(l));
  }
 }
 _objectInFrustum(e) {
  var t;
  return !e.frustumCulled || (e._UPDATE_BOUNDS && (t = e.boundingSphere, this._sphere.copy(t).applyMatrix4(e.matrixWorld), 
  e._UPDATE_BOUNDS = !1), this._frustum.intersectsSphere(this._sphere));
 }
 pick_setup(e, t, i = null) {
  this._pickEnabled = !0, this._pickCoordinateX = e, this._pickCoordinateY = t, 
  this._pickCallback = i;
 }
 pick_instance(e, t) {
  this._gl.clearBufferuiv(this._gl.COLOR, 0, new Uint32Array([ 4294967295, 0, 0, 0 ])), 
  this._gl.clearBufferfi(this._gl.DEPTH_STENCIL, 0, 1, 0), e.pickingMaterial.setUniform("u_PickInstance", !0), 
  this._setupProgram(e, t, e.pickingMaterial), this._setup_material_side(e.material.side), 
  this._setup_material_depth(!0, e.material.depthFunc, !0), this._drawObject(e), 
  e.pickingMaterial.setUniform("u_PickInstance", !1);
  t = new Uint32Array(4);
  return this._gl.readBuffer(this._gl.COLOR_ATTACHMENT0), this._gl.readPixels(this._pickCoordinateX, this._pickCoordinateY, 1, 1, this._gl.RGBA_INTEGER, this._gl.UNSIGNED_INT, t), 
  this._pickedID = 4294967295 != t[0] ? t[0] : null, this._pickedID;
 }
}

class FX extends RenderQueue {
 constructor(e, t, i) {
  super(e), this._inputs = t, this._outputs = i;
 }
 static iterateSceneR(t, i) {
  if (null != t) {
   if (0 < t.children.length) for (let e = 0; e < t.children.length; e++) FX.iterateSceneR(t.children[e], i);
   i(t);
  }
 }
 get inputs() {
  return this._inputs;
 }
 get outputs() {
  return this._outputs;
 }
}

FX.input = class {
 constructor(e) {
  this._name = e;
 }
 get name() {
  return this._name;
 }
 connect() {}
}, FX.output = class {
 constructor(e) {
  this._name = e;
 }
 get name() {
  return this._name;
 }
 connect() {}
}, document.body.clientWidth, document.body.clientHeight, document.body.clientWidth, 
document.body.clientHeight, document.body.clientWidth, document.body.clientHeight, 
document.body.clientWidth, document.body.clientHeight, document.body.clientWidth, 
document.body.clientHeight, document.body.clientWidth, document.body.clientHeight, 
document.body.clientWidth, document.body.clientHeight;

const predef_width = document.body.clientWidth, predef_height = document.body.clientHeight;

class PickerFX extends FX {
 static PICK_MODE = {
  RGB: PickingShaderMaterial.PICK_MODE.RGB,
  UINT: PickingShaderMaterial.PICK_MODE.UINT
 };
 constructor(e, i = {}, t = {}, r = {}) {
  super(e, i, r), this.inputs.scene = this.inputs.scene || void 0, this.inputs.camera = this.inputs.camera || void 0, 
  this.outputs.color = this.outputs.color || new FX.output("color_picker"), this._pickMode = null;
  const s = new Map(), a = new Map(), n = new Map();
  this._renderPass_Picker = new RenderPass(RenderPass.BASIC, (e, t) => {
   FX.iterateSceneR(i.scene, e => {
    e instanceof Mesh && (s.set(e._uuid, e.material), a.set(e._uuid, e.pickingMaterial), 
    n.set(e._uuid, e.visible));
   });
  }, (e, t) => (FX.iterateSceneR(i.scene, e => {
   e instanceof Mesh && (e.pickable ? (s.get(e._uuid) && a.get(e._uuid) || (s.set(e._uuid, e.material), 
   a.set(e._uuid, e.pickingMaterial), n.set(e._uuid, e.visible)), e.material = a.get(e._uuid), 
   e.material.pickMode = this._pickMode) : e.visible = !1);
  }), {
   scene: i.scene,
   camera: i.camera
  }), (e, t) => {
   FX.iterateSceneR(i.scene, e => {
    e instanceof Mesh && (e.pickable ? (s.get(e._uuid) && a.get(e._uuid) || (s.set(e._uuid, e.material), 
    a.set(e._uuid, e.pickingMaterial), n.set(e._uuid, e.visible)), e.material = s.get(e._uuid)) : e.visible = n.get(e._uuid));
   });
  }, RenderPass.TEXTURE, {
   width: predef_width,
   height: predef_height
  }, "depth_color_picker", [ {
   id: r.color.name,
   textureConfig: RenderPass.DEFAULT_RGBA_TEXTURE_CONFIG
  } ]), this.pushRenderPass(this._renderPass_Picker), this.pickMode = t.pickMode || PickerFX.PICK_MODE.RGB;
 }
 get pickMode() {
  return this._pickMode;
 }
 set pickMode(e) {
  (this._pickMode = e) === PickerFX.PICK_MODE.RGB ? this._renderPass_Picker.outTextures = [ {
   id: this.outputs.color.name,
   textureConfig: RenderPass.DEFAULT_RGBA_TEXTURE_CONFIG
  } ] : e === PickerFX.PICK_MODE.UINT ? this._renderPass_Picker.outTextures = [ {
   id: this.outputs.color.name,
   textureConfig: RenderPass.DEFAULT_R32UI_TEXTURE_CONFIG
  } ] : console.error("Unknown pick mode: [" + e + "].");
 }
}

document.body.clientWidth, document.body.clientHeight, document.body.clientWidth, 
document.body.clientHeight, document.body.clientWidth, document.body.clientHeight;

class Point extends Mesh {
 constructor(e = {}) {
  super(e.geometry || new Geometry({
   vertices: new Float32Attribute([ 0, 0, 0 ], 3)
  }), e.material || new PointBasicMaterial(), new PickingShaderMaterial("POINTS", {
   pointSize: 1
  })), this.type = "Point", this.renderingPrimitive = POINTS;
 }
 set points(e) {
  this.geometry.vertices = Float32Attribute(e, 3);
 }
 get points() {
  return this.geometry.vertices;
 }
 static fromJson(e, t, i) {
  t = new Point(t, i);
  return super.fromJson(e, void 0, void 0, t);
 }
}

class GLManager {
 static sCheckFrameBuffer = !0;
 static sProgramCaching = null;
 constructor(e, t, i) {
  this._gl = null;
  for (var r = (this._glVersion = t) == WEBGL1 ? [ "webgl", "experimental-webgl" ] : [ "webgl2", "experimental-webgl2" ], s = 0; s < r.length; s++) {
   try {
    this._gl = e.canvasDOM.getContext(r[s], i);
   } catch (e) {
    console.error(e);
   }
   if (this._gl) break;
  }
  if (!this._gl) throw "ERROR: Failed to retrieve GL Context.";
  this._gl.getExtension("EXT_color_buffer_float"), this._FIRST_COLOR_ATTACHMENT = this._gl.COLOR_ATTACHMENT0, 
  this._LAST_COLOR_ATTACHMENT = this._gl.COLOR_ATTACHMENT15, this._fboManager = new GLFrameBufferManager(this._gl), 
  this._textureManager = new GLTextureManager(this._gl), this._attributeManager = new GLAttributeManager(this._gl), 
  this.autoClear = !0, this._clearColor = new Vector4(0, 0, 0, 0), this._clearDepth = null, 
  this._clearStencil = null, this.setClearColor(0, 0, 0, 0), this.setClearDepth(1), 
  this.setClearStencil(0);
 }
 updateBufferAttribute(e, t) {
  t ? this._attributeManager.updateAttribute(e, this._gl.ELEMENT_ARRAY_BUFFER) : this._attributeManager.updateAttribute(e, this._gl.ARRAY_BUFFER);
 }
 initRenderTarget(t) {
  let i;
  var r, s = [];
  this._fboManager.bindFramebuffer(t), null !== t.depthTexture ? (i = this._textureManager.getGLTexture(t.depthTexture, !0), 
  this._gl.framebufferTexture2D(this._gl.FRAMEBUFFER, this._gl.DEPTH_ATTACHMENT, this._gl.TEXTURE_2D, i, 0), 
  this._gl.bindTexture(this._gl.TEXTURE_2D, null)) : this._gl.framebufferTexture2D(this._gl.FRAMEBUFFER, this._gl.DEPTH_ATTACHMENT, this._gl.TEXTURE_2D, null, 0), 
  r = t.sizeDrawBuffers();
  for (let e = 0; e < r; e++) i = this._textureManager.getGLTexture(t._drawBuffers[e], !0), 
  this._gl.framebufferTexture2D(this._gl.FRAMEBUFFER, this._FIRST_COLOR_ATTACHMENT + e, this._gl.TEXTURE_2D, i, 0), 
  s.push(this._FIRST_COLOR_ATTACHMENT + e);
  if (this._gl.bindTexture(this._gl.TEXTURE_2D, null), null !== t.__fboLength && t.__fboLength > r) for (let e = r; e < t.__fboLength; e++) this._gl.framebufferTexture2D(this._gl.FRAMEBUFFER, this._FIRST_COLOR_ATTACHMENT + e, this._gl.TEXTURE_2D, null, 0);
  if (this._gl.drawBuffers(s), t.__fboLength = r, GLManager.sCheckFrameBuffer && this._gl.checkFramebufferStatus(this._gl.FRAMEBUFFER) !== this._gl.FRAMEBUFFER_COMPLETE) switch (console.error("Render target: framebuffer not complete!"), 
  this._gl.checkFramebufferStatus(this._gl.FRAMEBUFFER)) {
  case this._gl.FRAMEBUFFER_INCOMPLETE_ATTACHMENT:
   console.error("FRAMEBUFFER_INCOMPLETE_ATTACHMENT: The attachment types are mismatched or not all framebuffer attachment points are framebuffer attachment complete.");
   break;

  case this._gl.FRAMEBUFFER_INCOMPLETE_MISSING_ATTACHMENT:
   console.error("FRAMEBUFFER_INCOMPLETE_MISSING_ATTACHMENT: There is no attachment.");
   break;

  case this._gl.FRAMEBUFFER_INCOMPLETE_DIMENSIONS:
   console.error("FRAMEBUFFER_INCOMPLETE_DIMENSIONS: Problem with the texture dimensions.");
   break;

  case this._gl.FRAMEBUFFER_UNSUPPORTED:
   console.error("FRAMEBUFFER_UNSUPPORTED: The format of the attachment is not supported or if depth and stencil attachments are not the same renderbuffer.");
   break;

  case this._gl.FRAMEBUFFER_INCOMPLETE_MULTISAMPLE:
   console.error("FRAMEBUFFER_INCOMPLETE_MULTISAMPLE: The values of gl.RENDERBUFFER_SAMPLES are different among attached renderbuffers, or are non-zero if the attached images are a mix of renderbuffers and textures.");
   break;

  default:
   console.error("Unknown error! Abandon hope all ye who enter here.");
  }
  this.clearSeparate(t);
 }
 initRenderTargetCube(t, i) {
  let r;
  var s, a = [];
  this._fboManager.bindFramebuffer(t), null !== t.depthTexture ? (r = this._textureManager.getGLCubeTexture(t.depthTexture, !0), 
  this._gl.framebufferTexture2D(this._gl.FRAMEBUFFER, this._gl.DEPTH_ATTACHMENT, this._gl.TEXTURE_CUBE_MAP_POSITIVE_X + i, r, 0), 
  this._gl.bindTexture(this._gl.TEXTURE_CUBE_MAP, null)) : this._gl.framebufferTexture2D(this._gl.FRAMEBUFFER, this._gl.DEPTH_ATTACHMENT, this._gl.TEXTURE_CUBE_MAP_POSITIVE_X + i, null, 0), 
  s = t.sizeDrawBuffers();
  for (let e = 0; e < s; e++) r = this._textureManager.getGLCubeTexture(t._drawBuffers[e], !0), 
  this._gl.framebufferTexture2D(this._gl.FRAMEBUFFER, this._FIRST_COLOR_ATTACHMENT + e, this._gl.TEXTURE_CUBE_MAP_POSITIVE_X + i, r, 0), 
  a.push(this._FIRST_COLOR_ATTACHMENT + e);
  if (this._gl.bindTexture(this._gl.TEXTURE_CUBE_MAP, null), null !== t.__fboLength && t.__fboLength > s) for (let e = s; e < t.__fboLength; e++) this._gl.framebufferTexture2D(this._gl.FRAMEBUFFER, this._FIRST_COLOR_ATTACHMENT + e, this._gl.TEXTURE_CUBE_MAP_POSITIVE_X + i, null, 0);
  if (this._gl.drawBuffers(a), t.__fboLength = s, GLManager.sCheckFrameBuffer && this._gl.checkFramebufferStatus(this._gl.FRAMEBUFFER) !== this._gl.FRAMEBUFFER_COMPLETE) switch (console.error("Render target: framebuffer not complete!"), 
  this._gl.checkFramebufferStatus(this._gl.FRAMEBUFFER)) {
  case this._gl.FRAMEBUFFER_INCOMPLETE_ATTACHMENT:
   console.error("FRAMEBUFFER_INCOMPLETE_ATTACHMENT: The attachment types are mismatched or not all framebuffer attachment points are framebuffer attachment complete.");
   break;

  case this._gl.FRAMEBUFFER_INCOMPLETE_MISSING_ATTACHMENT:
   console.error("FRAMEBUFFER_INCOMPLETE_MISSING_ATTACHMENT: There is no attachment.");
   break;

  case this._gl.FRAMEBUFFER_INCOMPLETE_DIMENSIONS:
   console.error("FRAMEBUFFER_INCOMPLETE_DIMENSIONS: Problem with the texture dimensions.");
   break;

  case this._gl.FRAMEBUFFER_UNSUPPORTED:
   console.error("FRAMEBUFFER_UNSUPPORTED: The format of the attachment is not supported or if depth and stencil attachments are not the same renderbuffer.");
   break;

  case this._gl.FRAMEBUFFER_INCOMPLETE_MULTISAMPLE:
   console.error("FRAMEBUFFER_INCOMPLETE_MULTISAMPLE: The values of gl.RENDERBUFFER_SAMPLES are different among attached renderbuffers, or are non-zero if the attached images are a mix of renderbuffers and textures.");
   break;

  default:
   console.error("Unknown error! Abandon hope all ye who enter here.");
  }
  this.clearSeparate(t);
 }
 clearSeparate(t) {
  var r = t.sizeDrawBuffers(), s = (this._gl.depthMask(!0), this._gl.clearBufferfv(this._gl.DEPTH, 0, new Float32Array([ 1, 1, 1, 1 ])), 
  this._clearColor.toArray());
  for (let e = 0; e < r; e++) {
   var a, n = t._drawBuffers[e];
   null !== n.clearColorArray && (1 === n.clearFunction ? (a = n.clearColorArray || new Uint32Array(s), 
   this._gl.clearBufferuiv(this._gl.COLOR, e, a)) : 2 === n.clearFunction ? (a = n.clearColorArray || new Int32Array(s), 
   this._gl.clearBufferiv(this._gl.COLOR, e, a)) : 3 === n.clearFunction ? (n = n.clearColorArray || new Float32Array(s), 
   this._gl.clearBufferfv(this._gl.COLOR, e, n)) : console.error("Unsupported value for clearFunction", t._drawBuffers[i].clearFunction));
  }
 }
 cleanupRenderTarget() {
  this._fboManager.unbindFramebuffer();
 }
 getGLTexture(e) {
  return this._textureManager.getGLTexture(e);
 }
 getGLCubeTexture(e) {
  return this._textureManager.getGLCubeTexture(e);
 }
 downloadTexture(e, t) {
  var i = this._textureManager.getGLTexture(e), r = this._gl.createFramebuffer(), r = (this._gl.bindFramebuffer(this._gl.FRAMEBUFFER, r), 
  this._gl.framebufferTexture2D(this._gl.FRAMEBUFFER, this._gl.COLOR_ATTACHMENT0, this._gl.TEXTURE_2D, i, 0), 
  document.createElement("canvas")), i = (r.width = e._width, r.height = e._height, 
  r.getContext("2d"));
  if (22 == e._type) {
   var s = new Float32Array(e._width * e._height * 4), a = (this._gl.readPixels(0, 0, e._width, e._height, this._gl.RGBA, this._gl.FLOAT, s), 
   "PF\n" + e._width + " " + e._height + "\n1.0\n"), n = new ArrayBuffer(a.length + e._width * e._height * 3 * 4), o = new DataView(n);
   for (let e = 0; e < a.length; e++) o.setUint8(e, a.charCodeAt(e));
   for (var h = 0; h < e._width * e._height; h++) o.setFloat32(a.length + 4 * (3 * h + 0), s[4 * h + 0]), 
   o.setFloat32(a.length + 4 * (3 * h + 1), s[4 * h + 1]), o.setFloat32(a.length + 4 * (3 * h + 2), s[4 * h + 2]);
   n = Array.prototype.map.call(new Uint8Array(n), function(e) {
    return String.fromCharCode(e);
   }).join("");
   console.log(n), (u = document.createElement("a")).download = t + ".pfm", u.href = "data:application/octet-stream;base64," + btoa(n), 
   u.click();
  } else {
   n = new Uint8Array(e._width * e._height * 4), n = (this._gl.readPixels(0, 0, e._width, e._height, this._gl.RGBA, this._gl.UNSIGNED_BYTE, n), 
   this._gl.bindFramebuffer(this._gl.FRAMEBUFFER, null), new ImageData(new Uint8ClampedArray(n.buffer), r.width, r.height));
   i.putImageData(n, 0, 0, 0, 0, r.width, r.height);
   (u = document.createElement("a")).download = t + ".png", u.href = r.toDataURL();
   var u, i = document.createEvent("MouseEvent");
   i.initEvent("click", !0, !0), u.dispatchEvent(i);
  }
 }
 getGLBuffer(e) {
  return this._attributeManager.getGLBuffer(e);
 }
 deleteAttributeBuffers() {
  this._attributeManager.deleteBuffers();
 }
 deleteFrameBuffers() {
  this._fboManager.deleteFrameBuffers();
 }
 deleteTextures() {
  this._textureManager.deleteTextures();
 }
 clear(e, t, i) {
  var r;
  null === this._gl.getParameter(this._gl.FRAMEBUFFER_BINDING) && (void (r = 0) !== e && !e || (r |= this._gl.COLOR_BUFFER_BIT), 
  void 0 !== t && !t || (r |= this._gl.DEPTH_BUFFER_BIT), void 0 !== i && !i || (r |= this._gl.STENCIL_BUFFER_BIT), 
  this._gl.clear(r));
 }
 get clearColor() {
  return this._clearColor;
 }
 set clearColor(e) {
  this.setClearColor(e.x, e.y, e.z, e.w);
 }
 setClearColor(e, t, i, r) {
  var s = new Vector4(e, t, i, r);
  !1 === this._clearColor.equals(s) && (this._gl.clearColor(e, t, i, r), this._clearColor.copy(s));
 }
 setClearDepth(e) {
  this._clearDepth !== e && (this._gl.clearDepth(e), this._clearDepth = e);
 }
 setClearStencil(e) {
  this._clearStencil !== e && (this._gl.clearStencil(e), this._clearStencil = e);
 }
 get context() {
  return this._gl;
 }
 get glVersion() {
  return this._glVersion;
 }
 get cache_programs() {
  return GLManager.sProgramCaching;
 }
 set cache_programs(e) {
  GLManager.sProgramCaching = e;
 }
 get gl() {
  return this._gl;
 }
 get contextAttributes() {
  return this._gl.getContextAttributes();
 }
 imageDataToImage(e) {
  var t = document.createElement("canvas"), i = t.getContext("2d"), i = (t.width = e.width, 
  t.height = e.height, i.putImageData(e, 0, 0), new Image());
  return i.src = t.toDataURL(), i;
 }
 flipImage(e, t, i) {
  for (var r = i / 2 | 0, s = 4 * t, a = new Uint8Array(4 * t), n = 0; n < r; ++n) {
   var o = n * s, h = (i - n - 1) * s;
   a.set(e.subarray(o, o + s)), e.copyWithin(o, h, h + s), e.set(a, h);
  }
 }
 openImageInNewTab(e) {
  const t = window.open(), i = this.imageDataToImage(e);
  i.addEventListener("load", function() {
   t ? t.scrollTo(i.width / 2 - t.innerWidth / 2, i.height / 2 - t.innerHeight / 2) : console.warn("Opening of a new tab failed");
  }), t ? t.document.body.appendChild(i) : console.warn("Opening of a new tab failed");
 }
}

class RendeQuTor {
 constructor(e, t, i) {
  this.renderer = e, this.scene = t, this.camera = i, this.queue = new RenderQueue(e), 
  this.pqueue = new RenderQueue(e), this.vp_w = 0, this.vp_h = 0, this.pick_radius = 32, 
  this.pick_center = 16, this.make_PRP_plain(), this.make_PRP_depth2r(), this.renderer.preDownloadPrograms([ this.PRP_depth2r_mat.requiredProgram(this.renderer) ]), 
  this.SSAA_value = 1, this.clear_zero_f32arr = new Float32Array([ 0, 0, 0, 0 ]), 
  this.std_textures = [], this.std_tex_cnt = 0, this.std_tex_used = new Set();
 }
 initDirectToScreen() {
  this.make_RP_DirectToScreen();
 }
 initSimple(e) {
  this.SSAA_value = e, this.make_RP_SSAA_Super(), this.make_RP_GBuffer(), this.make_RP_Outline(), 
  this.make_RP_GaussHVandBlend(), this.make_RP_ToScreen(), this.make_RP_ToneMapToScreen(), 
  this.RP_GBuffer.obj_list = [], this.renderer.preDownloadPrograms([ this.RP_GBuffer_mat.requiredProgram(this.renderer), this.RP_Outline_mat.requiredProgram(this.renderer), this.RP_GaussH_mat.requiredProgram(this.renderer), this.RP_Blend_mat.requiredProgram(this.renderer), this.RP_ToScreen_mat.requiredProgram(this.renderer), this.RP_ToneMapToScreen_mat.requiredProgram(this.renderer) ]);
 }
 initFull(e) {
  this.SSAA_value = e, this.make_RP_SSAA_Super(), this.make_RP_HighPassGaussBloom(), 
  this.make_RP_ToScreen(), this.RP_ToScreen.input_texture = "color_bloom";
 }
 updateViewport(e, t) {
  var i = {
   width: this.vp_w = e,
   height: this.vp_h = t
  }, r = this.queue._renderQueue;
  for (let e = 0; e < r.length; e++) r[e].view_setup(i);
 }
 pop_std_texture() {
  let e;
  return e = 0 == this.std_textures.length ? "std_tex_" + this.std_tex_cnt++ : this.std_textures.pop(), 
  this.std_tex_used.add(e), e;
 }
 push_std_texture(e) {
  this.std_tex_used.delete(e), this.std_textures.push(e);
 }
 release_std_textures() {
  if (0 < this.std_tex_used.size) {
   for (const e of this.std_tex_used) this.std_textures.push(e);
   this.std_tex_used.clear();
  }
 }
 render_outline() {
  var e = this.pop_std_texture(), t = this.pop_std_texture();
  this.RP_GBuffer.outTextures[0].id = e, this.RP_GBuffer.outTextures[1].id = t, 
  this.queue.render_pass(this.RP_GBuffer, "GBuffer"), this.RP_Outline.intex_normal = e, 
  this.RP_Outline.intex_view_dir = t, this.tex_outline ? this.RP_Outline.outTextures[0].clearColorArray = null : this.tex_outline = this.pop_std_texture(), 
  this.RP_Outline.outTextures[0].id = this.tex_outline, this.queue.render_pass(this.RP_Outline, "Outline"), 
  this.push_std_texture(e), this.push_std_texture(t);
 }
 render_main_and_blend_outline() {
  var e, t, i = 1 == this.SSAA_value, r = i ? this.pop_std_texture() : "color_main";
  this.RP_SSAA_Super.outTextures[0].id = r, this.queue.render_pass(this.RP_SSAA_Super, "SSAA Super"), 
  this.tex_outline ? (e = this.tex_outline, t = this.pop_std_texture(), this.RP_GaussH.intex = e, 
  this.RP_GaussH.outTextures[0].id = t, this.queue.render_pass(this.RP_GaussH, "GaussH"), 
  this.RP_GaussV.intex = t, this.RP_GaussV.outTextures[0].id = e, this.queue.render_pass(this.RP_GaussV, "GaussV"), 
  this.RP_Blend.intex_outline_blurred = e, this.RP_Blend.intex_main = r, this.RP_Blend.outTextures[0].id = t, 
  this.queue.render_pass(this.RP_Blend, "Blend"), i && this.push_std_texture(r), 
  this.push_std_texture(this.tex_outline), this.RP_Outline.outTextures[0].clearColorArray = this.clear_zero_f32arr, 
  this.tex_outline = null, this.tex_final = t, this.tex_final_push = !0) : (this.tex_final = r, 
  this.tex_final_push = i);
 }
 render_tone_map_to_screen() {
  this.RP_ToneMapToScreen.input_texture = this.tex_final, this.queue.render_pass(this.RP_ToneMapToScreen, "Tone Map To Screen"), 
  this.tex_final_push && (this.push_std_texture(this.tex_final), this.tex_final = null, 
  this.tex_final_push = null);
 }
 render_final_to_screen() {
  this.RP_ToScreen.input_texture = this.tex_final, this.queue.render_pass(this.RP_ToScreen, "Copy Final To Screen"), 
  this.tex_final_push && (this.push_std_texture(this.tex_final), this.tex_final = null, 
  this.tex_final_push = null);
 }
 render_begin(e) {
  this.tex_outline = null, this.queue.render_begin(e);
 }
 render_end() {
  this.queue.render_end(), this.release_std_textures();
 }
 render() {
  this.queue.render();
 }
 pick_begin(e, t) {
  this.camera.prePickStoreTBLR(), this.camera.narrowProjectionForPicking(this.vp_w, this.vp_h, this.pick_radius, this.pick_radius, e, this.vp_h - 1 - t);
 }
 pick_end() {
  this.camera.postPickRestoreTBLR();
 }
 pick(e, t, i = !1) {
  this.renderer.pick_setup(this.pick_center, this.pick_center);
  var r = this.pqueue.render();
  if (r.x = e, r.y = t, r.depth = -1, r.object = this.renderer.pickedObject3D, i && null !== this.renderer.pickedObject3D) {
   var e = this.renderer, t = e.gl, i = e.glManager._fboManager, s = (i.bindFramebuffer(this.pqueue._renderTarget), 
   new Float32Array(36)), a = (t.readBuffer(t.COLOR_ATTACHMENT0), t.readPixels(this.pick_center - 1, this.pick_center - 1, 3, 3, t.RGBA, t.FLOAT, s), 
   i.unbindFramebuffer(), this.camera.near), n = this.camera.far;
   for (let e = 0; e < 9; ++e) s[e] = a * n / ((a - n) * s[4 * e] + n);
   r.depth = s[4];
  }
  return r;
 }
 pick_instance(e) {
  return e.object !== this.renderer.pickedObject3D ? console.error("RendeQuTor::pick_instance state mismatch", e, this.renderer.pickedObject3D) : (this.renderer._pickSecondaryEnabled = !0, 
  this.pqueue.render(), e.instance = this.renderer._pickedID), e;
 }
 make_PRP_plain() {
  let i = this;
  this.PRP_plain = new RenderPass(RenderPass.BASIC, function(e, t) {}, function(e, t) {
   return {
    scene: i.scene,
    camera: i.camera
   };
  }, function(e, t) {}, RenderPass.TEXTURE, {
   width: this.pick_radius,
   height: this.pick_radius
  }, "depth_picking", [ {
   id: "color_picking",
   textureConfig: RenderPass.DEFAULT_R32UI_TEXTURE_CONFIG,
   clearColorArray: new Uint32Array([ 4294967295, 0, 0, 0 ])
  } ]), this.pqueue.pushRenderPass(this.PRP_plain);
 }
 make_PRP_depth2r() {
  this.PRP_depth2r_mat = new CustomShaderMaterial("copyDepthToRed"), this.PRP_depth2r_mat.lights = !1;
  let i = this;
  this.PRP_depth2r = new RenderPass(RenderPass.POSTPROCESS, function(e, t) {}, function(e, t) {
   return {
    material: i.PRP_depth2r_mat,
    textures: [ e.depth_picking ]
   };
  }, function(e, t) {}, RenderPass.TEXTURE, {
   width: this.pick_radius,
   height: this.pick_radius
  }, null, [ {
   id: "depthr32f_picking",
   textureConfig: RenderPass.FULL_FLOAT_R32F_TEXTURE_CONFIG,
   clearColorArray: new Float32Array([ 1, 0, 0, 0 ])
  } ]), this.pqueue.pushRenderPass(this.PRP_depth2r);
 }
 make_RP_DirectToScreen() {
  let i = this;
  this.RP_DirectToScreen = new RenderPass(RenderPass.BASIC, function(e, t) {}, function(e, t) {
   return {
    scene: i.scene,
    camera: i.camera
   };
  }, function(e, t) {}, RenderPass.SCREEN, null), this.RP_DirectToScreen.view_setup = function(e) {
   this.viewport = e;
  }, this.queue.pushRenderPass(this.RP_DirectToScreen);
 }
 make_RP_SSAA_Super() {
  let i = this;
  this.RP_SSAA_Super = new RenderPass(RenderPass.BASIC, function(e, t) {}, function(e, t) {
   return {
    scene: i.scene,
    camera: i.camera
   };
  }, function(e, t) {}, RenderPass.TEXTURE, null, "depth_main", [ {
   id: "color_main",
   textureConfig: RenderPass.DEFAULT_RGBA16F_TEXTURE_CONFIG
  } ]), this.RP_SSAA_Super.view_setup = function(e) {
   this.viewport = {
    width: e.width * i.SSAA_value,
    height: e.height * i.SSAA_value
   };
  }, this.queue.pushRenderPass(this.RP_SSAA_Super);
 }
 make_RP_SSAA_Down() {
  this.RP_SSAA_Down_mat = new CustomShaderMaterial("copyTexture"), this.RP_SSAA_Down_mat.lights = !1;
  let i = this;
  this.RP_SSAA_Down = new RenderPass(RenderPass.POSTPROCESS, function(e, t) {}, function(e, t) {
   return {
    material: i.RP_SSAA_Down_mat,
    textures: [ e[this.input_texture] ]
   };
  }, function(e, t) {}, RenderPass.TEXTURE, null, null, [ {
   id: "color_main",
   textureConfig: RenderPass.DEFAULT_RGBA16F_TEXTURE_CONFIG
  } ]), this.RP_SSAA_Down.input_texture = "color_super", this.RP_SSAA_Down.view_setup = function(e) {
   this.viewport = e;
  }, this.queue.pushRenderPass(this.RP_SSAA_Down);
 }
 make_RP_ToScreen() {
  this.RP_ToScreen_mat = new CustomShaderMaterial("copyTexture"), this.RP_ToScreen_mat.lights = !1;
  let i = this;
  this.RP_ToScreen = new RenderPass(RenderPass.POSTPROCESS, function(e, t) {}, function(e, t) {
   return {
    material: i.RP_ToScreen_mat,
    textures: [ e[this.input_texture] ]
   };
  }, function(e, t) {}, RenderPass.SCREEN, null), this.RP_ToScreen.input_texture = "color_main", 
  this.RP_ToScreen.view_setup = function(e) {
   this.viewport = e;
  }, this.queue.pushRenderPass(this.RP_ToScreen);
 }
 make_RP_ToneMapToScreen() {
  this.RP_ToneMapToScreen_mat = new CustomShaderMaterial("ToneMapping", {
   MODE: 1,
   gamma: 1,
   exposure: 2
  }), this.RP_ToneMapToScreen_mat.lights = !1;
  let i = this;
  this.RP_ToneMapToScreen = new RenderPass(RenderPass.POSTPROCESS, function(e, t) {}, function(e, t) {
   return {
    material: i.RP_ToneMapToScreen_mat,
    textures: [ e[this.input_texture] ]
   };
  }, function(e, t) {}, RenderPass.SCREEN, null), this.RP_ToneMapToScreen.input_texture = "color_main", 
  this.RP_ToneMapToScreen.view_setup = function(e) {
   this.viewport = e;
  }, this.queue.pushRenderPass(this.RP_ToneMapToScreen);
 }
 make_RP_GBuffer() {
  this.RP_GBuffer_mat = new CustomShaderMaterial("GBufferMini"), this.RP_GBuffer_mat.lights = !1, 
  this.RP_GBuffer_mat.side = FRONT_AND_BACK_SIDE, this.RP_GBuffer_mat_flat = new CustomShaderMaterial("GBufferMini"), 
  this.RP_GBuffer_mat_flat.lights = !1, this.RP_GBuffer_mat_flat.side = FRONT_AND_BACK_SIDE, 
  this.RP_GBuffer_mat_flat.normalFlat = !0;
  let r = this;
  this.RP_GBuffer = new RenderPass(RenderPass.BASIC, function(e, t) {}, function(e, t) {
   r.renderer._outlineEnabled = !0, r.renderer._outlineArray = this.obj_list, r.renderer._defaultOutlineMat = r.RP_GBuffer_mat, 
   r.renderer._defaultOutlineMatFlat = r.RP_GBuffer_mat_flat, r.renderer._fillRequiredPrograms(r.RP_GBuffer_mat.requiredProgram(r.renderer)), 
   r.renderer._fillRequiredPrograms(r.RP_GBuffer_mat_flat.requiredProgram(r.renderer));
   for (const i of this.obj_list) i.outlineMaterial && r.renderer._fillRequiredPrograms(i.outlineMaterial.requiredProgram(r.renderer));
   return {
    scene: r.scene,
    camera: r.camera
   };
  }, function(e, t) {
   r.renderer._outlineEnabled = !1, r.renderer._outlineArray = null;
  }, RenderPass.TEXTURE, null, "depth_gbuff", [ {
   id: "normal",
   textureConfig: RenderPass.DEFAULT_RGBA16F_TEXTURE_CONFIG,
   clearColorArray: this.clear_zero_f32arr
  }, {
   id: "view_dir",
   textureConfig: RenderPass.DEFAULT_RGBA16F_TEXTURE_CONFIG,
   clearColorArray: this.clear_zero_f32arr
  } ]), this.RP_GBuffer.view_setup = function(e) {
   this.viewport = e;
  }, this.queue.pushRenderPass(this.RP_GBuffer);
 }
 make_RP_Outline() {
  this.RP_Outline_mat = new CustomShaderMaterial("outline", {
   scale: 1,
   edgeColor: [ 1.4, 0, .8, 1 ],
   _DepthThreshold: 6,
   _NormalThreshold: .6,
   _DepthNormalThreshold: .5,
   _DepthNormalThresholdScale: 7
  }), this.RP_Outline_mat.addSBFlag("DISCARD_NON_EDGE"), this.RP_Outline_mat.lights = !1;
  let i = this;
  this.RP_Outline = new RenderPass(RenderPass.POSTPROCESS, function(e, t) {}, function(e, t) {
   return {
    material: i.RP_Outline_mat,
    textures: [ e.depth_gbuff, e[this.intex_normal], e[this.intex_view_dir] ]
   };
  }, function(e, t) {}, RenderPass.TEXTURE, null, null, [ {
   id: "color_outline",
   textureConfig: RenderPass.DEFAULT_RGBA16F_TEXTURE_CONFIG,
   clearColorArray: this.clear_zero_f32arr
  } ]), this.RP_Outline.intex_normal = "normal", this.RP_Outline.intex_view_dir = "view_dir", 
  this.RP_Outline.view_setup = function(e) {
   this.viewport = e;
  }, this.queue.pushRenderPass(this.RP_Outline);
 }
 make_RP_GaussHVandBlend() {
  let i = this;
  this.RP_GaussH_mat = new CustomShaderMaterial("gaussBlur", {
   horizontal: !0,
   power: 4
  }), this.RP_GaussH_mat.lights = !1, this.RP_GaussH = new RenderPass(RenderPass.POSTPROCESS, function(e, t) {}, function(e, t) {
   return {
    material: i.RP_GaussH_mat,
    textures: [ e[this.intex] ]
   };
  }, function(e, t) {}, RenderPass.TEXTURE, null, null, [ {
   id: "gauss_h",
   textureConfig: RenderPass.DEFAULT_RGBA16F_TEXTURE_CONFIG
  } ]), this.RP_GaussH.intex = "color_outline", this.RP_GaussH.view_setup = function(e) {
   this.viewport = e;
  }, this.RP_GaussV_mat = new CustomShaderMaterial("gaussBlur", {
   horizontal: !1,
   power: 4
  }), this.RP_GaussV_mat.lights = !1, this.RP_GaussV = new RenderPass(RenderPass.POSTPROCESS, function(e, t) {}, function(e, t) {
   return {
    material: i.RP_GaussV_mat,
    textures: [ e[this.intex] ]
   };
  }, function(e, t) {}, RenderPass.TEXTURE, null, null, [ {
   id: "gauss_hv",
   textureConfig: RenderPass.DEFAULT_RGBA16F_TEXTURE_CONFIG
  } ]), this.RP_GaussV.intex = "gauss_h", this.RP_GaussV.view_setup = function(e) {
   this.viewport = e;
  }, this.RP_Blend_mat = new CustomShaderMaterial("blendingAdditive"), this.RP_Blend_mat.lights = !1, 
  this.RP_Blend = new RenderPass(RenderPass.POSTPROCESS, function(e, t) {}, function(e, t) {
   return {
    material: i.RP_Blend_mat,
    textures: [ e[this.intex_outline_blurred], e[this.intex_main] ]
   };
  }, function(e, t) {}, RenderPass.TEXTURE, null, null, [ {
   id: "color_final",
   textureConfig: RenderPass.DEFAULT_RGBA16F_TEXTURE_CONFIG
  } ]), this.RP_Blend.intex_outline_blurred = "gauss_hv", this.RP_Blend.intex_main = "color_main", 
  this.RP_Blend.view_setup = function(e) {
   this.viewport = e;
  }, this.queue.pushRenderPass(this.RP_GaussH), this.queue.pushRenderPass(this.RP_GaussV), 
  this.queue.pushRenderPass(this.RP_Blend);
 }
 make_RP_HighPassGaussBloom() {
  let i = this;
  var e = new CustomShaderMaterial("highPass", {
   MODE: HIGHPASS_MODE_DIFFERENCE,
   targetColor: [ 0, 0, 1 ],
   threshold: .1
  });
  console.log("XXXXXXXX", e), this.RP_HighPass_mat = e, this.RP_HighPass_mat.lights = !1, 
  this.RP_HighPass = new RenderPass(RenderPass.POSTPROCESS, function(e, t) {}, function(e, t) {
   return {
    material: i.RP_HighPass_mat,
    textures: [ e.color_ssaa_super ]
   };
  }, function(e, t) {}, RenderPass.TEXTURE, null, null, [ {
   id: "color_high_pass",
   textureConfig: RenderPass.DEFAULT_RGBA_TEXTURE_CONFIG
  } ]), this.RP_HighPass.view_setup = function(e) {
   this.viewport = {
    width: e.width * i.SSAA_value,
    height: e.height * i.SSAA_value
   };
  }, this.queue.pushRenderPass(this.RP_HighPass), this.RP_Gauss1_mat = new CustomShaderMaterial("gaussBlur", {
   horizontal: !0,
   power: 1
  }), this.RP_Gauss1_mat.lights = !1, this.RP_Gauss1 = new RenderPass(RenderPass.POSTPROCESS, function(e, t) {}, function(e, t) {
   return {
    material: i.RP_Gauss1_mat,
    textures: [ e.color_high_pass ]
   };
  }, function(e, t) {}, RenderPass.TEXTURE, null, null, [ {
   id: "color_gauss_half",
   textureConfig: RenderPass.DEFAULT_RGBA_TEXTURE_CONFIG
  } ]), this.RP_Gauss1.view_setup = function(e) {
   this.viewport = {
    width: e.width * i.SSAA_value,
    height: e.height * i.SSAA_value
   };
  }, this.queue.pushRenderPass(this.RP_Gauss1), this.RP_Gauss2_mat = new CustomShaderMaterial("gaussBlur", {
   horizontal: !1,
   power: 1
  }), this.RP_Gauss2_mat.lights = !1, this.RP_Gauss2 = new RenderPass(RenderPass.POSTPROCESS, function(e, t) {}, function(e, t) {
   return {
    material: i.RP_Gauss2_mat,
    textures: [ e.color_gauss_half ]
   };
  }, function(e, t) {}, RenderPass.TEXTURE, null, null, [ {
   id: "color_gauss_full",
   textureConfig: RenderPass.DEFAULT_RGBA_TEXTURE_CONFIG
  } ]), this.RP_Gauss2.view_setup = function(e) {
   this.viewport = {
    width: e.width * i.SSAA_value,
    height: e.height * i.SSAA_value
   };
  }, this.queue.pushRenderPass(this.RP_Gauss2), this.RP_Bloom_mat = new CustomShaderMaterial("bloom"), 
  this.RP_Bloom_mat.lights = !1, this.RP_Bloom = new RenderPass(RenderPass.POSTPROCESS, function(e, t) {}, function(e, t) {
   return {
    material: i.RP_Bloom_mat,
    textures: [ e.color_gauss_full, e.color_ssaa_super ]
   };
  }, function(e, t) {}, RenderPass.TEXTURE, null, null, [ {
   id: "color_bloom",
   textureConfig: RenderPass.DEFAULT_RGBA_TEXTURE_CONFIG
  } ]), this.RP_Bloom.view_setup = function(e) {
   this.viewport = {
    width: e.width * i.SSAA_value,
    height: e.height * i.SSAA_value
   };
  }, this.queue.pushRenderPass(this.RP_Bloom);
 }
}

class REveCameraControls extends EventDispatcher {
 static matrixExtendDone = !1;
 constructor(D, e) {
  var s, a, t = {
   ROTATE: 0,
   DOLLY: 1,
   PAN: 2
  }, i = {
   ROTATE: 0,
   PAN: 1,
   DOLLY_PAN: 2,
   DOLLY_ROTATE: 3
  }, n = (super(EventDispatcher), REveCameraControls.matrixExtendDone || (Matrix4.prototype.lookAtMt = function(e, t, i) {
   var r = new Vector3(), s = new Vector3(), a = new Vector3(), n = this.elements;
   return a.copy(t), a.normalize(), r.crossVectors(i, a), r.normalize(), s.crossVectors(a, r), 
   n[0] = r.x, n[4] = s.x, n[8] = a.x, n[1] = r.y, n[5] = s.y, n[9] = a.y, n[2] = r.z, 
   n[6] = s.z, n[10] = a.z, this;
  }, Matrix4.prototype.getBaseVector = function(e) {
   var e = 4 * --e, t = this.elements;
   return new Vector3(t[0 + e], t[1 + e], t[2 + e]);
  }, Matrix4.prototype.getTranslation = function() {
   var e = this.elements;
   return new Vector3(e[12], e[13], e[14]);
  }, Matrix4.prototype.setBaseVector = function(e, t, i, r) {
   var e = 4 * --e, s = this.elements;
   t.isVector3 ? (s[0 + e] = t.x, s[1 + e] = t.y, s[2 + e] = t.z) : (s[0 + e] = t, 
   s[1 + e] = i, s[2 + e] = r);
  }, Matrix4.prototype.rotateIP = function(e) {
   var t = this.elements, i = e.clone();
   e.x = t[0] * i.x + t[4] * i.y + t[8] * i.z, e.y = t[1] * i.x + t[5] * i.y + t[9] * i.z, 
   e.z = t[2] * i.x + t[6] * i.y + t[10] * i.z;
  }, Matrix4.prototype.rotateLF = function(i, r, e) {
   if (i != r) {
    var s, a, n = Math.cos(e), o = Math.sin(e), h = this.elements;
    i = 4 * (i - 1), r = 4 * (r - 1);
    let t = 0;
    for (let e = 0; e < 4; ++e, ++t) s = n * h[i + t] + o * h[r + t], a = n * h[r + t] - o * h[i + t], 
    h[i + t] = s, h[r + t] = a;
   }
  }, Matrix4.prototype.rotatePF = function(t, i, e) {
   if (t != i) {
    var r = Math.cos(e), s = Math.sin(e), a = this.elements;
    --t, --i;
    for (let e = 0; e < 4; ++e) {
     var n = 4 * e, o = r * a[t + n] - s * a[i + n], h = r * a[i + n] + s * a[t + n];
     a[t + n] = o, a[i + n] = h;
    }
   }
  }, Matrix4.prototype.moveLF = function(e, t) {
   var i = this.elements, e = 4 * (e - 1);
   i[12] += t * i[e], i[13] += t * i[1 + e], i[14] += t * i[2 + e];
  }, Matrix4.prototype.dump = function() {
   for (let i = 0; i < 4; i++) {
    let t = "[ ";
    for (let e = 0; e < 4; e++) {
     var r = this.elements[4 * e + i].toFixed(2);
     t = t + r + " ";
    }
    console.log(t + "]");
   }
  }, REveCameraControls.matrixExtendDone = !0), this.object = D, this.domElement = void 0 !== e ? e : document, 
  this.enabled = !0, this.target = new Vector3(), this.cameraCenter = new Vector3(), 
  this.minDistance = 0, this.maxDistance = 1 / 0, this.minZoom = 0, this.maxZoom = 1 / 0, 
  this.minPolarAngle = 0, this.maxPolarAngle = Math.PI, this.minAzimuthAngle = -1 / 0, 
  this.maxAzimuthAngle = 1 / 0, this.enableDamping = !1, this.dampingFactor = .05, 
  this.enableZoom = !0, this.zoomSpeed = 1, this.enableRotate = !0, this.rotateSpeed = 1, 
  this.enablePan = !0, this.panSpeed = 1, this.screenSpacePanning = !1, this.keyPanSpeed = 7, 
  this.autoRotate = !1, this.autoRotateSpeed = 2, this.enableKeys = !0, this.keys = {
   LEFT: 37,
   UP: 38,
   RIGHT: 39,
   BOTTOM: 40
  }, this.mouseButtons = {
   LEFT: t.ROTATE,
   MIDDLE: t.DOLLY,
   RIGHT: t.PAN
  }, this.touches = {
   ONE: i.ROTATE,
   TWO: i.DOLLY_PAN
  }, this.target0 = this.target.clone(), this.position0 = this.object.position.clone(), 
  this.zoom0 = this.object.zoom, this.setCamBaseMtx = function(e, t) {
   m.identity(), m.setBaseVector(1, e), m.setBaseVector(3, t);
   var i = new Vector3();
   i.crossVectors(t, e), m.setBaseVector(2, i);
  }, this.setFromBBox = function(e) {
   var t = new Vector3(), t = (e.getCenter(t), Math.max(e.min.length(), e.max.length()));
   g.identity(), this.object.isPerspectiveCamera ? (e = Math.min(30, 30 * this.object.aspect), 
   e = t / (2 * Math.tan(e * Math.PI * .8 / 180)), g.moveLF(1, e)) : (e = .625 * Math.sqrt(3) * t, 
   g.moveLF(1, e), n.object._near = .05 * e, n.object._far = 2 * e, n.object.updateProjectionMatrix());
  }, this.setCameraCenter = function(e, t, i) {
   this.cameraCenter.set(e, t, i);
   e = new Matrix4(), e.multiplyMatrices(m, g), m.setBaseVector(4, this.cameraCenter), 
   t = m.clone();
   t.getInverse(m), g.multiplyMatrices(t, e), this.centerMarker && (this.centerMarker.position = this.cameraCenter, 
   this.centerMarker.visible = !0, this.centerMarker.updateMatrix());
  }, this.getPolarAngle = function() {
   return c.phi;
  }, this.getAzimuthalAngle = function() {
   return c.theta;
  }, this.saveState = function() {
   n.target0.copy(n.target), n.position0.copy(n.object.position), n.zoom0 = n.object.zoom;
  }, this.reset = function() {
   n.target.copy(n.target0), n.object.position.copy(n.position0), n.object.zoom = n.zoom0, 
   n.object.updateProjectionMatrix(), n.dispatchEvent(o), n.update(), l = u.NONE;
  }, this.resetOrthoPanZoom = function() {
   f.set(0, 0, 0), n.object.zoom = .78, n.object.updateProjectionMatrix(), y = !0;
  }, this.resetMouseDown = function(e) {
   N();
  }, this.testCameraMenu = function() {
   L(.5);
  }, this.update = (s = new Vector3(), a = new Quaternion(), function() {
   1 != p && (t = g.getBaseVector(1), e = g.getBaseVector(4), t = t.dot(e), t = Math.sqrt(t), 
   e.multiplyScalar(p), g.setBaseVector(4, e), p = 1, n.object.near = Math.min(.1 * t, 20)), 
   (f.x || f.y) && (g.moveLF(2, f.x), g.moveLF(3, f.y), f.set(0, 0, 0));
   var e = new Matrix4(), t = (e.multiplyMatrices(m, g), n.object.testMtx = e, new Vector3()), i = (t.setFromMatrixPosition(e), 
   new Vector3()), r = (i.setFromMatrixColumn(e, 0), new Vector3());
   return r.setFromMatrixColumn(e, 2), n.object._matrix.lookAtMt(t, i, r), n.object._matrix.setPosition(t), 
   n.object.matrixWorld.copy(n.object.matrix), y || s.distanceToSquared(e.getBaseVector(4)) > _ || 10 * (d.phi + d.theta) > _ ? (n.dispatchEvent(o), 
   s.copy(e.getBaseVector(4)), a.copy(n.object.quaternion), y = !1, d.theta = 0, 
   !(d.phi = 0)) : (s.distanceToSquared(e.getBaseVector(4)), !0);
  }), this.dispose = function() {
   n.domElement.removeEventListener("contextmenu", K, !1), n.domElement.removeEventListener("mousedown", j, !1), 
   n.domElement.removeEventListener("wheel", H, !1), n.domElement.removeEventListener("touchstart", X, !1), 
   n.domElement.removeEventListener("touchend", Z, !1), n.domElement.removeEventListener("touchmove", Y, !1), 
   document.removeEventListener("mousemove", I, !1), document.removeEventListener("mouseup", N, !1), 
   window.removeEventListener("keydown", O, !1);
  }, this), o = {
   type: "change"
  }, r = {
   type: "start"
  }, h = {
   type: "end"
  }, u = {
   NONE: -1,
   ROTATE: 0,
   DOLLY: 1,
   PAN: 2,
   TOUCH_ROTATE: 3,
   TOUCH_PAN: 4,
   TOUCH_DOLLY_PAN: 5,
   TOUCH_DOLLY_ROTATE: 6
  }, l = u.NONE, _ = 1e-6, c = new Spherical(), d = new Spherical(), m = new Matrix4(), g = new Matrix4(), p = 1, f = new Vector3(), y = !1, T = new Vector2(), x = new Vector2(), S = new Vector2(), E = new Vector2(), A = new Vector2(), R = new Vector2(), v = new Vector2(), P = new Vector2(), w = new Vector2();
  function M() {
   return Math.pow(.95, n.zoomSpeed);
  }
  function B(e, t) {
   var i, r, s, a;
   0 != e && (a = g.getBaseVector(1), g.getBaseVector(2), s = g.getBaseVector(3), 
   i = (r = g.getTranslation()).dot(a), r = r.dot(s), s = m.getBaseVector(3), m.rotateIP(a), 
   (a = Math.acos(a.dot(s))) + e < .01 ? e = .01 - a : a + e > Math.PI - .01 && (e = Math.PI - .01 - a), 
   g.moveLF(1, -i), g.moveLF(3, -r), g.rotateLF(3, 1, e), g.moveLF(3, r), g.moveLF(1, i)), 
   0 != t && g.rotatePF(1, 2, -t), d.phi = e, d.theta = t;
  }
  var b = function(e, t) {
   e = -e;
   var i, r, s = n.domElement === document ? n.domElement.body : n.domElement;
   n.object.isPerspectiveCamera ? (i = t * (r = .5 * (n.object.far + n.object.near) * Math.tan(.5 * n.object.fov * Math.PI / 180)) / s.clientHeight, 
   r = e * r / s.clientHeight, f.setX(r), f.setY(i)) : n.object.isOrthographicCamera ? (f.setX(e * (n.object.right - n.object.left) / n.object.zoom / s.clientWidth), 
   f.setY(t * (n.object.top - n.object.bottom) / n.object.zoom / s.clientHeight)) : (console.warn("WARNING: REveCameraControls encountered an unknown camera type - pan disabled."), 
   n.enablePan = !1), n.update();
  };
  function L(e) {
   n.object.isPerspectiveCamera ? p /= e : n.object.isOrthographicCamera ? (n.object.zoom = Math.max(n.minZoom, Math.min(n.maxZoom, n.object.zoom * e)), 
   n.object.updateProjectionMatrix(), y = !0) : (console.warn("WARNING: REveCameraControls encountered an unknown camera type - dolly/zoom disabled."), 
   n.enableZoom = !1), n.update();
  }
  function z(e) {
   n.object.isPerspectiveCamera ? p *= e : n.object.isOrthographicCamera ? (n.object.zoom = Math.max(n.minZoom, Math.min(n.maxZoom, n.object.zoom / e)), 
   n.object.updateProjectionMatrix(), y = !0) : (console.warn("WARNING: REveCameraControls encountered an unknown camera type - dolly/zoom disabled."), 
   n.enableZoom = !1), n.update();
  }
  function C(e) {
   T.set(e.clientX, e.clientY);
  }
  function F(e) {
   E.set(e.clientX, e.clientY);
  }
  function U(e) {
   var t;
   1 == e.touches.length ? T.set(e.touches[0].pageX, e.touches[0].pageY) : (t = .5 * (e.touches[0].pageX + e.touches[1].pageX), 
   e = .5 * (e.touches[0].pageY + e.touches[1].pageY), T.set(t, e));
  }
  function G(e) {
   var t;
   1 == e.touches.length ? E.set(e.touches[0].pageX, e.touches[0].pageY) : (t = .5 * (e.touches[0].pageX + e.touches[1].pageX), 
   e = .5 * (e.touches[0].pageY + e.touches[1].pageY), E.set(t, e));
  }
  function V(e) {
   var t = e.touches[0].pageX - e.touches[1].pageX, e = e.touches[0].pageY - e.touches[1].pageY, t = Math.sqrt(t * t + e * e);
   v.set(0, t);
  }
  function k(e) {
   1 == e.touches.length ? x.set(e.touches[0].pageX, e.touches[0].pageY) : (t = .5 * (e.touches[0].pageX + e.touches[1].pageX), 
   e = .5 * (e.touches[0].pageY + e.touches[1].pageY), x.set(t, e)), S.subVectors(x, T).multiplyScalar(n.rotateSpeed);
   var t = n.domElement === document ? n.domElement.body : n.domElement;
   B(-2 * Math.PI * S.y / t.clientHeight, 2 * Math.PI * S.x / t.clientWidth), T.copy(x);
  }
  function q(e) {
   var t;
   1 == e.touches.length ? A.set(e.touches[0].pageX, e.touches[0].pageY) : (t = .5 * (e.touches[0].pageX + e.touches[1].pageX), 
   e = .5 * (e.touches[0].pageY + e.touches[1].pageY), A.set(t, e)), R.subVectors(A, E).multiplyScalar(n.panSpeed), 
   b(R.x, R.y), E.copy(A);
  }
  function W(e) {
   var t = e.touches[0].pageX - e.touches[1].pageX, e = e.touches[0].pageY - e.touches[1].pageY, t = Math.sqrt(t * t + e * e);
   P.set(0, t), w.set(0, Math.pow(P.y / v.y, n.zoomSpeed)), L(w.y), v.copy(P);
  }
  function j(e) {
   if (!1 !== n.enabled) {
    switch (e.preventDefault(), (n.domElement.focus ? n.domElement : window).focus(), 
    e.button) {
    case 0:
     switch (n.mouseButtons.LEFT) {
     case t.ROTATE:
      if (e.ctrlKey || e.metaKey || e.shiftKey) {
       if (!1 === n.enablePan) return;
       F(e), l = u.PAN;
      } else {
       if (!1 === n.enableRotate) return;
       C(e), l = u.ROTATE;
      }
      break;

     case t.PAN:
      if (e.ctrlKey || e.metaKey || e.shiftKey) {
       if (!1 === n.enableRotate) return;
       C(e), l = u.ROTATE;
      } else {
       if (!1 === n.enablePan) return;
       F(e), l = u.PAN;
      }
      break;

     default:
      l = u.NONE;
     }
     break;

    case 1:
     if (n.mouseButtons.MIDDLE === t.DOLLY) {
      if (!1 === n.enableZoom) return;
      v.set(e.clientX, e.clientY), l = u.DOLLY;
     } else l = u.NONE;
     break;

    case 2:
     switch (n.mouseButtons.RIGHT) {
     case t.ROTATE:
      if (!1 === n.enableRotate) return;
      C(e), l = u.ROTATE;
      break;

     case t.PAN:
      if (!1 === n.enablePan) return;
      F(e), l = u.PAN;
      break;

     default:
      l = u.NONE;
     }
    }
    l !== u.NONE && (document.addEventListener("mousemove", I, !1), document.addEventListener("mouseup", N, !1), 
    n.dispatchEvent(r));
   }
  }
  function I(e) {
   var t;
   if (!1 !== n.enabled) switch (e.preventDefault(), l) {
   case u.ROTATE:
    !1 !== n.enableRotate && (t = e, x.set(t.clientX, t.clientY), S.subVectors(x, T).multiplyScalar(n.rotateSpeed), 
    t = n.domElement === document ? n.domElement.body : n.domElement, B(-2 * Math.PI * S.y / t.clientHeight, 2 * Math.PI * S.x / t.clientWidth), 
    T.copy(x), n.update());
    break;

   case u.DOLLY:
    !1 !== n.enableZoom && (P.set(e.clientX, e.clientY), w.subVectors(P, v), 0 < w.y ? L(M()) : w.y < 0 && z(M()), 
    v.copy(P), n.update());
    break;

   case u.PAN:
    !1 !== n.enablePan && (A.set(e.clientX, e.clientY), R.subVectors(A, E).multiplyScalar(n.panSpeed), 
    b(R.x, R.y), E.copy(A), n.update());
   }
  }
  function N(e) {
   !1 !== n.enabled && (document.removeEventListener("mousemove", I, !1), document.removeEventListener("mouseup", N, !1), 
   n.dispatchEvent(h), l = u.NONE);
  }
  function H(e) {
   !1 === n.enabled || !1 === n.enableZoom || l !== u.NONE && l !== u.ROTATE || (e.preventDefault(), 
   e.stopPropagation(), n.dispatchEvent(r), (e = e).deltaY < 0 ? z(M()) : 0 < e.deltaY && L(M()), 
   n.update(), n.dispatchEvent(h));
  }
  function O(e) {
   if (!1 !== n.enabled && !1 !== n.enableKeys && !1 !== n.enablePan) {
    var t = !1;
    switch (e.keyCode) {
    case n.keys.UP:
     b(0, n.keyPanSpeed), t = !0;
     break;

    case n.keys.BOTTOM:
     b(0, -n.keyPanSpeed), t = !0;
     break;

    case n.keys.LEFT:
     b(n.keyPanSpeed, 0), t = !0;
     break;

    case n.keys.RIGHT:
     b(-n.keyPanSpeed, 0), t = !0;
    }
    t && (e.preventDefault(), e.stopImmediatePropagation(), n.update());
   }
  }
  function X(e) {
   if (!1 !== n.enabled) {
    switch (e.preventDefault(), e.touches.length) {
    case 1:
     switch (n.touches.ONE) {
     case i.ROTATE:
      if (!1 === n.enableRotate) return;
      U(e), l = u.TOUCH_ROTATE;
      break;

     case i.PAN:
      if (!1 === n.enablePan) return;
      G(e), l = u.TOUCH_PAN;
      break;

     default:
      l = u.NONE;
     }
     break;

    case 2:
     switch (n.touches.TWO) {
     case i.DOLLY_PAN:
      if (!1 === n.enableZoom && !1 === n.enablePan) return;
      t = e, n.enableZoom && V(t), n.enablePan && G(t), l = u.TOUCH_DOLLY_PAN;
      break;

     case i.DOLLY_ROTATE:
      if (!1 === n.enableZoom && !1 === n.enableRotate) return;
      t = e, n.enableZoom && V(t), n.enableRotate && U(t), l = u.TOUCH_DOLLY_ROTATE;
      break;

     default:
      l = u.NONE;
     }
     break;

    default:
     l = u.NONE;
    }
    var t;
    l !== u.NONE && n.dispatchEvent(r);
   }
  }
  function Y(e) {
   var t;
   if (!1 !== n.enabled) switch (e.preventDefault(), e.stopPropagation(), l) {
   case u.TOUCH_ROTATE:
    !1 !== n.enableRotate && (k(e), n.update());
    break;

   case u.TOUCH_PAN:
    !1 !== n.enablePan && (q(e), n.update());
    break;

   case u.TOUCH_DOLLY_PAN:
    !1 === n.enableZoom && !1 === n.enablePan || (t = e, n.enableZoom && W(t), n.enablePan && q(t), 
    n.update());
    break;

   case u.TOUCH_DOLLY_ROTATE:
    !1 === n.enableZoom && !1 === n.enableRotate || (t = e, n.enableZoom && W(t), 
    n.enableRotate && k(t), n.update());
    break;

   default:
    l = u.NONE;
   }
  }
  function Z(e) {
   !1 !== n.enabled && (n.dispatchEvent(h), l = u.NONE);
  }
  function K(e) {
   !1 !== n.enabled && e.preventDefault();
  }
  n.domElement.addEventListener("contextmenu", K, !1), n.domElement.addEventListener("mousedown", j, !1), 
  n.domElement.addEventListener("wheel", H, !1), n.domElement.addEventListener("touchstart", X, !1), 
  n.domElement.addEventListener("touchend", Z, !1), n.domElement.addEventListener("touchmove", Y, !1), 
  n.domElement.addEventListener("mouseenter", function(e) {
   window.addEventListener("keydown", O);
  }), n.domElement.addEventListener("mouseleave", function(e) {
   window.removeEventListener("keydown", O);
  }), this.update();
 }
}

export {
 AmbientLight,
 BACK_SIDE,
 BLACKLIST,
 Box2,
 Box3,
 BufferAttribute,
 Cache,
 Camera,
 Canvas,
 Circle,
 Color,
 Cube,
 CubeTexture,
 CustomShaderMaterial,
 Cylindrical,
 DirectionalLight,
 Euler,
 EventDispatcher,
 FRAGMENT_SHADER,
 FRONT_AND_BACK_SIDE,
 FRONT_SIDE,
 FUNC_ALWAYS,
 FUNC_EQUAL,
 FUNC_GEQUAL,
 FUNC_GREATER,
 FUNC_LEQUAL,
 FUNC_LESS,
 FUNC_NEVER,
 FUNC_NOTEQUAL,
 FlatShading,
 Float32Attribute,
 Float64Attribute,
 Frustum,
 GLAttributeManager,
 GLFrameBufferManager,
 GLManager,
 GLProgram,
 GLProgramManager,
 GLTextureManager,
 Geometry,
 GouraudShading,
 Grid,
 Group,
 HIGHPASS_MODE_BRIGHTNESS,
 HIGHPASS_MODE_DIFFERENCE,
 ImageCache,
 ImageLoader,
 Int16Attribute,
 Int32Attribute,
 Int8Attribute,
 LINES,
 LINE_LOOP,
 LINE_STRIP,
 Light,
 Line,
 Line3,
 LoadingManager,
 MAXVEC,
 MINVEC,
 Material,
 MaterialProgramTemplate,
 Matrix3,
 Matrix4,
 Mesh,
 MeshBasicMaterial,
 MeshLambertMaterial,
 MeshPhongMaterial$1 as MeshPhongMaterial,
 MeshRenderer,
 Object3D,
 OrthographicCamera,
 POINTS,
 PerspectiveCamera,
 PhongShading,
 PickingShaderMaterial,
 Plane,
 Point,
 PointBasicMaterial,
 PointLight,
 Quad,
 Quaternion,
 REveCameraControls,
 Ray,
 Raycaster,
 RendeQuTor,
 RenderArray,
 RenderArrayManager,
 RenderPass,
 RenderQueue,
 RenderTarget,
 Renderer,
 SPRITE_SPACE_SCREEN,
 SPRITE_SPACE_WORLD,
 STRIPE_CAP_BUTT,
 STRIPE_CAP_DEFAULT,
 STRIPE_CAP_ROUND,
 STRIPE_CAP_SQUARE,
 STRIPE_JOIN_BEVEL,
 STRIPE_JOIN_DEFAULT,
 STRIPE_JOIN_MITER,
 STRIPE_JOIN_ROUND,
 STRIPE_SPACE_SCREEN,
 STRIPE_SPACE_WORLD,
 SUPPRESS_DEFAULT_KEYBOARD_KEYS,
 Scene,
 ShaderBuilder,
 ShaderLoader,
 SmoothShading,
 Sphere,
 Spherical,
 SpotLight,
 Sprite,
 SpriteBasicMaterial,
 SpriteGeometry,
 Stripe,
 StripeBasicMaterial,
 Stripes,
 StripesBasicMaterial,
 StripesGeometry,
 TEXT2D_SPACE_SCREEN,
 TEXT2D_SPACE_WORLD,
 TRIANGLES,
 TRIANGLE_FAN,
 TRIANGLE_STRIP,
 Text2D,
 Text2DMaterial,
 Texture,
 TextureCache,
 Triangle,
 Uint16Attribute,
 Uint32Attribute,
 Uint8Attribute,
 Uint8ClampedAttribute,
 UpdateListener,
 VERTEX_SHADER,
 Vector2,
 Vector3,
 Vector4,
 WEBGL1,
 WEBGL2,
 WrapAroundEnding,
 XHRLoader,
 ZShape,
 ZShapeBasicMaterial,
 ZSprite,
 ZSpriteBasicMaterial,
 ZeroCurvatureEnding,
 ZeroSlopeEnding,
 _Math,
 gamepadIDRegex,
 revision,
 singleton,
 singletonEnforcer
};