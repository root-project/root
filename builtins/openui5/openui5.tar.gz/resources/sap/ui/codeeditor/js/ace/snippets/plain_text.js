(function(){ace.require(["ace/snippets/plain_text"],function(e){if(typeof module=="object"&&typeof exports=="object"&&module){module.exports=e}})})();
//# sourceMappingURL=plain_text.js.map