(function(){ace.require(["ace/snippets/xml"],function(e){if(typeof module=="object"&&typeof exports=="object"&&module){module.exports=e}})})();
//# sourceMappingURL=xml.js.map