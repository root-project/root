// Version number is MAJOR.MINOR.PATCHES (or "trunk")
// Followed guidelines are here: http://apr.apache.org/versioning.html
#define AFVER "v0.4.3"
