#undef I18N

/* debugging options */
#undef  DEBUG_ALLOCS

#undef  HAVE_MMX
#undef  SHAPE

#undef  HAVE_XPM
#undef  HAVE_LIBXPM
#undef  HAVE_LIBXPM_X11

#undef  HAVE_JPEG
#undef  HAVE_PNG
#undef  HAVE_GIF
#undef  HAVE_TIFF
#undef  HAVE_FREETYPE
#undef  HAVE_FREETYPE_FREETYPE

#undef  HAVE_AFTERBASE

